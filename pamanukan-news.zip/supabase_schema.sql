-- ==============================================================================
-- PAMANUKAN NEWS - MASTER DATABASE SCHEMA & SEED DATA UNTUK SUPABASE BARU
-- ==============================================================================
-- Petunjuk Penggunaan:
-- 1. Buka Supabase Dashboard project baru Anda: https://supabase.com/dashboard
-- 2. Pilih project ➔ Masuk menu "SQL Editor" di bilah kiri.
-- 3. Klik "New query", salin (copy) dan tempel (paste) seluruh skrip ini.
-- 4. Klik tombol "RUN" (atau tekan Ctrl+Enter).
-- ==============================================================================

-- 1. AKTIFKAN EXTENSION
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ==============================================================================
-- 2. TABEL PENGGUNA TERHUBUNG DENGAN SUPABASE AUTH (auth.users)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'publisher' CHECK (role IN ('admin', 'publisher')),
  avatar TEXT DEFAULT 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  bio TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_users_role ON public.users(role);
CREATE INDEX IF NOT EXISTS idx_users_email ON public.users(email);

-- ==============================================================================
-- 3. TRIGGER OTOMATIS: SINKRONISASI AKUN BARU SUPABASE AUTH KE PUBLIC.USERS
-- ==============================================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  assigned_role TEXT;
  full_name TEXT;
BEGIN
  -- Cek metadata 'role' atau tentukan otomatis berdasarkan email
  assigned_role := COALESCE(
    NEW.raw_user_meta_data->>'role', 
    CASE 
      WHEN LOWER(NEW.email) LIKE '%admin%' OR LOWER(NEW.email) LIKE '%pemred%' THEN 'admin'
      ELSE 'publisher'
    END
  );
  
  full_name := COALESCE(
    NEW.raw_user_meta_data->>'name', 
    split_part(NEW.email, '@', 1)
  );

  INSERT INTO public.users (id, email, name, role, avatar, status)
  VALUES (
    NEW.id,
    NEW.email,
    full_name,
    assigned_role,
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    'active'
  )
  ON CONFLICT (id) DO UPDATE
  SET
    email = EXCLUDED.email,
    name = COALESCE(public.users.name, EXCLUDED.name),
    role = COALESCE(public.users.role, EXCLUDED.role),
    updated_at = NOW();

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ==============================================================================
-- 4. FUNGSI PRAKTIS PENGECEKAN & PENGATURAN PERAN (RBAC)
-- ==============================================================================
-- Mengecek apakah pemanggil adalah Admin
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid() AND role = 'admin' AND status = 'active'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Mengecek apakah pemanggil adalah Publisher
CREATE OR REPLACE FUNCTION public.is_publisher()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid() AND role = 'publisher' AND status = 'active'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Fungsi 1-Baris untuk mengubah akun menjadi Admin atau Publisher secara instan
CREATE OR REPLACE FUNCTION public.set_user_role(target_email TEXT, target_role TEXT)
RETURNS TEXT AS $$
BEGIN
  IF target_role NOT IN ('admin', 'publisher') THEN
    RAISE EXCEPTION 'Peran harus berupa admin atau publisher';
  END IF;

  UPDATE public.users 
  SET role = target_role, updated_at = NOW() 
  WHERE email = target_email;

  UPDATE auth.users 
  SET raw_user_meta_data = jsonb_set(COALESCE(raw_user_meta_data, '{}'::jsonb), '{role}', to_jsonb(target_role))
  WHERE email = target_email;

  RETURN 'Sukses: Akun ' || target_email || ' telah diatur sebagai ' || UPPER(target_role);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ==============================================================================
-- 5. TABEL RUBRIK KATEGORI BERITA
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  color TEXT NOT NULL DEFAULT '#dc2626',
  icon_name TEXT,
  "order" INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 6. TABEL ARTIKEL BERITA
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.articles (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  summary TEXT NOT NULL,
  content TEXT NOT NULL,
  category_id TEXT REFERENCES public.categories(id) ON DELETE SET NULL,
  category_name TEXT NOT NULL,
  cover_image TEXT NOT NULL,
  author_id UUID REFERENCES public.users(id) ON DELETE SET NULL,
  author_name TEXT NOT NULL,
  author_avatar TEXT,
  status TEXT NOT NULL DEFAULT 'published' CHECK (status IN ('draft', 'pending', 'published', 'rejected', 'archived')),
  is_headline BOOLEAN NOT NULL DEFAULT false,
  is_featured BOOLEAN NOT NULL DEFAULT false,
  is_editor_pick BOOLEAN NOT NULL DEFAULT false,
  tags TEXT[] DEFAULT '{}',
  views INTEGER NOT NULL DEFAULT 0,
  reading_time_minutes INTEGER NOT NULL DEFAULT 3,
  rejection_reason TEXT,
  published_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_articles_status ON public.articles(status);
CREATE INDEX IF NOT EXISTS idx_articles_category ON public.articles(category_id);
CREATE INDEX IF NOT EXISTS idx_articles_published ON public.articles(published_at DESC);

-- ==============================================================================
-- 7. TABEL MEDIA GALERI GAMBAR
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.media (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  url TEXT NOT NULL,
  original_size INTEGER NOT NULL DEFAULT 0,
  compressed_size INTEGER NOT NULL DEFAULT 0,
  mime_type TEXT NOT NULL DEFAULT 'image/jpeg',
  width INTEGER NOT NULL DEFAULT 1200,
  height INTEGER NOT NULL DEFAULT 800,
  uploaded_by UUID REFERENCES public.users(id) ON DELETE SET NULL,
  uploaded_by_name TEXT NOT NULL DEFAULT 'Redaksi',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 8. TABEL IKLAN BANNER
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.advertisements (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  position TEXT NOT NULL CHECK (position IN ('header', 'sidebar', 'in_feed', 'popup')),
  image_url TEXT NOT NULL,
  link_url TEXT NOT NULL DEFAULT '#',
  is_active BOOLEAN NOT NULL DEFAULT true,
  impressions INTEGER NOT NULL DEFAULT 0,
  clicks INTEGER NOT NULL DEFAULT 0,
  start_date DATE NOT NULL DEFAULT CURRENT_DATE,
  end_date DATE NOT NULL DEFAULT (CURRENT_DATE + INTERVAL '1 year'),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 9. TABEL PENGATURAN IDENTITAS WEBSITE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.site_settings (
  id TEXT PRIMARY KEY DEFAULT 'primary',
  site_name TEXT NOT NULL DEFAULT 'PAMANUKAN NEWS',
  tagline TEXT NOT NULL,
  running_text TEXT,
  contact_email TEXT,
  contact_phone TEXT,
  address TEXT,
  facebook TEXT,
  twitter TEXT,
  instagram TEXT,
  youtube TEXT,
  enable_push_notification BOOLEAN DEFAULT true,
  enable_ai_search BOOLEAN DEFAULT true,
  seo_description TEXT,
  seo_keywords TEXT,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 10. TABEL KOMENTAR PEMBACA
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public.comments (
  id TEXT PRIMARY KEY,
  article_id TEXT REFERENCES public.articles(id) ON DELETE CASCADE,
  author_name TEXT NOT NULL,
  author_avatar TEXT,
  content TEXT NOT NULL,
  likes INTEGER NOT NULL DEFAULT 0,
  is_verified BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 11. ROW LEVEL SECURITY (RLS) - OTORISASI AKSES AMAN
-- ==============================================================================
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.articles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.media ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.advertisements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;

-- Kebijakan Users:
CREATE POLICY "users_read_all" ON public.users FOR SELECT USING (true);
CREATE POLICY "users_admin_manage" ON public.users FOR ALL USING (public.is_admin());
CREATE POLICY "users_update_own" ON public.users FOR UPDATE USING (id = auth.uid());

-- Kebijakan Articles:
CREATE POLICY "articles_read_public" ON public.articles FOR SELECT 
  USING (status = 'published' OR public.is_admin() OR (public.is_publisher() AND author_id = auth.uid()));

CREATE POLICY "articles_admin_all" ON public.articles FOR ALL 
  USING (public.is_admin());

CREATE POLICY "articles_publisher_insert" ON public.articles FOR INSERT 
  WITH CHECK (public.is_publisher() AND (author_id = auth.uid() OR author_id IS NULL));

CREATE POLICY "articles_publisher_update" ON public.articles FOR UPDATE 
  USING (public.is_publisher() AND author_id = auth.uid());

CREATE POLICY "articles_publisher_delete" ON public.articles FOR DELETE 
  USING (public.is_publisher() AND author_id = auth.uid() AND status IN ('draft', 'rejected'));

-- Kebijakan Categories:
CREATE POLICY "categories_read_all" ON public.categories FOR SELECT USING (true);
CREATE POLICY "categories_admin_all" ON public.categories FOR ALL USING (public.is_admin());

-- Kebijakan Media:
CREATE POLICY "media_read_all" ON public.media FOR SELECT USING (true);
CREATE POLICY "media_admin_all" ON public.media FOR ALL USING (public.is_admin());
CREATE POLICY "media_publisher_upload" ON public.media FOR INSERT WITH CHECK (public.is_publisher() OR public.is_admin());

-- Kebijakan Iklan & Settings:
CREATE POLICY "ads_read_public" ON public.advertisements FOR SELECT USING (is_active = true OR public.is_admin());
CREATE POLICY "ads_admin_all" ON public.advertisements FOR ALL USING (public.is_admin());

CREATE POLICY "settings_read_all" ON public.site_settings FOR SELECT USING (true);
CREATE POLICY "settings_admin_all" ON public.site_settings FOR ALL USING (public.is_admin());

-- Kebijakan Komentar:
CREATE POLICY "comments_read_all" ON public.comments FOR SELECT USING (true);
CREATE POLICY "comments_insert_public" ON public.comments FOR INSERT WITH CHECK (true);
CREATE POLICY "comments_admin_manage" ON public.comments FOR ALL USING (public.is_admin());

-- ==============================================================================
-- 12. DATA AWAL (SEED DATA): KATEGORI, PENGATURAN & BERITA RESMI PAMANUKAN
-- ==============================================================================

-- A. Inisialisasi Pengaturan Website
INSERT INTO public.site_settings (
  id, site_name, tagline, running_text, contact_email, contact_phone, address,
  enable_push_notification, enable_ai_search, seo_description, seo_keywords
) VALUES (
  'primary',
  'PAMANUKAN NEWS',
  'Portal Berita Terpercaya Pantura Subang & Pelabuhan Patimban',
  'PAMANUKAN NEWS • Arus Lalu Lintas Pantura Terpantau Lancar • Operasional Dermaga Kontainer Patimban Berjalan Normal • Cuaca Pamanukan Berawan',
  'redaksi@pamanukannews.com',
  '+62 812-3456-7890',
  'Jl. Raya Pamanukan No. 88, Subang, Jawa Barat 41254',
  true,
  true,
  'Portal berita digital akurat seputar Pamanukan, Subang, Pelabuhan Patimban, dan wilayah Pantura Jawa Barat.',
  'pamanukan, berita subang, pelabuhan patimban, pantura, jawa barat'
) ON CONFLICT (id) DO UPDATE SET updated_at = NOW();

-- B. Inisialisasi Rubrik Kategori Berita
INSERT INTO public.categories (id, name, slug, color, icon_name, "order", is_active)
VALUES
  ('cat-pamanukan', 'Pamanukan', 'pamanukan', '#dc2626', 'MapPin', 1, true),
  ('cat-subang', 'Subang Raya', 'subang-raya', '#2563eb', 'Building2', 2, true),
  ('cat-patimban', 'Patimban & Industri', 'patimban-industri', '#059669', 'Ship', 3, true),
  ('cat-pantura', 'Arus Pantura', 'arus-pantura', '#d97706', 'Truck', 4, true),
  ('cat-pertanian', 'Tani & Nelayan', 'tani-nelayan', '#16a34a', 'Wheat', 5, true),
  ('cat-wisata', 'Wisata & Kuliner', 'wisata-kuliner', '#9333ea', 'Utensils', 6, true),
  ('cat-hukum', 'Hukum & Kriminal', 'hukum-kriminal', '#475569', 'Scale', 7, true),
  ('cat-opini', 'Opini & Budaya', 'opini-budaya', '#ca8a04', 'BookOpen', 8, true)
ON CONFLICT (id) DO NOTHING;

-- C. Inisialisasi Artikel Berita Unggulan
INSERT INTO public.articles (
  id, title, slug, summary, content, category_id, category_name, cover_image,
  author_name, author_avatar, status, is_headline, is_featured, is_editor_pick,
  tags, views, reading_time_minutes, published_at
) VALUES
(
  'art-patimban-exp-2026',
  'Ekspor Kendaraan Pelabuhan Internasional Patimban Tembus Rekor Baru di Kuartal I',
  'ekspor-kendaraan-pelabuhan-internasional-patimban-tembus-rekor-baru-di-kuartal-i',
  'Aktivitas bongkar muat kendaraan CBU dan kargo ekspor di Pelabuhan Patimban Subang melonjak signifikan seiring optimalisasi akses jalan tol dan jaringan logistik terpadu Pantura.',
  'Aktivitas bongkar muat kendaraan utuh (Completely Built Up/CBU) dan peti kemas logistik di Pelabuhan Internasional Patimban, Kabupaten Subang, mencatatkan tonggak sejarah baru sepanjang kuartal pertama tahun ini. Berdasarkan rilis otoritas pelabuhan, volume ekspor melonjak lebih dari tiga puluh lima persen dibanding periode tahun sebelumnya. Lonjakan ini ditopang oleh percepatan integrasi rantai pasok industri otomotif dari koridor Bekasi, Karawang, dan Purwakarta yang kini langsung dialirkan melalui jalur tol akses Patimban tanpa membebani jalur Tanjung Priok.

Kepala Kantor Kesyahbandaran dan Otoritas Pelabuhan (KSOP) Patimban menyampaikan bahwa perluasan dermaga mobil tahap lanjutan berkapasitas ratusan ribu unit per tahun kini telah beroperasi dengan kapasitas penuh. Digitalisasi izin sandar kapal serta integrasi sistem Bea Cukai membuat waktu tunggu kapal (port stay) terpangkas hingga di bawah 24 jam.

Masyarakat pesisir utara Subang, khususnya wilayah Pusakanagara dan Pamanukan, merasakan dampak positif berupa tumbuhnya sentra pergudangan, layanan ekspedisi, serta penyerapan tenaga kerja lokal bersertifikasi maritim.',
  'cat-patimban',
  'Patimban & Industri',
  'https://images.unsplash.com/photo-1578575437130-527eed3abbec?w=1200&auto=format&fit=crop&q=80',
  'Ahmad Fauzi Pantura',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
  'published',
  true,
  true,
  true,
  ARRAY['Patimban', 'Ekspor', 'Subang', 'Pelabuhan', 'Otomotif'],
  3842,
  4,
  NOW() - INTERVAL '2 hours'
),
(
  'art-fluvial-pamanukan-tanggul',
  'BBWS Citarum Tuntaskan Normalisasi dan Perkuatan Tanggul Kritis Sungai Cipunagara Pamanukan',
  'bbws-citarum-tuntaskan-normalisasi-dan-perkuatan-tanggul-kritis-sungai-cipunagara-pamanukan',
  'Upaya mitigasi banjir menahun di Pamanukan menunjukkan progres nyata setelah perkuatan parapet beton dan pengerukan sedimentasi sepanjang 12 kilometer dinyatakan rampung.',
  'Balai Besar Wilayah Sungai (BBWS) Citarum bersama Dinas Pekerjaan Umum dan Penataan Ruang (PUPR) Kabupaten Subang merampungkan proyek vital perkuatan tanggul kritis dan normalisasi sedimentasi Sungai Cipunagara di kawasan hilir Pamanukan. Proyek infrastruktur pencegahan banjir ini menargetkan pengamanan kawasan permukiman padat, sentra pasar Pamanukan, serta jalur vital Jalan Nasional Pantura dari ancaman luapan air pasang air laut (rob) dan kiriman hulu.

Pemasangan sheet pile baja dan dinding parapet beton setinggi 1,8 meter di titik rawan Karangmulya dan Mulyasari telah terbukti efektif menahan kenaikan debit air kiriman selama musim penghujan belakangan ini. Selain itu, pintu-pintu air otomatis dan stasiun pompa berkapasitas debit tinggi telah disiagakan dengan pasokan genset cadangan guna mengantisipasi gangguan kelistrikan.

Warga dan tokoh pedagang Pasar Inpres Pamanukan menyambut antusias penyelesaian pekerjaan ini, yang diharapkan mampu mengakhiri trauma genangan air yang selama puluhan tahun kerap melumpuhkan urat nadi perdagangan Pantura.',
  'cat-pamanukan',
  'Pamanukan',
  'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=1200&auto=format&fit=crop&q=80',
  'Budi Santoso, M.I.Kom',
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  'published',
  false,
  true,
  true,
  ARRAY['Pamanukan', 'Tanggul', 'Cipunagara', 'Banjir', 'Infrastruktur'],
  2190,
  3,
  NOW() - INTERVAL '6 hours'
),
(
  'art-panen-raya-padi-organik',
  'Petani Pantura Subang Raih Rekor Panen Padi Organik 9 Ton per Hektare',
  'petani-pantura-subang-raih-rekor-panen-padi-organik-9-ton-per-hektare',
  'Penerapan pupuk hayati lokal dan modernisasi alsintan di sentra sawah irigasi teknis Pamanukan berhasil meningkatkan hasil panen gabah kering panen.',
  'Kelompok Tani Tunas Makmur di wilayah Pamanukan Hilir berhasil mencatatkan produktivitas panen padi ramah lingkungan mencapai sembilan ton gabah kering panen (GKP) per hektare. Angka ini melampaui rata-rata produktivitas nasional dan menegaskan kembali reputasi Kabupaten Subang sebagai lumbung pangan utama Jawa Barat dan nasional.

Keberhasilan ini didorong oleh pendampingan penyuluh pertanian lapangan dalam menerapkan varietas unggul tahan hama wereng batang coklat serta pemanfaatan pupuk hayati berbasis mikroba lokal yang mampu memulihkan kesuburan tanah sawah yang sebelumnya jenuh kimia.

Dinas Ketahanan Pangan Subang memastikan Bulog siap menyerap hasil panen para petani dengan harga acuan pembelian pemerintah yang menguntungkan, sehingga stabilitas pendapatan petani Pantura tetap terjaga menjelang akhir tahun.',
  'cat-pertanian',
  'Tani & Nelayan',
  'https://images.unsplash.com/photo-1500937386664-56d1dfef3854?w=1200&auto=format&fit=crop&q=80',
  'Rian Hidayatulloh',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
  'published',
  false,
  false,
  true,
  ARRAY['Pertanian', 'Padi', 'Subang', 'Pangan', 'Petani'],
  1450,
  3,
  NOW() - INTERVAL '12 hours'
)
ON CONFLICT (id) DO NOTHING;

-- D. Inisialisasi Iklan Banner Display
INSERT INTO public.advertisements (
  id, title, position, image_url, link_url, is_active, impressions, clicks, start_date, end_date
) VALUES
(
  'ad-patimban-logistik',
  'Kawasan Pergudangan Terpadu Patimban Logistics Hub',
  'header',
  'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=1200&auto=format&fit=crop&q=80',
  'https://pamanukannews.com',
  true,
  12500,
  430,
  CURRENT_DATE,
  CURRENT_DATE + INTERVAL '1 year'
),
(
  'ad-subang-smart-politan',
  'Investasi Properti Strategis Subang Smartpolitan',
  'sidebar',
  'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=600&auto=format&fit=crop&q=80',
  'https://pamanukannews.com',
  true,
  8900,
  210,
  CURRENT_DATE,
  CURRENT_DATE + INTERVAL '1 year'
)
ON CONFLICT (id) DO NOTHING;
