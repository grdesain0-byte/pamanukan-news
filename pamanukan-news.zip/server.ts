import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const isProd = process.env.NODE_ENV === 'production';

app.use(express.json({ limit: '10mb' }));

// Shared Gemini Client
let geminiClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  geminiClient = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health check
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    portal: 'PAMANUKAN NEWS',
    hasGemini: !!process.env.GEMINI_API_KEY,
    time: new Date().toISOString(),
  });
});

// AI Smart Search & Archive Explorer Endpoint
app.post('/api/ai/search', async (req, res) => {
  try {
    const { query, articles } = req.body;
    if (!query) {
      return res.status(400).json({ error: 'Query is required' });
    }

    if (!geminiClient) {
      // Graceful fallback when no key is present: heuristic match
      const q = String(query).toLowerCase();
      const matched = (articles || []).filter((a: any) =>
        a.title.toLowerCase().includes(q) ||
        a.summary.toLowerCase().includes(q) ||
        (a.tags && a.tags.some((t: string) => t.toLowerCase().includes(q))) ||
        (a.category && a.category.toLowerCase().includes(q))
      );

      return res.json({
        aiSummary: `Ditemukan ${matched.length} artikel di arsip Pamanukan News yang berkaitan dengan "${query}".`,
        recommendedArticleIds: matched.slice(0, 5).map((m: any) => m.id),
        keyInsights: [
          `Pencarian lokal arsip Pantura untuk topik "${query}"`,
          'Data diperbarui secara real-time dari ruang redaksi',
        ],
        suggestedFollowUps: [
          `Berita terkini seputar ${query}`,
          `Kebijakan Pemkab Subang terkait ${query}`,
          `Dampak ekonomi bagi warga Pamanukan`,
        ],
      });
    }

    const simplifiedArticles = (articles || []).slice(0, 20).map((a: any) => ({
      id: a.id,
      title: a.title,
      category: a.category,
      summary: a.summary,
      tags: a.tags,
      date: a.publishedAt || a.createdAt,
    }));

    const prompt = `Anda adalah Asisten Redaksi & Analis Arsip Berita PAMANUKAN NEWS (Portal Berita Terdepan Pantura Subang).
Tugas Anda adalah memproses kueri pencarian pembaca: "${query}".

Berikut adalah katalog arsip berita yang tersedia:
${JSON.stringify(simplifiedArticles, null, 2)}

Berikan respon JSON valid dengan struktur:
{
  "aiSummary": "Rangkuman cerdas 2-3 kalimat berbahasa Indonesia tentang informasi terkait kueri berdasarkan arsip berita di atas",
  "recommendedArticleIds": ["id1", "id2"],
  "keyInsights": ["Poin insight 1", "Poin insight 2", "Poin insight 3"],
  "suggestedFollowUps": ["Pertanyaan atau topik terkait yang mungkin dicari pembaca 1", "Topik terkait 2"]
}
Prioritaskan artikel yang paling relevan dengan konteks Pamanukan, Subang, dan Pantura. Pastikan output hanya JSON murni tanpa markdown formatting.`;

    const response = await geminiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '{}';
    const parsed = JSON.parse(text);
    return res.json(parsed);
  } catch (error: any) {
    console.error('Error in /api/ai/search:', error);
    return res.status(500).json({
      error: 'Gagal memproses pencarian AI',
      details: error.message,
    });
  }
});

// AI Assistant for Journalists / Editors
app.post('/api/ai/assist', async (req, res) => {
  try {
    const { action, title, content, category } = req.body;

    if (!geminiClient) {
      // Mock fallback
      if (action === 'suggest_title') {
        return res.json({
          suggestions: [
            `${title || 'Berita Utama'}: Terobosan Baru di Kawasan Pantura Subang`,
            `Update Pamanukan: ${title || 'Liputan Khusus'} Menarik Perhatian Warga`,
            `Dinamika Terkini: Analisis Mendalam ${title || 'Perkembangan Wilayah'}`,
          ],
        });
      }
      return res.json({
        result: 'Fitur AI Redaksi aktif. Silakan hubungkan API key untuk generasi teks cerdas.',
      });
    }

    let prompt = '';
    if (action === 'suggest_title') {
      prompt = `Buatkan 5 rekomendasi judul berita gaya jurnalistik modern, lugas, menarik, anti-clickbait untuk portal berita PAMANUKAN NEWS.
Kategori: ${category || 'Umum'}
Topik/Konten: ${title} ${content ? `- ${content.substring(0, 300)}` : ''}
Keluarkan hanya JSON format:
{
  "suggestions": ["Judul 1", "Judul 2", "Judul 3", "Judul 4", "Judul 5"]
}`;
    } else if (action === 'generate_summary') {
      prompt = `Buat ringkasan berita 2 kalimat (lead berita) yang padat, akurat (memenuhi unsur 5W+1H) untuk portal PAMANUKAN NEWS.
Judul: ${title}
Konten Lengkap: ${content}
Keluarkan hanya JSON:
{
  "summary": "Teks ringkasan padat dan menarik"
}`;
    } else if (action === 'extract_tags') {
      prompt = `Ekstrak 6 tag/kata kunci SEO populer untuk artikel berita berikut.
Judul: ${title}
Konten: ${content ? content.substring(0, 500) : ''}
Keluarkan hanya JSON:
{
  "tags": ["tag1", "tag2", "tag3", "tag4", "tag5", "tag6"]
}`;
    } else {
      prompt = `Periksa dan sempurnakan tata bahasa (proofreading) draft berita berikut sesuai kaidah jurnalistik bahasa Indonesia (EYD V & PUEBI).
Judul: ${title}
Konten: ${content}
Keluarkan hanya JSON:
{
  "enhancedTitle": "Judul yang disempurnakan",
  "enhancedContent": "Konten yang telah dirapikan",
  "improvements": ["Catatan perbaikan 1", "Catatan perbaikan 2"]
}`;
    }

    const response = await geminiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);
  } catch (error: any) {
    console.error('Error in /api/ai/assist:', error);
    return res.status(500).json({ error: 'AI assist failed', details: error.message });
  }
});

// Setup Vite or Static File Serving
async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`[PAMANUKAN NEWS SERVER] Running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
