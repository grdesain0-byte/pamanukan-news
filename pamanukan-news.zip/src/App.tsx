import React, { useState } from 'react';
import { NewsProvider, useNews } from './context/NewsContext';
import { Header } from './components/common/Header';
import { CategoryNav } from './components/portal/CategoryNav';
import { HeroSection } from './components/portal/HeroSection';
import { NewsFeed } from './components/portal/NewsFeed';
import { Sidebar } from './components/portal/Sidebar';
import { Footer } from './components/portal/Footer';
import { ArticleDetailModal } from './components/portal/ArticleDetailModal';
import { AiSearchModal } from './components/portal/AiSearchModal';
import { DashboardLayout } from './components/dashboard/DashboardLayout';
import { ToastContainer } from './components/common/ToastContainer';
import { AuthModal } from './components/common/AuthModal';

const MainApp: React.FC = () => {
  const { articles } = useNews();

  // Navigation & Modal States
  const [currentView, setCurrentView] = useState<'portal' | 'dashboard'>('portal');
  const [dashboardTab, setDashboardTab] = useState<string>('analitik');
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('all');
  const [selectedArticleId, setSelectedArticleId] = useState<string | null>(null);
  const [isAiSearchOpen, setIsAiSearchOpen] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalRole, setAuthModalRole] = useState<'admin' | 'publisher'>('admin');
  const [portalSearchQuery, setPortalSearchQuery] = useState<string>('');

  const handleOpenAiSearch = () => {
    setIsAiSearchOpen(true);
  };

  const handleOpenAuthModal = (role: 'admin' | 'publisher' = 'admin') => {
    setAuthModalRole(role);
    setIsAuthModalOpen(true);
  };

  const handleSelectArticle = (id: string) => {
    setSelectedArticleId(id);
  };

  const handleNavigateToDashboard = (tab = 'analitik') => {
    setDashboardTab(tab);
    setCurrentView('dashboard');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateToPortal = () => {
    setCurrentView('portal');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
      {/* Toast Alert System */}
      <ToastContainer />

      {/* Global Auth Modal for Admin & Publisher */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        defaultRole={authModalRole}
        onSuccess={(targetRole) => {
          setIsAuthModalOpen(false);
          handleNavigateToDashboard(targetRole === 'admin' ? 'analitik' : 'tulis');
        }}
      />

      {/* Global AI Search Modal */}
      <AiSearchModal
        isOpen={isAiSearchOpen}
        onClose={() => setIsAiSearchOpen(false)}
        onSelectArticle={handleSelectArticle}
      />

      {/* Article Detail Reading Modal */}
      {selectedArticleId && (
        <ArticleDetailModal
          articleId={selectedArticleId}
          onClose={() => setSelectedArticleId(null)}
          onSelectArticle={handleSelectArticle}
        />
      )}

      {currentView === 'dashboard' ? (
        <DashboardLayout
          initialTab={dashboardTab}
          onNavigateToPortal={handleNavigateToPortal}
          onPreviewArticle={handleSelectArticle}
          onOpenAuthModal={() => handleOpenAuthModal('admin')}
        />
      ) : (
        <>
          {/* Public Portal Header */}
          <Header
            onOpenAiSearch={handleOpenAiSearch}
            onNavigateToDashboard={handleNavigateToDashboard}
            onSelectArticle={handleSelectArticle}
            currentView={currentView}
            onNavigateToPortal={handleNavigateToPortal}
            onOpenAuthModal={(role) => handleOpenAuthModal(role || 'admin')}
          />

          {/* Sticky Category Navbar */}
          <CategoryNav
            selectedCategoryId={selectedCategoryId}
            onSelectCategory={(id) => {
              setSelectedCategoryId(id);
              setPortalSearchQuery('');
            }}
          />

          {/* Hero Section (only when on 'all' and no active text search) */}
          {selectedCategoryId === 'all' && !portalSearchQuery && (
            <HeroSection
              articles={articles}
              onSelectArticle={handleSelectArticle}
            />
          )}

          {/* Main Feed & Sidebar Content Layout */}
          <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 flex-1 w-full">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Primary News Stream (8 cols) */}
              <div className="lg:col-span-8">
                <NewsFeed
                  selectedCategoryId={selectedCategoryId}
                  onSelectArticle={handleSelectArticle}
                  searchQuery={portalSearchQuery}
                />
              </div>

              {/* Editorial & Community Sidebar (4 cols) */}
              <div className="lg:col-span-4">
                <Sidebar onSelectArticle={handleSelectArticle} />
              </div>
            </div>
          </main>

          {/* Public Portal Footer */}
          <Footer
            onNavigateToDashboard={() => handleNavigateToDashboard('analitik')}
            onOpenAuthModal={() => handleOpenAuthModal('admin')}
            onSelectCategory={(id) => {
              setSelectedCategoryId(id);
              window.scrollTo({ top: 300, behavior: 'smooth' });
            }}
          />
        </>
      )}
    </div>
  );
};

export default function App() {
  return (
    <NewsProvider>
      <MainApp />
    </NewsProvider>
  );
}
