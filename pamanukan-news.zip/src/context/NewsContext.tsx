import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import {
  User,
  UserRole,
  Category,
  Article,
  Advertisement,
  MediaItem,
  SiteSettings,
  NotificationItem,
  SupabaseConfig,
} from '../types';
import {
  INITIAL_USERS,
  INITIAL_CATEGORIES,
  INITIAL_ARTICLES,
  INITIAL_ADS,
  INITIAL_SITE_SETTINGS,
  INITIAL_MEDIA,
  INITIAL_NOTIFICATIONS,
} from '../data/initialData';
import {
  getStoredSupabaseConfig,
  saveStoredSupabaseConfig,
  getSupabaseClient,
  resetSupabaseClient,
  testSupabaseConnection,
  signInWithSupabase,
  signUpWithSupabase,
  signOutFromSupabase,
  getSupabaseCurrentSession,
  subscribeToSupabaseAuth,
} from '../services/supabaseService';
import { playNotificationChime } from '../utils/audioChime';

interface ToastAlert {
  id: string;
  title: string;
  message: string;
  type: 'success' | 'info' | 'warning' | 'alert';
}

interface NewsContextType {
  currentUser: User;
  allUsers: User[];
  categories: Category[];
  articles: Article[];
  mediaItems: MediaItem[];
  advertisements: Advertisement[];
  siteSettings: SiteSettings;
  notifications: NotificationItem[];
  unreadNotifCount: number;
  supabaseConfig: SupabaseConfig;
  isDarkMode: boolean;
  activeToast: ToastAlert | null;
  pushSubscriptionActive: boolean;

  // Supabase Auth
  supabaseAuthUser: any | null;
  isSupabaseAuthActive: boolean;
  loginWithSupabaseAuth: (email: string, password: string) => Promise<{ success: boolean; error?: string; role?: UserRole }>;
  registerWithSupabaseAuth: (email: string, password: string, name: string, role: 'admin' | 'publisher') => Promise<{ success: boolean; error?: string }>;
  logoutSupabaseAuth: () => Promise<void>;

  // Role & Users
  switchUserRole: (role: UserRole) => void;
  setCurrentUser: (user: User) => void;
  addUser: (userData: Omit<User, 'id' | 'createdAt'>) => void;
  updateUser: (id: string, updates: Partial<User>) => void;
  deleteUser: (id: string) => void;

  // Articles & Workflow
  createArticle: (data: Partial<Article>) => Article;
  updateArticle: (id: string, updates: Partial<Article>) => void;
  submitArticleForReview: (id: string) => void;
  approveAndPublishArticle: (id: string) => void;
  rejectArticle: (id: string, reason: string) => void;
  deleteArticle: (id: string) => void;
  incrementArticleViews: (id: string) => void;

  // Media
  addMediaItem: (data: Omit<MediaItem, 'id' | 'createdAt'>) => MediaItem;
  deleteMediaItem: (id: string) => void;

  // Categories
  addCategory: (data: Omit<Category, 'id'>) => void;
  updateCategory: (id: string, updates: Partial<Category>) => void;
  deleteCategory: (id: string) => void;

  // Advertisements
  addAd: (data: Omit<Advertisement, 'id' | 'impressions' | 'clicks'>) => void;
  updateAd: (id: string, updates: Partial<Advertisement>) => void;
  deleteAd: (id: string) => void;
  recordAdClick: (id: string) => void;

  // Settings
  updateSiteSettings: (updates: Partial<SiteSettings>) => void;

  // Notifications
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  sendNotification: (notif: Omit<NotificationItem, 'id' | 'createdAt' | 'isRead'>) => void;
  togglePushNotifications: () => Promise<boolean>;

  // Theme
  toggleDarkMode: () => void;

  // Supabase
  updateSupabaseConfig: (config: SupabaseConfig) => void;
  testSupabase: (url: string, key: string) => Promise<{ success: boolean; message: string }>;
  syncWithSupabase: () => Promise<{ success: boolean; message: string }>;
  resetToDefaultData: () => void;
}

const NewsContext = createContext<NewsContextType | undefined>(undefined);

const STORAGE_KEYS = {
  USERS: 'pn_users_v1',
  CATEGORIES: 'pn_categories_v1',
  ARTICLES: 'pn_articles_v1',
  MEDIA: 'pn_media_v1',
  ADS: 'pn_ads_v1',
  SETTINGS: 'pn_settings_v1',
  NOTIFICATIONS: 'pn_notifs_v1',
  CURRENT_USER_ID: 'pn_current_user_id_v1',
  DARK_MODE: 'pn_dark_mode_v1',
  PUSH_SUB: 'pn_push_sub_v1',
};

export const NewsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // 1. Initial State Loaders with local storage fallback
  const [allUsers, setAllUsers] = useState<User[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.USERS);
      return saved ? JSON.parse(saved) : INITIAL_USERS;
    } catch {
      return INITIAL_USERS;
    }
  });

  const [currentUser, setCurrentUser] = useState<User>(() => {
    try {
      const currentId = localStorage.getItem(STORAGE_KEYS.CURRENT_USER_ID);
      const found = allUsers.find((u) => u.id === currentId);
      return found || allUsers[0];
    } catch {
      return allUsers[0];
    }
  });

  const [categories, setCategories] = useState<Category[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
      return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
    } catch {
      return INITIAL_CATEGORIES;
    }
  });

  const [articles, setArticles] = useState<Article[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ARTICLES);
      return saved ? JSON.parse(saved) : INITIAL_ARTICLES;
    } catch {
      return INITIAL_ARTICLES;
    }
  });

  const [mediaItems, setMediaItems] = useState<MediaItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.MEDIA);
      return saved ? JSON.parse(saved) : INITIAL_MEDIA;
    } catch {
      return INITIAL_MEDIA;
    }
  });

  const [advertisements, setAdvertisements] = useState<Advertisement[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ADS);
      return saved ? JSON.parse(saved) : INITIAL_ADS;
    } catch {
      return INITIAL_ADS;
    }
  });

  const [siteSettings, setSiteSettings] = useState<SiteSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      return saved ? JSON.parse(saved) : INITIAL_SITE_SETTINGS;
    } catch {
      return INITIAL_SITE_SETTINGS;
    }
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
      return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
    } catch {
      return INITIAL_NOTIFICATIONS;
    }
  });

  const [supabaseConfig, setSupabaseConfig] = useState<SupabaseConfig>(() =>
    getStoredSupabaseConfig()
  );

  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.DARK_MODE);
      if (saved !== null) return JSON.parse(saved);
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch {
      return false;
    }
  });

  const [pushSubscriptionActive, setPushSubscriptionActive] = useState<boolean>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.PUSH_SUB) === 'true';
    } catch {
      return false;
    }
  });

  const [activeToast, setActiveToast] = useState<ToastAlert | null>(null);
  const [supabaseAuthUser, setSupabaseAuthUser] = useState<any | null>(null);

  // Check Supabase session on mount & subscribe to changes
  useEffect(() => {
    getSupabaseCurrentSession().then((session) => {
      if (session?.user) {
        setSupabaseAuthUser(session.user);
      }
    });

    const { unsubscribe } = subscribeToSupabaseAuth((event, session) => {
      if (session?.user) {
        setSupabaseAuthUser(session.user);
        const role = (session.user.user_metadata?.role ||
          (session.user.email?.includes('pemred') || session.user.email?.includes('admin') ? 'admin' : 'publisher')) as UserRole;
        const existing = allUsers.find((u) => u.email === session.user.email);
        if (existing) {
          setCurrentUser(existing);
        } else {
          const newUser: User = {
            id: session.user.id,
            name: session.user.user_metadata?.name || session.user.email?.split('@')[0] || 'User Supabase',
            email: session.user.email || '',
            role,
            status: 'active',
            avatar: `https://images.unsplash.com/photo-${role === 'admin' ? '1534528741775-53994a69daeb' : '1507003211169-0a1dd7228f2d'}?w=150&auto=format&fit=crop&q=80`,
            articlesCount: 0,
            createdAt: session.user.created_at || new Date().toISOString(),
          };
          setAllUsers((prev) => (prev.some((u) => u.id === newUser.id) ? prev : [newUser, ...prev]));
          setCurrentUser(newUser);
        }
      } else if (event === 'SIGNED_OUT') {
        setSupabaseAuthUser(null);
      }
    });

    return () => {
      unsubscribe();
    };
  }, [allUsers]);

  // Initial fetch from Supabase for live data (articles, categories, site_settings)
  useEffect(() => {
    const client = getSupabaseClient();
    if (!client) return;

    // 1. Fetch live articles
    client
      .from('articles')
      .select('*')
      .order('created_at', { ascending: false })
      .then(({ data, error }) => {
        if (!error && data && data.length > 0) {
          const mapped: Article[] = data.map((ra: any) => ({
            id: ra.id,
            title: ra.title,
            slug: ra.slug,
            summary: ra.summary,
            content: ra.content,
            categoryId: ra.category_id,
            categoryName: ra.category_name,
            coverImage: ra.cover_image,
            authorId: ra.author_id,
            authorName: ra.author_name,
            authorAvatar: ra.author_avatar,
            status: ra.status,
            isHeadline: ra.is_headline,
            isFeatured: ra.is_featured,
            isEditorPick: ra.is_editor_pick,
            tags: ra.tags || [],
            views: ra.views || 0,
            readingTimeMinutes: ra.reading_time_minutes || 3,
            publishedAt: ra.published_at || '',
            createdAt: ra.created_at,
            updatedAt: ra.updated_at,
            rejectionReason: ra.rejection_reason,
            commentsCount: 0,
            sharesCount: 0,
          }));
          setArticles(mapped);
        }
      });

    // 2. Fetch live categories
    client
      .from('categories')
      .select('*')
      .order('order', { ascending: true })
      .then(({ data, error }) => {
        if (!error && data && data.length > 0) {
          const mapped: Category[] = data.map((c: any) => ({
            id: c.id,
            name: c.name,
            slug: c.slug,
            color: c.color || '#dc2626',
            order: c.order || 0,
            isActive: c.is_active ?? true,
            count: 0,
          }));
          setCategories(mapped);
        }
      });

    // 3. Fetch live site settings
    client
      .from('site_settings')
      .select('*')
      .eq('id', 'primary')
      .maybeSingle()
      .then(({ data, error }) => {
        if (!error && data) {
          setSiteSettings((prev) => ({
            ...prev,
            siteName: data.site_name || prev.siteName,
            tagline: data.tagline || prev.tagline,
            runningText: data.running_text || prev.runningText,
            contactEmail: data.contact_email || prev.contactEmail,
            contactPhone: data.contact_phone || prev.contactPhone,
            address: data.address || prev.address,
            enablePushNotification: data.enable_push_notification ?? prev.enablePushNotification,
            enableAiSearch: data.enable_ai_search ?? prev.enableAiSearch,
            seoDescription: data.seo_description || prev.seoDescription,
            seoKeywords: data.seo_keywords || prev.seoKeywords,
          }));
        }
      });

    // 4. Fetch live advertisements
    client
      .from('advertisements')
      .select('*')
      .then(({ data, error }) => {
        if (!error && data && data.length > 0) {
          const mapped: Advertisement[] = data.map((ad: any) => ({
            id: ad.id,
            title: ad.title,
            position: ad.position,
            imageUrl: ad.image_url,
            linkUrl: ad.link_url,
            isActive: ad.is_active,
            impressions: ad.impressions || 0,
            clicks: ad.clicks || 0,
            startDate: ad.start_date,
            endDate: ad.end_date,
          }));
          setAdvertisements(mapped);
        }
      });

    // 5. Fetch live media
    client
      .from('media')
      .select('*')
      .order('created_at', { ascending: false })
      .then(({ data, error }) => {
        if (!error && data && data.length > 0) {
          const mapped: MediaItem[] = data.map((m: any) => ({
            id: m.id,
            name: m.name,
            url: m.url,
            originalSize: m.original_size || 0,
            compressedSize: m.compressed_size || 0,
            mimeType: m.mime_type || 'image/jpeg',
            width: m.width || 1200,
            height: m.height || 800,
            uploadedBy: m.uploaded_by || 'redaksi',
            uploadedByName: m.uploaded_by_name || 'Redaksi',
            createdAt: m.created_at || new Date().toISOString(),
          }));
          setMediaItems(mapped);
        }
      });
  }, [supabaseConfig]);

  // Sync dark mode class on HTML document
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem(STORAGE_KEYS.DARK_MODE, JSON.stringify(isDarkMode));
  }, [isDarkMode]);

  // Persistence effects
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(allUsers));
  }, [allUsers]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ARTICLES, JSON.stringify(articles));
  }, [articles]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MEDIA, JSON.stringify(mediaItems));
  }, [mediaItems]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ADS, JSON.stringify(advertisements));
  }, [advertisements]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(siteSettings));
  }, [siteSettings]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER_ID, currentUser.id);
  }, [currentUser]);

  // Toast Helper
  const showToast = useCallback((title: string, message: string, type: ToastAlert['type'] = 'info') => {
    const alert: ToastAlert = {
      id: Date.now().toString(),
      title,
      message,
      type,
    };
    setActiveToast(alert);
    playNotificationChime();
    setTimeout(() => {
      setActiveToast((current) => (current?.id === alert.id ? null : current));
    }, 4500);
  }, []);

  // Send Notification
  const sendNotification = useCallback(
    (notif: Omit<NotificationItem, 'id' | 'createdAt' | 'isRead'>) => {
      const newNotif: NotificationItem = {
        ...notif,
        id: `notif-${Date.now()}`,
        createdAt: new Date().toISOString(),
        isRead: false,
      };

      setNotifications((prev) => [newNotif, ...prev]);
      showToast(notif.title, notif.message, notif.type === 'breaking_news' ? 'alert' : 'info');

      // Native browser notification if enabled
      if (pushSubscriptionActive && 'Notification' in window && Notification.permission === 'granted') {
        try {
          new Notification(`${siteSettings.siteName}: ${notif.title}`, {
            body: notif.message,
            icon: siteSettings.logoUrl || '/favicon.ico',
          });
        } catch {
          // Ignore browser notification error
        }
      }
    },
    [pushSubscriptionActive, siteSettings.siteName, siteSettings.logoUrl, showToast]
  );

  // Supabase Auth Actions
  const loginWithSupabaseAuth = useCallback(
    async (email: string, password: string): Promise<{ success: boolean; error?: string; role?: UserRole }> => {
      const res = await signInWithSupabase(email, password);
      if (res.success && res.user) {
        setSupabaseAuthUser(res.user);
        const role = (res.role || 'publisher') as UserRole;
        const existing = allUsers.find((u) => u.email === email);
        if (existing) {
          setCurrentUser(existing);
        } else {
          const newUser: User = {
            id: res.user.id,
            name: res.user.user_metadata?.name || email.split('@')[0],
            email,
            role,
            status: 'active',
            avatar: `https://images.unsplash.com/photo-${role === 'admin' ? '1534528741775-53994a69daeb' : '1507003211169-0a1dd7228f2d'}?w=150&auto=format&fit=crop&q=80`,
            articlesCount: 0,
            createdAt: new Date().toISOString(),
          };
          setAllUsers((prev) => [newUser, ...prev]);
          setCurrentUser(newUser);
        }
        showToast('Login Supabase Berhasil', `Otentikasi Supabase terverifikasi sebagai ${role.toUpperCase()}`, 'success');
        return { success: true, role };
      }
      return { success: false, error: res.error || 'Gagal login via Supabase' };
    },
    [allUsers, showToast]
  );

  const registerWithSupabaseAuth = useCallback(
    async (email: string, password: string, name: string, role: 'admin' | 'publisher'): Promise<{ success: boolean; error?: string }> => {
      const res = await signUpWithSupabase(email, password, name, role);
      if (res.success) {
        showToast('Pendaftaran Supabase Berhasil', `Akun ${name} (${role.toUpperCase()}) telah didaftarkan di Supabase Auth.`, 'success');
        return { success: true };
      }
      return { success: false, error: res.error || 'Gagal mendaftar ke Supabase Auth' };
    },
    [showToast]
  );

  const logoutSupabaseAuth = useCallback(async () => {
    await signOutFromSupabase();
    setSupabaseAuthUser(null);
    showToast('Logout Supabase', 'Sesi autentikasi Supabase telah keluar.', 'info');
  }, [showToast]);

  // Switch Role
  const switchUserRole = useCallback(
    (role: UserRole) => {
      const match = allUsers.find((u) => u.role === role);
      if (match) {
        setCurrentUser(match);
        showToast('Beralih Peran', `Sekarang Anda masuk sebagai: ${match.name} (${role.toUpperCase()})`, 'info');
      }
    },
    [allUsers, showToast]
  );

  // Users CRUD
  const addUser = useCallback((userData: Omit<User, 'id' | 'createdAt'>) => {
    const newUser: User = {
      ...userData,
      id: `user-${Date.now()}`,
      createdAt: new Date().toISOString(),
      articlesCount: 0,
    };
    setAllUsers((prev) => [newUser, ...prev]);
  }, []);

  const updateUser = useCallback((id: string, updates: Partial<User>) => {
    setAllUsers((prev) => prev.map((u) => (u.id === id ? { ...u, ...updates } : u)));
    setCurrentUser((curr) => (curr.id === id ? { ...curr, ...updates } : curr));
  }, []);

  const deleteUser = useCallback((id: string) => {
    setAllUsers((prev) => prev.filter((u) => u.id !== id));
  }, []);

  // Articles Workflow
  const createArticle = useCallback(
    (data: Partial<Article>): Article => {
      const readingTime = Math.max(1, Math.ceil((data.content || '').split(/\s+/).length / 180));
      const slug = (data.title || 'berita-baru')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)+/g, '');

      const newArticle: Article = {
        id: `art-${Date.now()}`,
        title: data.title || 'Judul Berita',
        slug: `${slug}-${Math.floor(1000 + Math.random() * 9000)}`,
        summary: data.summary || '',
        content: data.content || '',
        categoryId: data.categoryId || categories[0]?.id || 'cat-pamanukan',
        categoryName: categories.find((c) => c.id === data.categoryId)?.name || 'Pamanukan',
        coverImage: data.coverImage || 'https://images.unsplash.com/photo-1585829365295-ab7cd400c167?w=1000&auto=format&fit=crop&q=80',
        authorId: currentUser.id,
        authorName: currentUser.name,
        authorAvatar: currentUser.avatar,
        status: data.status || 'draft',
        isHeadline: data.isHeadline || false,
        isFeatured: data.isFeatured || false,
        isEditorPick: data.isEditorPick || false,
        tags: data.tags || ['Pamanukan'],
        views: 0,
        readingTimeMinutes: readingTime,
        publishedAt: data.status === 'published' ? new Date().toISOString() : '',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        commentsCount: 0,
        sharesCount: 0,
      };

      setArticles((prev) => [newArticle, ...prev]);

      // Direct write to Supabase database
      const client = getSupabaseClient();
      if (client) {
        client
          .from('articles')
          .upsert({
            id: newArticle.id,
            title: newArticle.title,
            slug: newArticle.slug,
            summary: newArticle.summary,
            content: newArticle.content,
            category_id: newArticle.categoryId,
            category_name: newArticle.categoryName,
            cover_image: newArticle.coverImage,
            author_id: currentUser.id?.startsWith('user-') ? null : currentUser.id,
            author_name: currentUser.name,
            author_avatar: currentUser.avatar,
            status: newArticle.status,
            is_headline: newArticle.isHeadline,
            is_featured: newArticle.isFeatured,
            is_editor_pick: newArticle.isEditorPick,
            tags: newArticle.tags,
            views: 0,
            reading_time_minutes: readingTime,
            published_at: newArticle.publishedAt || null,
            created_at: newArticle.createdAt,
            updated_at: newArticle.updatedAt,
          })
          .then();
      }

      if (newArticle.status === 'pending') {
        sendNotification({
          title: 'Berita Baru Dikirim untuk Review',
          message: `${currentUser.name} telah mengirimkan artikel "${newArticle.title}" untuk ditinjau editor.`,
          type: 'review_note',
          articleId: newArticle.id,
          articleTitle: newArticle.title,
          recipientRole: 'editor',
        });
      } else if (newArticle.status === 'published') {
        sendNotification({
          title: 'Berita Baru Diterbitkan',
          message: `Artikel "${newArticle.title}" telah dipublikasikan dan dapat dibaca publik.`,
          type: 'publish',
          articleId: newArticle.id,
          articleTitle: newArticle.title,
          recipientRole: 'all',
        });
      }

      return newArticle;
    },
    [categories, currentUser, sendNotification]
  );

  const updateArticle = useCallback((id: string, updates: Partial<Article>) => {
    setArticles((prev) =>
      prev.map((a) => {
        if (a.id !== id) return a;
        return {
          ...a,
          ...updates,
          updatedAt: new Date().toISOString(),
        };
      })
    );

    const client = getSupabaseClient();
    if (client) {
      const payload: any = { updated_at: new Date().toISOString() };
      if (updates.title !== undefined) payload.title = updates.title;
      if (updates.slug !== undefined) payload.slug = updates.slug;
      if (updates.summary !== undefined) payload.summary = updates.summary;
      if (updates.content !== undefined) payload.content = updates.content;
      if (updates.categoryId !== undefined) payload.category_id = updates.categoryId;
      if (updates.categoryName !== undefined) payload.category_name = updates.categoryName;
      if (updates.coverImage !== undefined) payload.cover_image = updates.coverImage;
      if (updates.status !== undefined) payload.status = updates.status;
      if (updates.isHeadline !== undefined) payload.is_headline = updates.isHeadline;
      if (updates.isFeatured !== undefined) payload.is_featured = updates.isFeatured;
      if (updates.isEditorPick !== undefined) payload.is_editor_pick = updates.isEditorPick;
      if (updates.tags !== undefined) payload.tags = updates.tags;
      if (updates.publishedAt !== undefined) payload.published_at = updates.publishedAt || null;
      if (updates.rejectionReason !== undefined) payload.rejection_reason = updates.rejectionReason;

      client.from('articles').update(payload).eq('id', id).then();
    }
  }, []);

  const submitArticleForReview = useCallback(
    (id: string) => {
      setArticles((prev) =>
        prev.map((a) => {
          if (a.id !== id) return a;
          return {
            ...a,
            status: 'pending' as const,
            updatedAt: new Date().toISOString(),
          };
        })
      );

      const target = articles.find((a) => a.id === id);
      sendNotification({
        title: 'Pengajuan Review Berita',
        message: `Artikel "${target?.title || 'Berita'}" diajukan untuk proses editorial dan review redaktur.`,
        type: 'review_note',
        articleId: id,
        articleTitle: target?.title,
        recipientRole: 'editor',
      });
      showToast('Berita Diajukan', 'Draft berhasil dikirim ke meja Redaktur untuk direview.', 'success');
    },
    [articles, sendNotification, showToast]
  );

  const approveAndPublishArticle = useCallback(
    (id: string) => {
      let publishedTitle = '';
      setArticles((prev) =>
        prev.map((a) => {
          if (a.id !== id) return a;
          publishedTitle = a.title;
          return {
            ...a,
            status: 'published' as const,
            publishedAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            rejectionReason: undefined,
          };
        })
      );

      sendNotification({
        title: 'Berita Telah Terbit!',
        message: `Artikel "${publishedTitle}" telah disetujui redaksi dan resmi diterbitkan di portal PAMANUKAN NEWS.`,
        type: 'publish',
        articleId: id,
        articleTitle: publishedTitle,
        recipientRole: 'all',
      });

      const client = getSupabaseClient();
      if (client) {
        client
          .from('articles')
          .update({
            status: 'published',
            published_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
            rejection_reason: null,
          })
          .eq('id', id)
          .then();
      }

      showToast('Berita Diterbitkan', `Artikel "${publishedTitle}" kini tayang di portal.`, 'success');
    },
    [sendNotification, showToast]
  );

  const rejectArticle = useCallback(
    (id: string, reason: string) => {
      let rejectedTitle = '';
      let authorId = '';
      setArticles((prev) =>
        prev.map((a) => {
          if (a.id !== id) return a;
          rejectedTitle = a.title;
          authorId = a.authorId;
          return {
            ...a,
            status: 'rejected' as const,
            rejectionReason: reason,
            updatedAt: new Date().toISOString(),
          };
        })
      );

      sendNotification({
        title: 'Catatan Revisi Redaksi',
        message: `Artikel "${rejectedTitle}" memerlukan perbaikan: "${reason}"`,
        type: 'review_note',
        articleId: id,
        articleTitle: rejectedTitle,
        recipientRole: 'publisher',
      });

      const client = getSupabaseClient();
      if (client) {
        client
          .from('articles')
          .update({
            status: 'rejected',
            rejection_reason: reason,
            updated_at: new Date().toISOString(),
          })
          .eq('id', id)
          .then();
      }

      showToast('Revisi Dikirim', 'Catatan revisi telah diteruskan kepada publisher/penulis.', 'warning');
    },
    [sendNotification, showToast]
  );

  const deleteArticle = useCallback((id: string) => {
    setArticles((prev) => prev.filter((a) => a.id !== id));
    const client = getSupabaseClient();
    if (client) {
      client.from('articles').delete().eq('id', id).then();
    }
  }, []);

  const incrementArticleViews = useCallback((id: string) => {
    setArticles((prev) =>
      prev.map((a) => (a.id === id ? { ...a, views: a.views + 1 } : a))
    );
  }, []);

  // Media Management
  const addMediaItem = useCallback(
    (data: Omit<MediaItem, 'id' | 'createdAt'>): MediaItem => {
      const newItem: MediaItem = {
        ...data,
        id: `media-${Date.now()}`,
        createdAt: new Date().toISOString(),
      };
      setMediaItems((prev) => [newItem, ...prev]);

      const client = getSupabaseClient();
      if (client) {
        client
          .from('media')
          .upsert({
            id: newItem.id,
            name: newItem.name,
            url: newItem.url,
            original_size: newItem.originalSize,
            compressed_size: newItem.compressedSize,
            mime_type: newItem.mimeType,
            width: newItem.width,
            height: newItem.height,
            uploaded_by_name: newItem.uploadedBy,
            created_at: newItem.createdAt,
          })
          .then();
      }

      return newItem;
    },
    []
  );

  const deleteMediaItem = useCallback((id: string) => {
    setMediaItems((prev) => prev.filter((m) => m.id !== id));
    const client = getSupabaseClient();
    if (client) {
      client.from('media').delete().eq('id', id).then();
    }
  }, []);

  // Categories
  const addCategory = useCallback((data: Omit<Category, 'id'>) => {
    const newCat: Category = {
      ...data,
      id: `cat-${data.slug}`,
      count: 0,
    };
    setCategories((prev) => [...prev, newCat]);

    const client = getSupabaseClient();
    if (client) {
      client
        .from('categories')
        .upsert({
          id: newCat.id,
          name: newCat.name,
          slug: newCat.slug,
          color: newCat.color,
          order: newCat.order,
          is_active: newCat.isActive,
        })
        .then();
    }
  }, []);

  const updateCategory = useCallback((id: string, updates: Partial<Category>) => {
    setCategories((prev) => prev.map((c) => (c.id === id ? { ...c, ...updates } : c)));
    const client = getSupabaseClient();
    if (client) {
      const payload: any = {};
      if (updates.name !== undefined) payload.name = updates.name;
      if (updates.slug !== undefined) payload.slug = updates.slug;
      if (updates.color !== undefined) payload.color = updates.color;
      if (updates.order !== undefined) payload.order = updates.order;
      if (updates.isActive !== undefined) payload.is_active = updates.isActive;
      client.from('categories').update(payload).eq('id', id).then();
    }
  }, []);

  const deleteCategory = useCallback((id: string) => {
    setCategories((prev) => prev.filter((c) => c.id !== id));
    const client = getSupabaseClient();
    if (client) {
      client.from('categories').delete().eq('id', id).then();
    }
  }, []);

  // Ads
  const addAd = useCallback((data: Omit<Advertisement, 'id' | 'impressions' | 'clicks'>) => {
    const newAd: Advertisement = {
      ...data,
      id: `ad-${Date.now()}`,
      impressions: 0,
      clicks: 0,
    };
    setAdvertisements((prev) => [newAd, ...prev]);

    const client = getSupabaseClient();
    if (client) {
      client
        .from('advertisements')
        .upsert({
          id: newAd.id,
          title: newAd.title,
          position: newAd.position,
          image_url: newAd.imageUrl,
          link_url: newAd.linkUrl,
          is_active: newAd.isActive,
          impressions: 0,
          clicks: 0,
          start_date: newAd.startDate,
          end_date: newAd.endDate,
        })
        .then();
    }
  }, []);

  const updateAd = useCallback((id: string, updates: Partial<Advertisement>) => {
    setAdvertisements((prev) => prev.map((ad) => (ad.id === id ? { ...ad, ...updates } : ad)));
    const client = getSupabaseClient();
    if (client) {
      const payload: any = {};
      if (updates.title !== undefined) payload.title = updates.title;
      if (updates.position !== undefined) payload.position = updates.position;
      if (updates.imageUrl !== undefined) payload.image_url = updates.imageUrl;
      if (updates.linkUrl !== undefined) payload.link_url = updates.linkUrl;
      if (updates.isActive !== undefined) payload.is_active = updates.isActive;
      if (updates.startDate !== undefined) payload.start_date = updates.startDate;
      if (updates.endDate !== undefined) payload.end_date = updates.endDate;
      client.from('advertisements').update(payload).eq('id', id).then();
    }
  }, []);

  const deleteAd = useCallback((id: string) => {
    setAdvertisements((prev) => prev.filter((ad) => ad.id !== id));
    const client = getSupabaseClient();
    if (client) {
      client.from('advertisements').delete().eq('id', id).then();
    }
  }, []);

  const recordAdClick = useCallback((id: string) => {
    setAdvertisements((prev) =>
      prev.map((ad) => (ad.id === id ? { ...ad, clicks: ad.clicks + 1 } : ad))
    );
    const client = getSupabaseClient();
    if (client) {
      client.rpc('increment_ad_clicks', { ad_id: id }).then();
    }
  }, []);

  // Settings
  const updateSiteSettings = useCallback((updates: Partial<SiteSettings>) => {
    setSiteSettings((prev) => ({ ...prev, ...updates }));

    const client = getSupabaseClient();
    if (client) {
      const payload: any = { id: 'primary', updated_at: new Date().toISOString() };
      if (updates.siteName !== undefined) payload.site_name = updates.siteName;
      if (updates.tagline !== undefined) payload.tagline = updates.tagline;
      if (updates.runningText !== undefined) payload.running_text = updates.runningText;
      if (updates.contactEmail !== undefined) payload.contact_email = updates.contactEmail;
      if (updates.contactPhone !== undefined) payload.contact_phone = updates.contactPhone;
      if (updates.address !== undefined) payload.address = updates.address;
      if (updates.enablePushNotification !== undefined) payload.enable_push_notification = updates.enablePushNotification;
      if (updates.enableAiSearch !== undefined) payload.enable_ai_search = updates.enableAiSearch;
      if (updates.seoDescription !== undefined) payload.seo_description = updates.seoDescription;
      if (updates.seoKeywords !== undefined) payload.seo_keywords = updates.seoKeywords;

      client.from('site_settings').upsert(payload).then();
    }
  }, []);

  // Notifications
  const markNotificationAsRead = useCallback((id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, isRead: true } : n)));
  }, []);

  const markAllNotificationsAsRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  }, []);

  const togglePushNotifications = useCallback(async (): Promise<boolean> => {
    if (!('Notification' in window)) {
      showToast('Browser Tidak Mendukung', 'Browser Anda belum mendukung Web Push Notifications.', 'warning');
      return false;
    }

    if (pushSubscriptionActive) {
      setPushSubscriptionActive(false);
      localStorage.setItem(STORAGE_KEYS.PUSH_SUB, 'false');
      showToast('Notifikasi Nonaktif', 'Anda telah berhenti berlangganan push notifikasi berita.', 'info');
      return false;
    }

    try {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        setPushSubscriptionActive(true);
        localStorage.setItem(STORAGE_KEYS.PUSH_SUB, 'true');
        showToast('Notifikasi Aktif!', 'Anda akan menerima pemberitahuan setiap ada berita breaking news di Pamanukan.', 'success');
        return true;
      } else {
        showToast('Izin Ditolak', 'Harap izinkan notifikasi pada pengaturan browser Anda.', 'warning');
        return false;
      }
    } catch {
      return false;
    }
  }, [pushSubscriptionActive, showToast]);

  const toggleDarkMode = useCallback(() => {
    setIsDarkMode((prev) => !prev);
  }, []);

  // Supabase Integration Handlers
  const updateSupabaseConfigState = useCallback((config: SupabaseConfig) => {
    setSupabaseConfig(config);
    resetSupabaseClient(config);
  }, []);

  const testSupabase = useCallback(async (url: string, key: string) => {
    return await testSupabaseConnection(url, key);
  }, []);

  const syncWithSupabase = useCallback(async (): Promise<{ success: boolean; message: string }> => {
    const client = getSupabaseClient();
    if (!client) {
      return {
        success: false,
        message: 'Konfigurasi Supabase belum terpasang atau tidak valid. Silakan atur URL dan Anon Key terlebih dahulu.',
      };
    }

    try {
      // 1. Fetch remote articles if existing
      const { data: remoteArticles, error: fetchErr } = await client
        .from('articles')
        .select('*')
        .order('created_at', { ascending: false });

      if (fetchErr) {
        return {
          success: false,
          message: `Gagal sinkronisasi Supabase: ${fetchErr.message}. Pastikan skrip SQL Schema telah dijalankan di Supabase.`,
        };
      }

      // 1. Synchronize Articles
      if (remoteArticles && remoteArticles.length > 0) {
        const mapped: Article[] = remoteArticles.map((ra: any) => ({
          id: ra.id,
          title: ra.title,
          slug: ra.slug,
          summary: ra.summary,
          content: ra.content,
          categoryId: ra.category_id,
          categoryName: ra.category_name,
          coverImage: ra.cover_image,
          authorId: ra.author_id,
          authorName: ra.author_name,
          authorAvatar: ra.author_avatar,
          status: ra.status,
          isHeadline: ra.is_headline,
          isFeatured: ra.is_featured,
          isEditorPick: ra.is_editor_pick,
          tags: ra.tags || [],
          views: ra.views || 0,
          readingTimeMinutes: ra.reading_time_minutes || 3,
          publishedAt: ra.published_at || '',
          createdAt: ra.created_at,
          updatedAt: ra.updated_at,
          rejectionReason: ra.rejection_reason,
          commentsCount: 0,
          sharesCount: 0,
        }));
        setArticles(mapped);
      } else if (articles.length > 0) {
        const payload = articles.map((a) => ({
          id: a.id,
          title: a.title,
          slug: a.slug,
          summary: a.summary,
          content: a.content,
          category_id: a.categoryId,
          category_name: a.categoryName,
          cover_image: a.coverImage,
          author_id: a.authorId?.startsWith('user-') ? null : a.authorId,
          author_name: a.authorName,
          author_avatar: a.authorAvatar,
          status: a.status,
          is_headline: a.isHeadline,
          is_featured: a.isFeatured,
          is_editor_pick: a.isEditorPick,
          tags: a.tags,
          views: a.views,
          reading_time_minutes: a.readingTimeMinutes,
          rejection_reason: a.rejectionReason,
          published_at: a.publishedAt || null,
          created_at: a.createdAt,
          updated_at: a.updatedAt,
        }));
        await client.from('articles').upsert(payload);
      }

      // 2. Synchronize Categories
      const { data: remoteCats } = await client.from('categories').select('*').order('order', { ascending: true });
      if (remoteCats && remoteCats.length > 0) {
        setCategories(
          remoteCats.map((c: any) => ({
            id: c.id,
            name: c.name,
            slug: c.slug,
            color: c.color || '#dc2626',
            order: c.order || 0,
            isActive: c.is_active ?? true,
            count: 0,
          }))
        );
      } else if (categories.length > 0) {
        await client.from('categories').upsert(
          categories.map((c) => ({
            id: c.id,
            name: c.name,
            slug: c.slug,
            color: c.color,
            order: c.order,
            is_active: c.isActive,
          }))
        );
      }

      // 3. Synchronize Site Settings
      const { data: remoteSettings } = await client.from('site_settings').select('*').eq('id', 'primary').maybeSingle();
      if (remoteSettings) {
        setSiteSettings((prev) => ({
          ...prev,
          siteName: remoteSettings.site_name || prev.siteName,
          tagline: remoteSettings.tagline || prev.tagline,
          runningText: remoteSettings.running_text || prev.runningText,
          contactEmail: remoteSettings.contact_email || prev.contactEmail,
          contactPhone: remoteSettings.contact_phone || prev.contactPhone,
          address: remoteSettings.address || prev.address,
        }));
      } else {
        await client.from('site_settings').upsert({
          id: 'primary',
          site_name: siteSettings.siteName,
          tagline: siteSettings.tagline,
          running_text: siteSettings.runningText,
          contact_email: siteSettings.contactEmail,
          contact_phone: siteSettings.contactPhone,
          address: siteSettings.address,
        });
      }

      // 4. Synchronize Advertisements
      const { data: remoteAds } = await client.from('advertisements').select('*');
      if (remoteAds && remoteAds.length > 0) {
        setAdvertisements(
          remoteAds.map((ad: any) => ({
            id: ad.id,
            title: ad.title,
            position: ad.position,
            imageUrl: ad.image_url,
            linkUrl: ad.link_url,
            isActive: ad.is_active,
            impressions: ad.impressions || 0,
            clicks: ad.clicks || 0,
            startDate: ad.start_date,
            endDate: ad.end_date,
          }))
        );
      } else if (advertisements.length > 0) {
        await client.from('advertisements').upsert(
          advertisements.map((ad) => ({
            id: ad.id,
            title: ad.title,
            position: ad.position,
            image_url: ad.imageUrl,
            link_url: ad.linkUrl,
            is_active: ad.isActive,
            impressions: ad.impressions,
            clicks: ad.clicks,
            start_date: ad.startDate,
            end_date: ad.endDate,
          }))
        );
      }

      const updatedConfig: SupabaseConfig = {
        ...supabaseConfig,
        isConnected: true,
        lastSyncTime: new Date().toLocaleTimeString('id-ID'),
      };
      setSupabaseConfig(updatedConfig);
      saveStoredSupabaseConfig(updatedConfig);

      showToast('Sinkronisasi Berhasil', 'Data artikel PAMANUKAN NEWS berhasil disinkronkan dengan database Supabase.', 'success');
      return { success: true, message: 'Sinkronisasi berhasil!' };
    } catch (err: any) {
      return {
        success: false,
        message: `Terjadi kendala saat sinkronisasi: ${err.message}`,
      };
    }
  }, [articles, showToast, supabaseConfig]);

  const resetToDefaultData = useCallback(() => {
    setAllUsers(INITIAL_USERS);
    setCurrentUser(INITIAL_USERS[0]);
    setCategories(INITIAL_CATEGORIES);
    setArticles(INITIAL_ARTICLES);
    setMediaItems(INITIAL_MEDIA);
    setAdvertisements(INITIAL_ADS);
    setSiteSettings(INITIAL_SITE_SETTINGS);
    setNotifications(INITIAL_NOTIFICATIONS);
    showToast('Reset Berhasil', 'Data telah dikembalikan ke arsip berita bawaan Pamanukan News.', 'info');
  }, [showToast]);

  const unreadNotifCount = notifications.filter((n) => !n.isRead).length;

  return (
    <NewsContext.Provider
      value={{
        currentUser,
        allUsers,
        categories,
        articles,
        mediaItems,
        advertisements,
        siteSettings,
        notifications,
        unreadNotifCount,
        supabaseConfig,
        isDarkMode,
        activeToast,
        pushSubscriptionActive,

        // Supabase Auth
        supabaseAuthUser,
        isSupabaseAuthActive: Boolean(supabaseAuthUser),
        loginWithSupabaseAuth,
        registerWithSupabaseAuth,
        logoutSupabaseAuth,

        switchUserRole,
        setCurrentUser,
        addUser,
        updateUser,
        deleteUser,

        createArticle,
        updateArticle,
        submitArticleForReview,
        approveAndPublishArticle,
        rejectArticle,
        deleteArticle,
        incrementArticleViews,

        addMediaItem,
        deleteMediaItem,

        addCategory,
        updateCategory,
        deleteCategory,

        addAd,
        updateAd,
        deleteAd,
        recordAdClick,

        updateSiteSettings,

        markNotificationAsRead,
        markAllNotificationsAsRead,
        sendNotification,
        togglePushNotifications,

        toggleDarkMode,

        updateSupabaseConfig: updateSupabaseConfigState,
        testSupabase,
        syncWithSupabase,
        resetToDefaultData,
      }}
    >
      {children}
    </NewsContext.Provider>
  );
};

export function useNews() {
  const context = useContext(NewsContext);
  if (!context) {
    throw new Error('useNews must be used within a NewsProvider');
  }
  return context;
}
