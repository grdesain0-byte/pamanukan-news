export type UserRole = 'admin' | 'publisher' | 'editor' | 'reader';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
  bio?: string;
  status: 'active' | 'suspended';
  createdAt: string;
  articlesCount?: number;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  color: string;
  iconName?: string;
  order: number;
  isActive: boolean;
  count?: number;
}

export type ArticleStatus = 'draft' | 'pending' | 'published' | 'rejected' | 'archived';

export interface Article {
  id: string;
  title: string;
  slug: string;
  summary: string;
  content: string;
  categoryId: string;
  categoryName: string;
  coverImage: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  status: ArticleStatus;
  isHeadline: boolean;
  isFeatured: boolean;
  isEditorPick: boolean;
  tags: string[];
  views: number;
  readingTimeMinutes: number;
  publishedAt: string;
  createdAt: string;
  updatedAt: string;
  rejectionReason?: string;
  commentsCount: number;
  sharesCount: number;
}

export interface MediaItem {
  id: string;
  name: string;
  url: string;
  originalSize: number; // in bytes
  compressedSize: number; // in bytes
  mimeType: string;
  width: number;
  height: number;
  uploadedBy: string;
  uploadedByName: string;
  createdAt: string;
}

export type AdPosition = 'header' | 'sidebar' | 'in_feed' | 'popup';

export interface Advertisement {
  id: string;
  title: string;
  position: AdPosition;
  imageUrl: string;
  linkUrl: string;
  isActive: boolean;
  impressions: number;
  clicks: number;
  startDate: string;
  endDate: string;
}

export interface Comment {
  id: string;
  articleId: string;
  authorName: string;
  authorAvatar: string;
  content: string;
  createdAt: string;
  likes: number;
  isVerified?: boolean;
}

export interface SiteSettings {
  siteName: string;
  tagline: string;
  logoUrl?: string;
  runningText: string;
  contactEmail: string;
  contactPhone: string;
  address: string;
  socialMedia: {
    facebook: string;
    twitter: string;
    instagram: string;
    youtube: string;
  };
  enablePushNotification: boolean;
  enableAiSearch: boolean;
  seoDescription: string;
  seoKeywords: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'status_update' | 'review_note' | 'publish' | 'breaking_news' | 'system';
  articleId?: string;
  articleTitle?: string;
  isRead: boolean;
  createdAt: string;
  recipientRole?: UserRole | 'all';
}

export interface SupabaseConfig {
  url: string;
  anonKey: string;
  isConnected: boolean;
  lastSyncTime?: string;
}
