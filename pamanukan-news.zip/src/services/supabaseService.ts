import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { SupabaseConfig } from '../types';

const STORAGE_KEY = 'pamanukan_supabase_config';

export const DIRECT_SUPABASE_CONFIG: SupabaseConfig = {
  url: 'https://taiclgzvnuqbnpfaufcb.supabase.co',
  anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRhaWNsZ3p2bnVxYm5wZmF1ZmNiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTAyMTY5NTgsImV4cCI6MjEwNTc5Mjk1OH0.coRCpeoqm0Vuq5XSdGhlxNwYXBrQJOxUCB_4KUrVe24',
  isConnected: true,
};

export function getStoredSupabaseConfig(): SupabaseConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      // Auto-migrate from old project or empty credentials to new Supabase project
      if (
        !parsed.url ||
        !parsed.anonKey ||
        parsed.url.includes('srmrnvoyfusvpyawldyb') ||
        parsed.url.includes('xyzcompany')
      ) {
        saveStoredSupabaseConfig(DIRECT_SUPABASE_CONFIG);
        return { ...DIRECT_SUPABASE_CONFIG };
      }
      return parsed;
    }
  } catch (e) {
    console.error('Failed to read Supabase config from storage', e);
  }

  // Fallback to Vite env variables or direct project credentials
  const url = import.meta.env.VITE_SUPABASE_URL || DIRECT_SUPABASE_CONFIG.url;
  const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || DIRECT_SUPABASE_CONFIG.anonKey;

  return {
    url,
    anonKey,
    isConnected: true,
  };
}

export function saveStoredSupabaseConfig(config: SupabaseConfig): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
  } catch (e) {
    console.error('Failed to save Supabase config to storage', e);
  }
}

let activeClient: SupabaseClient | null = null;

export function getSupabaseClient(): SupabaseClient | null {
  const config = getStoredSupabaseConfig();
  if (!config.url || !config.anonKey) {
    return null;
  }

  if (!activeClient) {
    try {
      activeClient = createClient(config.url, config.anonKey);
    } catch (err) {
      console.error('Failed to initialize Supabase client:', err);
      return null;
    }
  }

  return activeClient;
}

export function resetSupabaseClient(config: SupabaseConfig): SupabaseClient | null {
  saveStoredSupabaseConfig(config);
  if (!config.url || !config.anonKey) {
    activeClient = null;
    return null;
  }

  try {
    activeClient = createClient(config.url, config.anonKey);
    return activeClient;
  } catch (err) {
    console.error('Failed to reinitialize Supabase client:', err);
    activeClient = null;
    return null;
  }
}

export async function testSupabaseConnection(url: string, anonKey: string): Promise<{ success: boolean; message: string }> {
  if (!url || !anonKey) {
    return { success: false, message: 'URL dan Anon Key Supabase wajib diisi.' };
  }

  try {
    const testClient = createClient(url, anonKey);
    // Simple ping check to articles or health
    const { error } = await testClient.from('articles').select('id').limit(1);

    if (error && error.code !== 'PGRST116' && !error.message.includes('relation "public.articles" does not exist')) {
      return { success: false, message: `Error koneksi Supabase: ${error.message}` };
    }

    return {
      success: true,
      message: 'Berhasil terhubung ke Supabase Project!',
    };
  } catch (err: any) {
    return {
      success: false,
      message: `Gagal menghubungi server Supabase: ${err.message || 'Periksa format URL dan koneksi internet.'}`,
    };
  }
}

/**
 * ====================================================
 * SUPABASE AUTHENTICATION INTEGRATION
 * ====================================================
 */

export interface SupabaseAuthResult {
  success: boolean;
  user?: any;
  session?: any;
  role?: 'admin' | 'publisher' | 'editor' | 'reader';
  error?: string;
}

export async function signInWithSupabase(
  email: string,
  password: string
): Promise<SupabaseAuthResult> {
  const client = getSupabaseClient();
  if (!client) {
    return { success: false, error: 'Klien Supabase belum terkonfigurasi.' };
  }

  try {
    const { data, error } = await client.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      return { success: false, error: error.message };
    }

    const userMetadata = data.user?.user_metadata || {};
    let determinedRole: 'admin' | 'publisher' =
      userMetadata.role ||
      (email.toLowerCase().includes('pemred') || email.toLowerCase().includes('admin') ? 'admin' : 'publisher');

    // Query user profile from Supabase database public.users to get actual registered role
    try {
      const { data: profile } = await client
        .from('users')
        .select('role, name')
        .eq('id', data.user.id)
        .maybeSingle();

      if (profile?.role) {
        determinedRole = profile.role as 'admin' | 'publisher';
      }
    } catch {
      // Fallback to metadata
    }

    return {
      success: true,
      user: data.user,
      session: data.session,
      role: determinedRole,
    };
  } catch (err: any) {
    return {
      success: false,
      error: err.message || 'Terjadi kesalahan pada login Supabase Auth.',
    };
  }
}

export async function signUpWithSupabase(
  email: string,
  password: string,
  name: string,
  role: 'admin' | 'publisher'
): Promise<SupabaseAuthResult> {
  const client = getSupabaseClient();
  if (!client) {
    return { success: false, error: 'Klien Supabase belum terkonfigurasi.' };
  }

  try {
    const { data, error } = await client.auth.signUp({
      email,
      password,
      options: {
        data: {
          name,
          role,
        },
      },
    });

    if (error) {
      return { success: false, error: error.message };
    }

    return {
      success: true,
      user: data.user,
      session: data.session,
      role,
    };
  } catch (err: any) {
    return {
      success: false,
      error: err.message || 'Gagal mendaftar akun di Supabase Auth.',
    };
  }
}

export async function signOutFromSupabase(): Promise<{ success: boolean; error?: string }> {
  const client = getSupabaseClient();
  if (!client) return { success: true };

  try {
    const { error } = await client.auth.signOut();
    if (error) {
      return { success: false, error: error.message };
    }
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

export async function getSupabaseCurrentSession() {
  const client = getSupabaseClient();
  if (!client) return null;

  try {
    const { data } = await client.auth.getSession();
    return data.session;
  } catch {
    return null;
  }
}

export function subscribeToSupabaseAuth(
  callback: (event: string, session: any) => void
) {
  const client = getSupabaseClient();
  if (!client) return { unsubscribe: () => {} };

  const { data: authListener } = client.auth.onAuthStateChange((event, session) => {
    callback(event, session);
  });

  return {
    unsubscribe: () => {
      authListener?.subscription.unsubscribe();
    },
  };
}

/**
 * Returns SQL DDL Schema ready to execute in Supabase SQL Editor
 * Distinguishes ADMIN and PUBLISHER with auth.users integration, auto-sync trigger & RLS
 */
export function generateSupabaseSQLSchema(): string {
  return `-- ==============================================================================
-- PAMANUKAN NEWS - SUPABASE DATABASE & RBAC AUTHENTICATION SCHEMA
-- Jalankan skrip ini langsung di menu: Supabase Dashboard ➔ SQL Editor ➔ New Query
-- ==============================================================================

-- 1. TABEL PENGGUNA TERINTEGRASI DENGAN SUPABASE AUTH (auth.users)
-- Membedakan peran 'admin' dan 'publisher' secara ketat
CREATE TABLE IF NOT EXISTS public.users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'publisher' CHECK (role IN ('admin', 'publisher')),
  avatar TEXT,
  bio TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. TRIGGER OTOMATIS: SINKRONISASI USER DARI SUPABASE AUTH KE PUBLIC.USERS
-- Mengambil metadata 'name' dan 'role' saat pengguna mendaftar melalui Supabase Auth
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  assigned_role TEXT;
  full_name TEXT;
BEGIN
  -- Cek metadata atau tentukan peran default
  assigned_role := COALESCE(NEW.raw_user_meta_data->>'role', 
                   CASE 
                     WHEN NEW.email LIKE '%admin%' OR NEW.email LIKE '%pemred%' THEN 'admin'
                     ELSE 'publisher'
                   END);
  
  full_name := COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1));

  INSERT INTO public.users (id, email, name, role, avatar, status)
  VALUES (
    NEW.id,
    NEW.email,
    full_name,
    assigned_role,
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    'active'
  )
  ON CONFLICT (id) DO UPDATE
  SET
    email = EXCLUDED.email,
    name = COALESCE(EXCLUDED.name, public.users.name),
    role = COALESCE(public.users.role, EXCLUDED.role),
    updated_at = NOW();

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Pasang Trigger ke tabel auth.users Supabase
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 3. FUNGSI PEMBANTU ROW LEVEL SECURITY (RLS)
-- Mengecek apakah pemanggil adalah ADMIN aktif
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid() AND role = 'admin' AND status = 'active'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Mengecek apakah pemanggil adalah PUBLISHER aktif
CREATE OR REPLACE FUNCTION public.is_publisher()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid() AND role = 'publisher' AND status = 'active'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 4. TABEL KATEGORI BERITA
CREATE TABLE IF NOT EXISTS public.categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  color TEXT NOT NULL DEFAULT '#dc2626',
  icon_name TEXT,
  "order" INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. TABEL ARTIKEL BERITA
CREATE TABLE IF NOT EXISTS public.articles (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  summary TEXT NOT NULL,
  content TEXT NOT NULL,
  category_id TEXT REFERENCES public.categories(id) ON DELETE SET NULL,
  category_name TEXT NOT NULL,
  cover_image TEXT NOT NULL,
  author_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
  author_name TEXT NOT NULL,
  author_avatar TEXT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'pending', 'published', 'rejected', 'archived')),
  is_headline BOOLEAN NOT NULL DEFAULT false,
  is_featured BOOLEAN NOT NULL DEFAULT false,
  is_editor_pick BOOLEAN NOT NULL DEFAULT false,
  tags TEXT[] DEFAULT '{}',
  views INTEGER NOT NULL DEFAULT 0,
  reading_time_minutes INTEGER NOT NULL DEFAULT 3,
  rejection_reason TEXT,
  published_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. TABEL MEDIA GALERI & KOMPRESI GAMBAR
CREATE TABLE IF NOT EXISTS public.media (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  url TEXT NOT NULL,
  original_size INTEGER NOT NULL,
  compressed_size INTEGER NOT NULL,
  mime_type TEXT NOT NULL,
  width INTEGER NOT NULL,
  height INTEGER NOT NULL,
  uploaded_by UUID REFERENCES public.users(id) ON DELETE SET NULL,
  uploaded_by_name TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. TABEL IKLAN BANNER
CREATE TABLE IF NOT EXISTS public.advertisements (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  position TEXT NOT NULL CHECK (position IN ('header', 'sidebar', 'in_feed', 'popup')),
  image_url TEXT NOT NULL,
  link_url TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  impressions INTEGER NOT NULL DEFAULT 0,
  clicks INTEGER NOT NULL DEFAULT 0,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. TABEL PENGATURAN WEBSITE
CREATE TABLE IF NOT EXISTS public.site_settings (
  id TEXT PRIMARY KEY DEFAULT 'primary',
  site_name TEXT NOT NULL DEFAULT 'PAMANUKAN NEWS',
  tagline TEXT NOT NULL,
  running_text TEXT,
  contact_email TEXT,
  contact_phone TEXT,
  address TEXT,
  facebook TEXT,
  twitter TEXT,
  instagram TEXT,
  youtube TEXT,
  enable_push_notification BOOLEAN DEFAULT true,
  enable_ai_search BOOLEAN DEFAULT true,
  seo_description TEXT,
  seo_keywords TEXT,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. TABEL KOMENTAR
CREATE TABLE IF NOT EXISTS public.comments (
  id TEXT PRIMARY KEY,
  article_id TEXT REFERENCES public.articles(id) ON DELETE CASCADE,
  author_name TEXT NOT NULL,
  author_avatar TEXT,
  content TEXT NOT NULL,
  likes INTEGER NOT NULL DEFAULT 0,
  is_verified BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10. AKTIFKAN ROW LEVEL SECURITY (RLS) DI SELURUH TABEL
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.articles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.media ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.advertisements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;

-- ------------------------------------------------------------------------------
-- KEBIJAKAN RLS UNTUK MEMBEDAKAN ADMIN & PUBLISHER SECARA KETAT
-- ------------------------------------------------------------------------------

-- [PUBLIC.USERS]
-- Publik dapat melihat info profil penulis redaksi
CREATE POLICY "users_select_all" ON public.users FOR SELECT USING (true);
-- Hanya ADMIN yang dapat mengubah role dan status user lain
CREATE POLICY "users_admin_manage" ON public.users FOR ALL USING (public.is_admin());
-- Pengguna dapat mengedit profil diri mereka sendiri
CREATE POLICY "users_update_own" ON public.users FOR UPDATE USING (id = auth.uid());

-- [PUBLIC.ARTICLES]
-- Publik membaca artikel yang statusnya 'published'
CREATE POLICY "articles_public_read" ON public.articles FOR SELECT USING (status = 'published');
-- ADMIN memiliki izin penuh atas semua artikel (Select, Insert, Update, Delete)
CREATE POLICY "articles_admin_all" ON public.articles FOR ALL USING (public.is_admin());
-- PUBLISHER dapat melihat semua artikel di ruang redaksi
CREATE POLICY "articles_publisher_select" ON public.articles FOR SELECT USING (public.is_publisher());
-- PUBLISHER dapat membuat berita baru (author_id harus id miliknya)
CREATE POLICY "articles_publisher_insert" ON public.articles FOR INSERT WITH CHECK (
  public.is_publisher() AND author_id = auth.uid()
);
-- PUBLISHER dapat mengedit/submit/publish berita karyanya sendiri
CREATE POLICY "articles_publisher_update" ON public.articles FOR UPDATE USING (
  public.is_publisher() AND author_id = auth.uid()
);
-- PUBLISHER hanya bisa menghapus draf karyanya sendiri
CREATE POLICY "articles_publisher_delete" ON public.articles FOR DELETE USING (
  public.is_publisher() AND author_id = auth.uid() AND status IN ('draft', 'rejected')
);

-- [PUBLIC.CATEGORIES]
-- Publik dan Publisher dapat melihat kategori aktif
CREATE POLICY "categories_select" ON public.categories FOR SELECT USING (true);
-- Hanya ADMIN yang berhak menambah, mengubah, atau menghapus kategori
CREATE POLICY "categories_admin_all" ON public.categories FOR ALL USING (public.is_admin());

-- [PUBLIC.MEDIA]
-- Semua orang dapat melihat aset media gambar
CREATE POLICY "media_select" ON public.media FOR SELECT USING (true);
-- ADMIN memiliki izin penuh atas semua media
CREATE POLICY "media_admin_all" ON public.media FOR ALL USING (public.is_admin());
-- PUBLISHER dapat mengunggah media baru
CREATE POLICY "media_publisher_insert" ON public.media FOR INSERT WITH CHECK (
  public.is_publisher() OR public.is_admin()
);

-- [PUBLIC.ADVERTISEMENTS]
-- Publik dapat melihat iklan banner aktif
CREATE POLICY "ads_select" ON public.advertisements FOR SELECT USING (is_active = true);
-- Hanya ADMIN yang berhak mengelola iklan
CREATE POLICY "ads_admin_all" ON public.advertisements FOR ALL USING (public.is_admin());

-- [PUBLIC.SITE_SETTINGS]
-- Publik dan Publisher dapat membaca pengaturan website
CREATE POLICY "settings_select" ON public.site_settings FOR SELECT USING (true);
-- Hanya ADMIN yang berhak mengubah pengaturan website
CREATE POLICY "settings_admin_update" ON public.site_settings FOR UPDATE USING (public.is_admin());

-- [PUBLIC.COMMENTS]
CREATE POLICY "comments_select" ON public.comments FOR SELECT USING (true);
CREATE POLICY "comments_insert" ON public.comments FOR INSERT WITH CHECK (true);
CREATE POLICY "comments_admin_all" ON public.comments FOR ALL USING (public.is_admin());

-- ==============================================================================
-- QUERY PRAKTIS: PENETAPAN PERAN SECARA MANUAL (JALANKAN SESUAI KEBUTUHAN)
-- ==============================================================================
-- 1. Mengubah pengguna menjadi ADMIN:
-- UPDATE public.users SET role = 'admin' WHERE email = 'pemred@pamanukannews.com';

-- 2. Mengubah pengguna menjadi PUBLISHER:
-- UPDATE public.users SET role = 'publisher' WHERE email = 'wartawan@pamanukannews.com';

-- 3. Melihat daftar seluruh pengguna beserta perannya:
-- SELECT id, name, email, role, status, created_at FROM public.users ORDER BY role, name;
`;
}
