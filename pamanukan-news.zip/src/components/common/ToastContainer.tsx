import React from 'react';
import { useNews } from '../../context/NewsContext';
import { CheckCircle2, AlertCircle, Info, Bell, X } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const { activeToast } = useNews();

  if (!activeToast) return null;

  const icons = {
    success: <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />,
    alert: <AlertCircle className="w-5 h-5 text-red-500 shrink-0" />,
    warning: <AlertCircle className="w-5 h-5 text-amber-500 shrink-0" />,
    info: <Info className="w-5 h-5 text-blue-500 shrink-0" />,
  };

  const borders = {
    success: 'border-emerald-500/30 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200',
    alert: 'border-red-500/30 bg-red-50 dark:bg-red-950/40 text-red-900 dark:text-red-200',
    warning: 'border-amber-500/30 bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200',
    info: 'border-blue-500/30 bg-blue-50 dark:bg-blue-950/40 text-blue-900 dark:text-blue-200',
  };

  return (
    <div className="fixed bottom-5 right-5 z-50 max-w-md w-full animate-bounce-in shadow-2xl">
      <div
        className={`flex items-start gap-3 p-4 rounded-xl border backdrop-blur-md shadow-lg ${
          borders[activeToast.type] || borders.info
        }`}
      >
        <div className="mt-0.5">{icons[activeToast.type] || <Bell className="w-5 h-5 text-blue-500" />}</div>
        <div className="flex-1 min-w-0">
          <h4 className="font-bold text-sm leading-snug">{activeToast.title}</h4>
          <p className="text-xs mt-0.5 opacity-90 leading-relaxed">{activeToast.message}</p>
        </div>
      </div>
    </div>
  );
};
