import React, { useState, useEffect } from 'react';
import { useNews } from '../../context/NewsContext';
import {
  Sun,
  Moon,
  Search,
  Bell,
  Sparkles,
  CloudSun,
  Clock,
  LayoutDashboard,
  Shield,
  PenTool,
  CheckCheck,
  ExternalLink,
  ChevronDown,
  UserCheck,
  Radio,
  LogIn,
} from 'lucide-react';
import { UserRole } from '../../types';

interface HeaderProps {
  onOpenAiSearch: () => void;
  onNavigateToDashboard: (tab?: string) => void;
  onSelectArticle: (id: string) => void;
  currentView: 'portal' | 'dashboard';
  onNavigateToPortal: () => void;
  onOpenAuthModal?: (role?: 'admin' | 'publisher') => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenAiSearch,
  onNavigateToDashboard,
  onSelectArticle,
  currentView,
  onNavigateToPortal,
  onOpenAuthModal,
}) => {
  const {
    currentUser,
    allUsers,
    switchUserRole,
    siteSettings,
    notifications,
    unreadNotifCount,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    isDarkMode,
    toggleDarkMode,
    pushSubscriptionActive,
    togglePushNotifications,
    advertisements,
  } = useNews();

  const [currentTimeStr, setCurrentTimeStr] = useState<string>('');
  const [currentDateStr, setCurrentDateStr] = useState<string>('');
  const [showNotifMenu, setShowNotifMenu] = useState<boolean>(false);
  const [showRoleMenu, setShowRoleMenu] = useState<boolean>(false);

  // Live Clock & Indonesian Date
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTimeStr(
        now.toLocaleTimeString('id-ID', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: false,
        }) + ' WIB'
      );
      setCurrentDateStr(
        now.toLocaleDateString('id-ID', {
          weekday: 'long',
          day: 'numeric',
          month: 'long',
          year: 'numeric',
        })
      );
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const headerAd = advertisements.find((ad) => ad.position === 'header' && ad.isActive);

  return (
    <header className="w-full bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 transition-colors sticky top-0 z-40 shadow-xs">
      {/* Main Brand Header with Search & CMS Access */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Logo and Tagline */}
        <div
          onClick={onNavigateToPortal}
          className="flex items-center gap-3 cursor-pointer group select-none"
        >
          <div className="w-11 h-11 bg-linear-to-tr from-red-600 to-red-700 rounded-xl flex items-center justify-center text-white font-black text-2xl shadow-md shadow-red-600/30 group-hover:scale-105 transition-transform">
            P
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900 dark:text-white leading-none">
                PAMANUKAN <span className="text-red-600">NEWS</span>
              </h1>
              <span className="bg-red-100 dark:bg-red-950/70 text-red-700 dark:text-red-300 text-[10px] font-extrabold px-1.5 py-0.5 rounded tracking-widest uppercase">
                PANTURA
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-1">
              {siteSettings.tagline}
            </p>
          </div>
        </div>

        {/* Header Ad Slot (if active) */}
        {headerAd && (
          <a
            href={headerAd.linkUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden lg:block border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden relative hover:opacity-95 transition"
            title={headerAd.title}
          >
            <span className="absolute top-1 right-1 bg-black/60 text-[9px] text-white px-1.5 py-0.2 rounded font-mono">
              IKLAN
            </span>
            <img
              src={headerAd.imageUrl}
              alt={headerAd.title}
              className="h-14 w-auto max-w-[460px] object-cover"
            />
          </a>
        )}

        {/* Right Tools: AI Search, Notifications, Dark Mode, CMS Button */}
        <div className="flex items-center gap-2.5">
          {/* AI Search Button */}
          <button
            onClick={onOpenAiSearch}
            className="flex items-center gap-2 px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-red-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl border border-slate-200 dark:border-slate-700 transition cursor-pointer text-xs font-semibold group"
          >
            <Sparkles className="w-4 h-4 text-red-600 group-hover:rotate-12 transition-transform" />
            <span className="hidden sm:inline">Pencarian AI Arsip</span>
            <kbd className="hidden sm:inline text-[10px] bg-white dark:bg-slate-900 px-1.5 py-0.5 rounded border border-slate-300 dark:border-slate-600 text-slate-400">
              ⌘K
            </kbd>
          </button>

          {/* Notification Center */}
          <div className="relative">
            <button
              onClick={() => setShowNotifMenu(!showNotifMenu)}
              className="relative p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
              title="Pemberitahuan & Update Berita"
            >
              <Bell className="w-5 h-5" />
              {unreadNotifCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-red-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-bounce">
                  {unreadNotifCount}
                </span>
              )}
            </button>

            {/* Notification Dropdown */}
            {showNotifMenu && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 py-3 z-50 overflow-hidden">
                <div className="flex items-center justify-between px-4 pb-2 border-b border-slate-100 dark:border-slate-700/60">
                  <div className="flex items-center gap-2">
                    <Bell className="w-4 h-4 text-red-600" />
                    <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                      Notifikasi Real-Time
                    </h3>
                  </div>
                  {unreadNotifCount > 0 && (
                    <button
                      onClick={markAllNotificationsAsRead}
                      className="text-[11px] text-red-600 dark:text-red-400 font-semibold hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <CheckCheck className="w-3.5 h-3.5" />
                      Tandai dibaca
                    </button>
                  )}
                </div>

                <div className="max-h-80 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-700/40">
                  {notifications.length === 0 ? (
                    <div className="p-6 text-center text-slate-400 text-xs">
                      Belum ada notifikasi baru.
                    </div>
                  ) : (
                    notifications.map((notif) => (
                      <div
                        key={notif.id}
                        onClick={() => {
                          markNotificationAsRead(notif.id);
                          if (notif.articleId) {
                            onSelectArticle(notif.articleId);
                            setShowNotifMenu(false);
                          }
                        }}
                        className={`p-3.5 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition cursor-pointer ${
                          !notif.isRead ? 'bg-red-50/50 dark:bg-red-950/20' : ''
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                            {notif.title}
                          </h4>
                          <span className="text-[10px] text-slate-400 shrink-0">
                            {new Date(notif.createdAt).toLocaleTimeString('id-ID', {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 line-clamp-2">
                          {notif.message}
                        </p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Dark Mode Switcher */}
          <button
            onClick={toggleDarkMode}
            className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            title="Ganti Mode Gelap / Terang"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Simple Modern Login Button on Portal */}
          {currentView === 'portal' && onOpenAuthModal && (
            <button
              onClick={() => onOpenAuthModal('admin')}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 hover:text-slate-900 dark:hover:text-white bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 transition cursor-pointer"
              title="Masuk ke Akun"
            >
              <LogIn className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400 shrink-0" />
              <span className="hidden sm:inline">Masuk</span>
            </button>
          )}

          {/* Return to Portal Button when in Dashboard */}
          {currentView !== 'portal' && (
            <button
              onClick={onNavigateToPortal}
              className="flex items-center gap-2 px-3.5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition shadow-sm cursor-pointer"
            >
              <ExternalLink className="w-4 h-4" />
              <span>Lihat Portal</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
