import React, { useState } from 'react';
import { useNews } from '../../context/NewsContext';
import {
  Lock,
  Mail,
  User,
  ArrowRight,
  Eye,
  EyeOff,
  X,
  CheckCircle2,
  AlertCircle,
  Loader2,
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (targetRole: 'admin' | 'publisher') => void;
  defaultRole?: 'admin' | 'publisher';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { loginWithSupabaseAuth, registerWithSupabaseAuth, switchUserRole } = useNews();

  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMsg('');
    setSuccessMsg('');

    const targetEmail = email.trim();
    const targetPassword = password;
    const targetName = name.trim();

    try {
      if (authMode === 'register') {
        const res = await registerWithSupabaseAuth(
          targetEmail,
          targetPassword,
          targetName,
          targetEmail.toLowerCase().includes('admin') || targetEmail.toLowerCase().includes('pemred')
            ? 'admin'
            : 'publisher'
        );

        if (res.success) {
          setSuccessMsg('Pendaftaran akun berhasil! Silakan masuk dengan akun Anda.');
          setAuthMode('login');
        } else {
          setErrorMsg(res.error || 'Gagal mendaftarkan akun di Supabase.');
        }
      } else {
        // Direct login with Supabase account
        const loginRes = await loginWithSupabaseAuth(targetEmail, targetPassword);

        if (loginRes.success) {
          const role = (loginRes.role || 'publisher') as 'admin' | 'publisher';
          onSuccess(role);
          onClose();
        } else {
          setErrorMsg(
            loginRes.error ||
              'Email atau kata sandi tidak valid. Pastikan akun sudah terdaftar di Supabase.'
          );
        }
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Terjadi kendala saat menghubungkan ke Supabase.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
      <div className="relative w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-800 overflow-hidden my-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="pt-8 px-6 pb-2 text-center">
          <div className="w-12 h-12 bg-linear-to-tr from-red-600 to-red-700 rounded-2xl mx-auto flex items-center justify-center text-white font-black text-xl shadow-md shadow-red-600/30 mb-3">
            P
          </div>
          <h3 className="text-xl font-black text-slate-900 dark:text-white">
            {authMode === 'login' ? 'Masuk ke Akun' : 'Daftar Akun Baru'}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            PAMANUKAN NEWS
          </p>

          {/* Mode Tabs */}
          <div className="mt-4 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl flex items-center">
            <button
              type="button"
              onClick={() => {
                setAuthMode('login');
                setErrorMsg('');
                setSuccessMsg('');
              }}
              className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                authMode === 'login'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Masuk
            </button>
            <button
              type="button"
              onClick={() => {
                setAuthMode('register');
                setErrorMsg('');
                setSuccessMsg('');
              }}
              className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                authMode === 'register'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Daftar
            </button>
          </div>
        </div>

        {/* Form Body */}
        <div className="px-6 py-5">
          <form onSubmit={handleSubmit} className="space-y-3.5">
            {/* If Register Mode: Name Input */}
            {authMode === 'register' && (
              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Nama Lengkap
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Nama Lengkap"
                    className="w-full bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-xs pl-9 pr-3.5 py-2.5 rounded-xl outline-none focus:ring-2 focus:ring-red-500 focus:bg-white dark:focus:bg-slate-800 transition font-medium"
                  />
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                </div>
              </div>
            )}

            {/* Email Input */}
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Email
              </label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-xs pl-9 pr-3.5 py-2.5 rounded-xl outline-none focus:ring-2 focus:ring-red-500 focus:bg-white dark:focus:bg-slate-800 transition font-medium"
                />
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              </div>
            </div>

            {/* Password Input */}
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Kata Sandi
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-xs pl-9 pr-10 py-2.5 rounded-xl outline-none focus:ring-2 focus:ring-red-500 focus:bg-white dark:focus:bg-slate-800 transition font-medium"
                />
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Error Message */}
            {errorMsg && (
              <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 text-xs flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <div className="flex-1 leading-snug">
                  <span>{errorMsg}</span>
                </div>
              </div>
            )}

            {/* Success Message */}
            {successMsg && (
              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{successMsg}</span>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 px-4 rounded-xl text-white text-xs font-bold transition shadow-md flex items-center justify-center gap-2 cursor-pointer bg-red-600 hover:bg-red-700 disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Memproses...</span>
                </>
              ) : (
                <>
                  <span>{authMode === 'login' ? 'Masuk' : 'Daftar Akun'}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>

            {/* Quick Demo Access */}
            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
              <p className="text-[11px] font-bold text-center text-slate-500">
                Akses Instan Demo Redaksi:
              </p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    switchUserRole('admin');
                    onSuccess('admin');
                    onClose();
                  }}
                  className="py-1.5 px-2 rounded-lg border border-red-200 dark:border-red-900/40 bg-red-50 dark:bg-red-950/30 text-red-700 dark:text-red-300 text-[11px] font-bold hover:bg-red-100 transition cursor-pointer text-center"
                >
                  Masuk sbg Pemred (Admin)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    switchUserRole('publisher');
                    onSuccess('publisher');
                    onClose();
                  }}
                  className="py-1.5 px-2 rounded-lg border border-blue-200 dark:border-blue-900/40 bg-blue-50 dark:bg-blue-950/30 text-blue-700 dark:text-blue-300 text-[11px] font-bold hover:bg-blue-100 transition cursor-pointer text-center"
                >
                  Masuk sbg Publisher
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
