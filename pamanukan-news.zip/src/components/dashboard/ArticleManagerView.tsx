import React, { useState } from 'react';
import { useNews } from '../../context/NewsContext';
import { Article, ArticleStatus } from '../../types';
import {
  Search,
  Filter,
  CheckCircle,
  XCircle,
  Eye,
  Edit,
  Trash2,
  Send,
  Flame,
  Award,
  Clock,
  AlertCircle,
  ChevronRight,
  MessageSquare,
} from 'lucide-react';

interface ArticleManagerViewProps {
  onEditArticle: (article: Article) => void;
  onPreviewArticle: (articleId: string) => void;
  onAddNew: () => void;
}

export const ArticleManagerView: React.FC<ArticleManagerViewProps> = ({
  onEditArticle,
  onPreviewArticle,
  onAddNew,
}) => {
  const {
    articles,
    categories,
    currentUser,
    approveAndPublishArticle,
    rejectArticle,
    deleteArticle,
    updateArticle,
    submitArticleForReview,
  } = useNews();

  const [activeTab, setActiveTab] = useState<'all' | ArticleStatus>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCat, setSelectedCat] = useState('all');

  // Review Modal State
  const [reviewingArticle, setReviewingArticle] = useState<Article | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');

  // Per user workflow specification: Publisher has Buat Berita, Edit Berita, Upload Media, Submit Berita, Review, Publish
  const canModerate = currentUser.role === 'admin' || currentUser.role === 'editor' || currentUser.role === 'publisher';

  // Filter articles
  let filtered = articles;

  // If user is a junior publisher, they can see their own articles or published ones
  if (currentUser.role === 'publisher') {
    // Publishers see all articles to stay informed, but can only edit their own
  }

  if (activeTab !== 'all') {
    filtered = filtered.filter((a) => a.status === activeTab);
  }

  if (selectedCat !== 'all') {
    filtered = filtered.filter((a) => a.categoryId === selectedCat);
  }

  if (searchQuery.trim()) {
    const q = searchQuery.toLowerCase();
    filtered = filtered.filter(
      (a) =>
        a.title.toLowerCase().includes(q) ||
        a.authorName.toLowerCase().includes(q) ||
        a.summary.toLowerCase().includes(q)
    );
  }

  const counts = {
    all: articles.length,
    published: articles.filter((a) => a.status === 'published').length,
    pending: articles.filter((a) => a.status === 'pending').length,
    draft: articles.filter((a) => a.status === 'draft').length,
    rejected: articles.filter((a) => a.status === 'rejected').length,
  };

  const statusBadges: Record<ArticleStatus, { label: string; class: string }> = {
    published: { label: 'Terbit', class: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' },
    pending: { label: 'Menunggu Review', class: 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 animate-pulse' },
    draft: { label: 'Draft', class: 'bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-300' },
    rejected: { label: 'Perlu Revisi', class: 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300' },
    archived: { label: 'Arsip', class: 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300' },
  };

  return (
    <div className="space-y-6">
      {/* Top Header & New Button */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
            Kelola Berita & Editorial Workflow
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Manajemen alur naskah: Draft ➔ Submit ➔ Review Redaktur ➔ Terbit Real-time.
          </p>
        </div>

        <button
          onClick={onAddNew}
          className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition shadow-md shadow-red-600/30 flex items-center gap-1.5 cursor-pointer"
        >
          <span>+ Tulis Berita Baru</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 overflow-x-auto pb-2 border-b border-slate-200 dark:border-slate-800">
        {(
          [
            { key: 'all', label: 'Semua Berita', count: counts.all },
            { key: 'published', label: 'Sudah Terbit', count: counts.published },
            { key: 'pending', label: 'Menunggu Review', count: counts.pending },
            { key: 'draft', label: 'Draft Penulis', count: counts.draft },
            { key: 'rejected', label: 'Perlu Revisi', count: counts.rejected },
          ] as const
        ).map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer ${
              activeTab === tab.key
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <span>{tab.label}</span>
            <span
              className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                activeTab === tab.key
                  ? 'bg-red-700 text-white'
                  : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
              }`}
            >
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3.5 top-2.5 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Cari berdasarkan judul, penulis, atau kata kunci..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white placeholder-slate-400 text-xs pl-10 pr-4 py-2.5 rounded-xl outline-none focus:ring-2 focus:ring-red-500"
          />
        </div>

        <select
          value={selectedCat}
          onChange={(e) => setSelectedCat(e.target.value)}
          className="w-full sm:w-48 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 text-xs px-3 py-2.5 rounded-xl outline-none"
        >
          <option value="all">Semua Kategori</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </div>

      {/* Articles Table */}
      <div className="bg-white dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-700/50 text-slate-500 dark:text-slate-400 uppercase tracking-wider font-bold border-b border-slate-200 dark:border-slate-700/60">
              <tr>
                <th className="py-3 px-4">Artikel & Sampul</th>
                <th className="py-3 px-3">Kategori</th>
                <th className="py-3 px-3">Penulis</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3">Tayang</th>
                <th className="py-3 px-4 text-right">Aksi & Workflow</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700/40">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">
                    Tidak ada artikel di kategori ini.
                  </td>
                </tr>
              ) : (
                filtered.map((art) => {
                  const badge = statusBadges[art.status] || statusBadges.draft;
                  const canEditThis =
                    currentUser.role === 'admin' ||
                    currentUser.role === 'editor' ||
                    art.authorId === currentUser.id;

                  return (
                    <tr
                      key={art.id}
                      className="hover:bg-slate-50/70 dark:hover:bg-slate-700/30 transition"
                    >
                      {/* Title & Thumbnail */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={art.coverImage}
                            alt={art.title}
                            className="w-14 h-11 rounded-lg object-cover shrink-0"
                          />
                          <div className="min-w-0 max-w-md">
                            <div className="flex items-center gap-1.5 mb-0.5">
                              {art.isHeadline && (
                                <span className="bg-red-600 text-white text-[9px] font-black px-1.5 py-0.2 rounded uppercase">
                                  Headline
                                </span>
                              )}
                              {art.isEditorPick && (
                                <span className="bg-amber-400 text-slate-900 text-[9px] font-bold px-1.5 py-0.2 rounded uppercase">
                                  Pilihan
                                </span>
                              )}
                              <span className="text-[10px] text-slate-400">
                                {new Date(art.updatedAt || art.createdAt).toLocaleDateString('id-ID')}
                              </span>
                            </div>
                            <h4
                              onClick={() => onPreviewArticle(art.id)}
                              className="font-bold text-slate-900 dark:text-white truncate hover:text-red-600 cursor-pointer"
                            >
                              {art.title}
                            </h4>
                            {art.rejectionReason && (
                              <p className="text-[11px] text-red-500 italic mt-0.5">
                                Catatan revisi: "{art.rejectionReason}"
                              </p>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Category */}
                      <td className="py-3 px-3">
                        <span className="font-semibold text-slate-700 dark:text-slate-300">
                          {art.categoryName}
                        </span>
                      </td>

                      {/* Author */}
                      <td className="py-3 px-3">
                        <span className="text-slate-600 dark:text-slate-300 font-medium">
                          {art.authorName}
                        </span>
                      </td>

                      {/* Status */}
                      <td className="py-3 px-3">
                        <span className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold ${badge.class}`}>
                          {badge.label}
                        </span>
                      </td>

                      {/* Views */}
                      <td className="py-3 px-3 font-mono font-semibold text-slate-700 dark:text-slate-300">
                        {art.views.toLocaleString('id-ID')}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Preview in Reader View */}
                          <button
                            onClick={() => onPreviewArticle(art.id)}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-slate-100 dark:hover:bg-slate-700 transition"
                            title="Pratinjau Berita"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          {/* Submit if Draft or Rejected (Publisher) */}
                          {(art.status === 'draft' || art.status === 'rejected') && (
                            <button
                              onClick={() => submitArticleForReview(art.id)}
                              className="px-2 py-1 bg-blue-50 dark:bg-blue-950/40 text-blue-600 hover:bg-blue-100 rounded-lg text-[11px] font-bold transition flex items-center gap-1"
                              title="Ajukan ke Redaktur"
                            >
                              <Send className="w-3 h-3" />
                              <span>Submit</span>
                            </button>
                          )}

                          {/* Approve & Reject for Editors/Admins */}
                          {canModerate && art.status === 'pending' && (
                            <>
                              <button
                                onClick={() => approveAndPublishArticle(art.id)}
                                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[11px] font-bold transition flex items-center gap-1 shadow-xs"
                                title="Setujui & Terbitkan Berita"
                              >
                                <CheckCircle className="w-3.5 h-3.5" />
                                <span>Terbitkan</span>
                              </button>

                              <button
                                onClick={() => setReviewingArticle(art)}
                                className="px-2.5 py-1 bg-red-100 dark:bg-red-950 text-red-600 hover:bg-red-200 rounded-lg text-[11px] font-bold transition flex items-center gap-1"
                                title="Minta Revisi"
                              >
                                <XCircle className="w-3.5 h-3.5" />
                                <span>Revisi</span>
                              </button>
                            </>
                          )}

                          {/* Edit button */}
                          {canEditThis && (
                            <button
                              onClick={() => onEditArticle(art)}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-slate-100 dark:hover:bg-slate-700 transition"
                              title="Edit Konten"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                          )}

                          {/* Delete */}
                          {(currentUser.role === 'admin' || art.authorId === currentUser.id) && (
                            <button
                              onClick={() => {
                                if (confirm(`Hapus artikel "${art.title}"?`)) {
                                  deleteArticle(art.id);
                                }
                              }}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-slate-100 dark:hover:bg-slate-700 transition"
                              title="Hapus"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Review Modal */}
      {reviewingArticle && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-lg w-full shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-red-600" />
              <h3 className="text-base font-black text-slate-900 dark:text-white">
                Kirim Catatan Revisi Redaksi
              </h3>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300">
              Artikel: <strong className="text-slate-900 dark:text-white">{reviewingArticle.title}</strong>
            </p>

            <textarea
              rows={4}
              placeholder="Jelaskan bagian mana yang perlu diperbaiki (misal: verifikasi nama narasumber, tambahkan kutipan warga, atau perbaiki lead berita)..."
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-2xl p-3 text-xs text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-red-500"
            />

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setReviewingArticle(null);
                  setRejectionReason('');
                }}
                className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-200 transition"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  if (!rejectionReason.trim()) {
                    alert('Harap masukkan catatan revisi.');
                    return;
                  }
                  rejectArticle(reviewingArticle.id, rejectionReason.trim());
                  setReviewingArticle(null);
                  setRejectionReason('');
                }}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition shadow-xs"
              >
                Kirim Catatan Revisi
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
