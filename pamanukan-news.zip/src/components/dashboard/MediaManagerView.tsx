import React, { useState } from 'react';
import { useNews } from '../../context/NewsContext';
import { compressImage, formatBytes } from '../../services/imageCompression';
import {
  Upload,
  Image as ImageIcon,
  Trash2,
  Copy,
  Check,
  Sparkles,
  Maximize2,
  Sliders,
} from 'lucide-react';

export const MediaManagerView: React.FC = () => {
  const { mediaItems, addMediaItem, deleteMediaItem, currentUser } = useNews();
  const [isUploading, setIsUploading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [quality, setQuality] = useState<number>(0.8);
  const [uploadStatus, setUploadStatus] = useState<string>('');

  const totalOriginal = mediaItems.reduce((acc, m) => acc + (m.originalSize || 0), 0);
  const totalCompressed = mediaItems.reduce((acc, m) => acc + (m.compressedSize || 0), 0);
  const totalSaved = Math.max(0, totalOriginal - totalCompressed);
  const overallSavedPct =
    totalOriginal > 0 ? Math.round((totalSaved / totalOriginal) * 100) : 0;

  const handleMultipleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    setUploadStatus(`Mengompresi ${files.length} gambar...`);

    let processedCount = 0;
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      try {
        const result = await compressImage(file, {
          maxWidth: 1280,
          maxHeight: 850,
          quality,
          format: 'image/webp',
        });

        addMediaItem({
          name: file.name.replace(/\.[^/.]+$/, '') + '.webp',
          url: result.dataUrl,
          originalSize: result.originalSize,
          compressedSize: result.compressedSize,
          mimeType: result.mimeType,
          width: result.width,
          height: result.height,
          uploadedBy: currentUser.id,
          uploadedByName: currentUser.name,
        });

        processedCount++;
        setUploadStatus(`Berhasil mengompresi ${processedCount} dari ${files.length} gambar...`);
      } catch (err) {
        console.error('Failed to compress media item:', err);
      }
    }

    setIsUploading(false);
    setUploadStatus('');
  };

  const handleCopyUrl = (id: string, url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
            Pustaka Media & Kompresi Otomatis
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Kompresi otomatis WebP untuk mempercepat waktu pemuatan artikel berita.
          </p>
        </div>

        {/* Compression Savings Pill */}
        <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-500/30 px-4 py-2 rounded-2xl flex items-center gap-3 text-xs">
          <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center font-black">
            ⚡
          </div>
          <div>
            <p className="font-extrabold text-emerald-800 dark:text-emerald-300">
              Total Hemat Bandwidth: {overallSavedPct}% ({formatBytes(totalSaved)})
            </p>
            <p className="text-[11px] text-emerald-700/80 dark:text-emerald-400">
              Asli: {formatBytes(totalOriginal)} ➔ WebP: {formatBytes(totalCompressed)}
            </p>
          </div>
        </div>
      </div>

      {/* Uploader Box */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-800/80 border-2 border-dashed border-red-500/40 hover:border-red-500 transition-colors shadow-xs">
        <div className="flex flex-col items-center justify-center text-center space-y-3">
          <div className="w-14 h-14 rounded-2xl bg-red-50 dark:bg-red-950/60 text-red-600 flex items-center justify-center shadow-inner">
            <Upload className="w-7 h-7" />
          </div>

          <div>
            <h3 className="text-sm font-black text-slate-900 dark:text-white">
              Unggah Foto Liputan Berita
            </h3>
            <p className="text-xs text-slate-500 mt-1 max-w-md">
              Seret dan lepaskan beberapa foto sekaligus (JPEG/PNG/WebP). Sistem akan otomatis memperkecil ukuran hingga 90% tanpa menurunkan ketajaman visual.
            </p>
          </div>

          {/* Quality slider */}
          <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-700/60 px-3.5 py-1.5 rounded-xl text-xs">
            <Sliders className="w-3.5 h-3.5 text-slate-500" />
            <span className="font-semibold text-slate-600 dark:text-slate-300">
              Tingkat Kualitas Kompresi: {Math.round(quality * 100)}%
            </span>
            <input
              type="range"
              min="0.5"
              max="0.95"
              step="0.05"
              value={quality}
              onChange={(e) => setQuality(parseFloat(e.target.value))}
              className="accent-red-600 w-24 cursor-pointer"
            />
          </div>

          <label className="mt-2 px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition shadow-md shadow-red-600/30 cursor-pointer flex items-center gap-2">
            <Upload className="w-4 h-4" />
            <span>Pilih File dari Perangkat</span>
            <input
              type="file"
              multiple
              accept="image/jpeg,image/png,image/webp"
              onChange={handleMultipleUpload}
              className="hidden"
            />
          </label>

          {isUploading && (
            <div className="pt-2 text-xs font-bold text-red-600 flex items-center gap-2">
              <span className="w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full animate-spin" />
              <span>{uploadStatus}</span>
            </div>
          )}
        </div>
      </div>

      {/* Media Grid */}
      <div className="space-y-3">
        <h3 className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400">
          Galeri Media Terkompresi ({mediaItems.length})
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {mediaItems.map((item) => {
            const savedPct =
              item.originalSize > 0
                ? Math.round(
                    ((item.originalSize - item.compressedSize) / item.originalSize) * 100
                  )
                : 0;

            return (
              <div
                key={item.id}
                className="group rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs hover:border-red-500/40 hover:shadow-md transition flex flex-col justify-between"
              >
                {/* Image */}
                <div className="relative h-40 bg-slate-100 dark:bg-slate-700 overflow-hidden">
                  <img
                    src={item.url}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                    loading="lazy"
                  />
                  {savedPct > 0 && (
                    <span className="absolute top-2 left-2 bg-emerald-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full shadow-sm">
                      Hemat {savedPct}%
                    </span>
                  )}
                  <span className="absolute bottom-2 right-2 bg-black/70 text-white text-[10px] px-1.5 py-0.5 rounded font-mono">
                    {item.width} x {item.height}
                  </span>
                </div>

                {/* Details */}
                <div className="p-3.5 space-y-2">
                  <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    {item.name}
                  </p>

                  <div className="flex items-center justify-between text-[11px] text-slate-500">
                    <span>{formatBytes(item.compressedSize)}</span>
                    <span className="line-through text-slate-400">
                      {formatBytes(item.originalSize)}
                    </span>
                  </div>

                  <p className="text-[10px] text-slate-400 truncate">
                    Oleh: {item.uploadedByName}
                  </p>

                  {/* Actions */}
                  <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
                    <button
                      onClick={() => handleCopyUrl(item.id, item.url)}
                      className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-[11px] font-bold hover:bg-slate-200 transition flex items-center gap-1 cursor-pointer"
                    >
                      {copiedId === item.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-500" />
                          <span>Tersalin!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Salin URL</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={() => {
                        if (confirm(`Hapus media "${item.name}"?`)) {
                          deleteMediaItem(item.id);
                        }
                      }}
                      className="p-1 rounded-lg text-slate-400 hover:text-red-600 transition cursor-pointer"
                      title="Hapus media"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
