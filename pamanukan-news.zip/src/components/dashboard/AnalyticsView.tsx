import React, { useState, useEffect } from 'react';
import { useNews } from '../../context/NewsContext';
import {
  Users,
  Eye,
  Clock,
  TrendingUp,
  Smartphone,
  Monitor,
  Tablet,
  MapPin,
  Flame,
  ArrowUpRight,
  Activity,
  Calendar,
  Share2,
  RefreshCw,
} from 'lucide-react';

export const AnalyticsView: React.FC = () => {
  const { articles } = useNews();
  const [activeReaders, setActiveReaders] = useState<number>(142);

  // Simulate real-time active readers fluctuation
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveReaders((prev) => {
        const delta = Math.floor(Math.random() * 7) - 3;
        return Math.max(80, Math.min(320, prev + delta));
      });
    }, 3500);
    return () => clearInterval(interval);
  }, []);

  const totalViews = articles.reduce((sum, a) => sum + (a.views || 0), 0);
  const publishedCount = articles.filter((a) => a.status === 'published').length;
  const pendingCount = articles.filter((a) => a.status === 'pending').length;

  const topArticles = [...articles]
    .filter((a) => a.status === 'published')
    .sort((a, b) => b.views - a.views)
    .slice(0, 5);

  const regionData = [
    { name: 'Pamanukan Kota', percentage: 41, count: '14,250' },
    { name: 'Subang Kota', percentage: 23, count: '7,980' },
    { name: 'Kawasan Patimban & Pusakanagara', percentage: 15, count: '5,210' },
    { name: 'Ciasem & Sukamandi', percentage: 12, count: '4,170' },
    { name: 'Pagaden & Jalancagak', percentage: 9, count: '3,120' },
  ];

  const weeklyTraffic = [
    { day: 'Sen', views: 12400, height: '55%' },
    { day: 'Sel', views: 14800, height: '65%' },
    { day: 'Rab', views: 16200, height: '72%' },
    { day: 'Kam', views: 15100, height: '67%' },
    { day: 'Jum', views: 18900, height: '84%' },
    { day: 'Sab', views: 22400, height: '100%' },
    { day: 'Min', views: 20100, height: '90%' },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner: Real-Time Readers Activity */}
      <div className="p-6 rounded-3xl bg-linear-to-r from-slate-900 via-red-950 to-slate-900 text-white border border-slate-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500" />
            </span>
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
              Live Monitoring Pembaca Real-Time
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
            Dasbor Analitik Ruang Redaksi
          </h2>
          <p className="text-xs text-slate-300">
            Memantau keterlibatan pembaca, sebaran geografis Pantura, dan tren performa konten.
          </p>
        </div>

        {/* Big Live Number */}
        <div className="bg-white/10 backdrop-blur-md px-6 py-4 rounded-2xl border border-white/15 flex items-center gap-4">
          <Activity className="w-8 h-8 text-emerald-400 animate-pulse" />
          <div>
            <div className="text-3xl sm:text-4xl font-black font-mono text-white">
              {activeReaders}
            </div>
            <p className="text-[11px] text-slate-300 font-semibold uppercase tracking-wider">
              Pembaca Aktif Saat Ini
            </p>
          </div>
        </div>
      </div>

      {/* 4 Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Pageviews */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-bold uppercase">Total Tayangan (Views)</span>
            <Eye className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white">
            {totalViews.toLocaleString('id-ID')}
          </div>
          <p className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>+18.4% minggu ini</span>
          </p>
        </div>

        {/* Avg Read Time */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-bold uppercase">Rata-rata Waktu Baca</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white">
            3m 48s
          </div>
          <p className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>Keterlibatan tinggi</span>
          </p>
        </div>

        {/* Scroll Depth Rate */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-bold uppercase">Rasio Scroll Depth (&gt;75%)</span>
            <TrendingUp className="w-4 h-4 text-purple-500" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white">
            76.2%
          </div>
          <p className="text-xs text-slate-500 font-medium">
            Pembaca menyelesaikan artikel
          </p>
        </div>

        {/* Published & Pending */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-800 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-bold uppercase">Status Konten Redaksi</span>
            <Calendar className="w-4 h-4 text-red-500" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white">
            {publishedCount} <span className="text-xs font-normal text-slate-400">Terbit</span>
          </div>
          <p className="text-xs text-amber-600 dark:text-amber-400 font-semibold">
            {pendingCount} artikel menunggu review
          </p>
        </div>
      </div>

      {/* Main Charts & Demographics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Weekly Traffic Chart (7 Cols) */}
        <div className="lg:col-span-7 p-6 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-700/60 pb-3">
            <div>
              <h3 className="font-black text-sm text-slate-900 dark:text-white uppercase tracking-tight">
                Tren Pembaca Mingguan (7 Hari Terakhir)
              </h3>
              <p className="text-xs text-slate-500">Puncak pembaca terjadi pada akhir pekan</p>
            </div>
            <span className="text-xs font-bold bg-slate-100 dark:bg-slate-700 px-2.5 py-1 rounded-lg text-slate-600 dark:text-slate-300">
              Total: 120.000+ views
            </span>
          </div>

          {/* Bar Chart Container */}
          <div className="h-56 flex items-end justify-between gap-2 pt-6 pb-2 px-2">
            {weeklyTraffic.map((bar, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity">
                  {bar.views.toLocaleString('id-ID')}
                </span>
                <div
                  style={{ height: bar.height }}
                  className={`w-full max-w-[42px] rounded-t-xl transition-all duration-500 ${
                    i === 5
                      ? 'bg-red-600 shadow-md shadow-red-600/30'
                      : 'bg-slate-200 dark:bg-slate-700 group-hover:bg-red-400'
                  }`}
                />
                <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                  {bar.day}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Demographics Pantura (5 Cols) */}
        <div className="lg:col-span-5 p-6 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-700/60 pb-3">
            <h3 className="font-black text-sm text-slate-900 dark:text-white uppercase tracking-tight flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-red-600" />
              <span>Sebaran Pembaca Wilayah</span>
            </h3>
            <span className="text-[11px] text-slate-400">Pantura Subang</span>
          </div>

          <div className="space-y-3 pt-1">
            {regionData.map((reg, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-800 dark:text-slate-200">{reg.name}</span>
                  <span className="text-slate-500 font-mono font-semibold">
                    {reg.percentage}% ({reg.count})
                  </span>
                </div>
                <div className="w-full bg-slate-100 dark:bg-slate-700 rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-red-600 h-2 rounded-full transition-all duration-700"
                    style={{ width: `${reg.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Device Breakdown */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-700/60 grid grid-cols-3 gap-2 text-center text-xs">
            <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-700/40">
              <Smartphone className="w-4 h-4 text-blue-500 mx-auto mb-1" />
              <p className="font-black text-slate-900 dark:text-white">71%</p>
              <p className="text-[10px] text-slate-400">Ponsel / HP</p>
            </div>
            <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-700/40">
              <Monitor className="w-4 h-4 text-purple-500 mx-auto mb-1" />
              <p className="font-black text-slate-900 dark:text-white">25%</p>
              <p className="text-[10px] text-slate-400">Komputer</p>
            </div>
            <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-700/40">
              <Tablet className="w-4 h-4 text-emerald-500 mx-auto mb-1" />
              <p className="font-black text-slate-900 dark:text-white">4%</p>
              <p className="text-[10px] text-slate-400">Tablet</p>
            </div>
          </div>
        </div>
      </div>

      {/* Top Performing Articles Table */}
      <div className="p-6 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-700/60 pb-3">
          <h3 className="font-black text-sm text-slate-900 dark:text-white uppercase tracking-tight flex items-center gap-1.5">
            <Flame className="w-4 h-4 text-amber-500" />
            <span>Leaderboard Artikel Terpopuler</span>
          </h3>
          <span className="text-xs text-slate-400">Performa 30 hari</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-700/50 text-slate-500 dark:text-slate-400 uppercase tracking-wider font-bold">
              <tr>
                <th className="py-2.5 px-4 rounded-l-lg">Peringkat & Judul</th>
                <th className="py-2.5 px-3">Kategori</th>
                <th className="py-2.5 px-3">Penulis</th>
                <th className="py-2.5 px-3">Tayangan</th>
                <th className="py-2.5 px-3">Komentar</th>
                <th className="py-2.5 px-4 rounded-r-lg">Waktu Baca</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700/40">
              {topArticles.map((art, idx) => (
                <tr key={art.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-700/30 transition">
                  <td className="py-3 px-4 flex items-center gap-3">
                    <span
                      className={`w-6 h-6 rounded-md flex items-center justify-center font-black text-xs shrink-0 ${
                        idx === 0
                          ? 'bg-amber-400 text-slate-950'
                          : idx === 1
                          ? 'bg-slate-300 text-slate-900'
                          : idx === 2
                          ? 'bg-amber-700 text-white'
                          : 'bg-slate-100 dark:bg-slate-700 text-slate-500'
                      }`}
                    >
                      {idx + 1}
                    </span>
                    <span className="font-bold text-slate-900 dark:text-white truncate max-w-sm">
                      {art.title}
                    </span>
                  </td>
                  <td className="py-3 px-3">
                    <span className="bg-red-50 dark:bg-red-950/60 text-red-600 dark:text-red-400 px-2 py-0.5 rounded font-semibold text-[11px]">
                      {art.categoryName}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-slate-600 dark:text-slate-300 font-medium">
                    {art.authorName}
                  </td>
                  <td className="py-3 px-3 font-mono font-bold text-slate-900 dark:text-white">
                    {art.views.toLocaleString('id-ID')}
                  </td>
                  <td className="py-3 px-3 text-slate-500 font-mono">
                    {art.commentsCount}
                  </td>
                  <td className="py-3 px-4 text-slate-500">
                    {art.readingTimeMinutes} menit
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
