import React, { useState } from 'react';
import { useNews } from '../../context/NewsContext';
import { generateSupabaseSQLSchema } from '../../services/supabaseService';
import {
  Database,
  CheckCircle,
  XCircle,
  Copy,
  Check,
  RefreshCw,
  ExternalLink,
  ShieldCheck,
  Code,
  RotateCcw,
} from 'lucide-react';

export const SupabaseSettingsView: React.FC = () => {
  const {
    supabaseConfig,
    updateSupabaseConfig,
    testSupabase,
    syncWithSupabase,
    resetToDefaultData,
  } = useNews();

  const [url, setUrl] = useState(supabaseConfig.url || '');
  const [anonKey, setAnonKey] = useState(supabaseConfig.anonKey || '');
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [copiedSql, setCopiedSql] = useState(false);

  const sqlSchema = generateSupabaseSQLSchema();

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await testSupabase(url, anonKey);
      setTestResult(res);
      if (res.success) {
        updateSupabaseConfig({
          url,
          anonKey,
          isConnected: true,
          lastSyncTime: new Date().toLocaleTimeString('id-ID'),
        });
      }
    } finally {
      setIsTesting(false);
    }
  };

  const handleSaveAndSync = async () => {
    updateSupabaseConfig({
      url,
      anonKey,
      isConnected: supabaseConfig.isConnected,
    });
    setIsSyncing(true);
    try {
      await syncWithSupabase();
    } finally {
      setIsSyncing(false);
    }
  };

  const handleCopySql = () => {
    navigator.clipboard.writeText(sqlSchema);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2500);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2.5">
            <Database className="w-6 h-6 text-emerald-500" />
            <span>Integrasi Database Supabase</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Sinkronkan seluruh artikel, pengguna, dan media PAMANUKAN NEWS dengan PostgreSQL Supabase.
          </p>
        </div>

        {/* Connection Status Badge */}
        <div
          className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-2 ${
            supabaseConfig.isConnected
              ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500/40 text-emerald-800 dark:text-emerald-300'
              : 'bg-amber-50 dark:bg-amber-950/40 border-amber-500/40 text-amber-800 dark:text-amber-300'
          }`}
        >
          <span
            className={`w-2.5 h-2.5 rounded-full ${
              supabaseConfig.isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'
            }`}
          />
          <span>
            {supabaseConfig.isConnected
              ? `Terhubung ke Supabase (${supabaseConfig.lastSyncTime || 'Aktif'})`
              : 'Mode Database Lokal (Offline Ready)'}
          </span>
        </div>
      </div>

      {/* Supabase Credentials Box */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
          <span>Kredensial API Project Supabase</span>
        </h3>
        <p className="text-xs text-slate-500">
          Dapatkan URL dan Anon Key dari dasbor proyek Supabase Anda di menu{' '}
          <strong className="text-slate-700 dark:text-slate-300">Project Settings ➔ API</strong>.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
              Project URL
            </label>
            <input
              type="text"
              placeholder="https://xyzcompany.supabase.co"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
              Anon Public API Key
            </label>
            <input
              type="password"
              placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
              value={anonKey}
              onChange={(e) => setAnonKey(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        </div>

        {/* Buttons */}
        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            type="button"
            onClick={handleTestConnection}
            disabled={isTesting || !url || !anonKey}
            className="px-4 py-2 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 disabled:opacity-50 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
          >
            {isTesting ? (
              <span className="w-3.5 h-3.5 border-2 border-slate-600 border-t-transparent rounded-full animate-spin" />
            ) : (
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
            )}
            <span>Uji Koneksi Supabase</span>
          </button>

          <button
            type="button"
            onClick={handleSaveAndSync}
            disabled={isSyncing || !url || !anonKey}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            {isSyncing ? (
              <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <RefreshCw className="w-4 h-4" />
            )}
            <span>Simpan & Sinkronkan Sekarang</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (confirm('Kembalikan ke data bawaan simulasi Pamanukan News?')) {
                resetToDefaultData();
              }
            }}
            className="px-3.5 py-2 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 text-xs font-semibold flex items-center gap-1.5 ml-auto"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Data Bawaan</span>
          </button>
        </div>

        {testResult && (
          <div
            className={`p-3.5 rounded-xl border text-xs flex items-center gap-2 ${
              testResult.success
                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500/30 text-emerald-800 dark:text-emerald-300'
                : 'bg-red-50 dark:bg-red-950/40 border-red-500/30 text-red-800 dark:text-red-300'
            }`}
          >
            {testResult.success ? (
              <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
            ) : (
              <XCircle className="w-4 h-4 text-red-500 shrink-0" />
            )}
            <span>{testResult.message}</span>
          </div>
        )}
      </div>

      {/* SQL Migration Generator Card */}
      <div className="p-6 rounded-3xl bg-slate-900 text-white border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-black flex items-center gap-2 text-white">
              <Code className="w-4 h-4 text-emerald-400" />
              <span>Skrip SQL DDL Schema Supabase (Siap Dijalankan)</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Salin dan tempel skrip berikut ke dalam <strong>Supabase SQL Editor</strong> untuk membuat seluruh tabel dan kebijakan keamanan (RLS).
            </p>
          </div>

          <button
            onClick={handleCopySql}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm cursor-pointer shrink-0"
          >
            {copiedSql ? (
              <>
                <Check className="w-4 h-4 text-white" />
                <span>Skrip SQL Tersalin!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Salin Skrip SQL</span>
              </>
            )}
          </button>
        </div>

        <div className="relative">
          <pre className="p-4 rounded-2xl bg-black/60 border border-white/10 text-emerald-300 font-mono text-[11px] overflow-x-auto max-h-72 leading-relaxed">
            {sqlSchema}
          </pre>
        </div>
      </div>
    </div>
  );
};
