import React, { useState } from 'react';
import { useNews } from '../../context/NewsContext';
import { Advertisement, AdPosition } from '../../types';
import { Plus, Edit, Trash2, ExternalLink, MousePointer, Eye, CheckCircle2 } from 'lucide-react';

export const AdManagerView: React.FC = () => {
  const { advertisements, addAd, updateAd, deleteAd } = useNews();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAd, setEditingAd] = useState<Advertisement | null>(null);

  const [title, setTitle] = useState('');
  const [position, setPosition] = useState<AdPosition>('header');
  const [imageUrl, setImageUrl] = useState('');
  const [linkUrl, setLinkUrl] = useState('');
  const [startDate, setStartDate] = useState('2026-09-01');
  const [endDate, setEndDate] = useState('2026-12-31');
  const [isActive, setIsActive] = useState(true);

  const handleOpenAdd = () => {
    setEditingAd(null);
    setTitle('');
    setPosition('header');
    setImageUrl('https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=728&h=90&auto=format&fit=crop&q=80');
    setLinkUrl('https://example.com');
    setStartDate('2026-09-01');
    setEndDate('2026-12-31');
    setIsActive(true);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (ad: Advertisement) => {
    setEditingAd(ad);
    setTitle(ad.title);
    setPosition(ad.position);
    setImageUrl(ad.imageUrl);
    setLinkUrl(ad.linkUrl);
    setStartDate(ad.startDate);
    setEndDate(ad.endDate);
    setIsActive(ad.isActive);
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !imageUrl.trim()) return;

    if (editingAd) {
      updateAd(editingAd.id, {
        title,
        position,
        imageUrl,
        linkUrl,
        startDate,
        endDate,
        isActive,
      });
    } else {
      addAd({
        title,
        position,
        imageUrl,
        linkUrl,
        startDate,
        endDate,
        isActive,
      });
    }

    setIsModalOpen(false);
  };

  const positionLabels: Record<AdPosition, string> = {
    header: 'Header Atas (728x90)',
    sidebar: 'Sidebar Kanan (300x250)',
    in_feed: 'Di Sela Berita (In-Feed)',
    popup: 'Pop-up Interstitial',
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
            Kelola Iklan & Banner Komersial
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Manajemen slot tayang pariwara, link rujukan, counter impresi, dan klik pembaca.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center gap-1.5 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Pasang Iklan Baru</span>
        </button>
      </div>

      {/* Ads Table */}
      <div className="bg-white dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 dark:bg-slate-700/50 text-slate-500 dark:text-slate-400 uppercase tracking-wider font-bold border-b border-slate-200 dark:border-slate-700/60">
            <tr>
              <th className="py-3 px-4">Banner & Klien</th>
              <th className="py-3 px-3">Penempatan Slot</th>
              <th className="py-3 px-3">Impresi</th>
              <th className="py-3 px-3">Klik</th>
              <th className="py-3 px-3">CTR (%)</th>
              <th className="py-3 px-3">Status</th>
              <th className="py-3 px-4 text-right">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-700/40">
            {advertisements.map((ad) => {
              const ctr = ad.impressions > 0 ? ((ad.clicks / ad.impressions) * 100).toFixed(2) : '0.00';

              return (
                <tr key={ad.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-700/30 transition">
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={ad.imageUrl}
                        alt={ad.title}
                        className="w-16 h-10 rounded-lg object-cover shrink-0 border border-slate-200 dark:border-slate-700"
                      />
                      <div className="max-w-xs min-w-0">
                        <p className="font-bold text-slate-900 dark:text-white truncate">{ad.title}</p>
                        <a
                          href={ad.linkUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="text-[11px] text-blue-500 hover:underline truncate block"
                        >
                          {ad.linkUrl}
                        </a>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-3 font-medium text-slate-700 dark:text-slate-300">
                    {positionLabels[ad.position]}
                  </td>
                  <td className="py-3 px-3 font-mono font-semibold text-slate-800 dark:text-slate-200">
                    {ad.impressions.toLocaleString('id-ID')}
                  </td>
                  <td className="py-3 px-3 font-mono font-semibold text-slate-800 dark:text-slate-200">
                    {ad.clicks.toLocaleString('id-ID')}
                  </td>
                  <td className="py-3 px-3 font-mono font-bold text-emerald-600 dark:text-emerald-400">
                    {ctr}%
                  </td>
                  <td className="py-3 px-3">
                    <button
                      onClick={() => updateAd(ad.id, { isActive: !ad.isActive })}
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold cursor-pointer transition ${
                        ad.isActive
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {ad.isActive ? 'Tayang' : 'Berhenti'}
                    </button>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => handleOpenEdit(ad)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-slate-100 dark:hover:bg-slate-700 transition"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Hapus iklan "${ad.title}"?`)) {
                            deleteAd(ad.id);
                          }
                        }}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-slate-100 dark:hover:bg-slate-700 transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Modal Add/Edit */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <h3 className="text-base font-black text-slate-900 dark:text-white">
              {editingAd ? 'Edit Iklan Banner' : 'Pasang Iklan Banner Baru'}
            </h3>

            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Nama Kampanye / Pengiklan
                </label>
                <input
                  type="text"
                  placeholder="Contoh: Bank bjb Pamanukan - KUR Bunga Rendah"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Posisi Penempatan Slot
                </label>
                <select
                  value={position}
                  onChange={(e) => setPosition(e.target.value as AdPosition)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-red-500"
                >
                  <option value="header">Header Atas (728x90)</option>
                  <option value="sidebar">Sidebar Kanan (300x250)</option>
                  <option value="in_feed">Di Sela Berita (In-Feed)</option>
                  <option value="popup">Pop-up Interstitial</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  URL Gambar Banner
                </label>
                <input
                  type="text"
                  placeholder="https://..."
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  URL Tujuan Klik (Landing Page)
                </label>
                <input
                  type="text"
                  placeholder="https://pengiklan.com"
                  value={linkUrl}
                  onChange={(e) => setLinkUrl(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="ad-active"
                  checked={isActive}
                  onChange={(e) => setIsActive(e.target.checked)}
                  className="accent-red-600 rounded"
                />
                <label htmlFor="ad-active" className="text-xs font-bold text-slate-700 dark:text-slate-300 cursor-pointer">
                  Aktifkan dan tayangkan banner sekarang
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-200 transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition shadow-xs"
                >
                  Simpan Iklan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
