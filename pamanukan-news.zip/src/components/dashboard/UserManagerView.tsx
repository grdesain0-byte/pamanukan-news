import React, { useState } from 'react';
import { useNews } from '../../context/NewsContext';
import { User, UserRole } from '../../types';
import { UserPlus, Shield, UserCheck, Ban, Edit, Trash2, Mail } from 'lucide-react';

export const UserManagerView: React.FC = () => {
  const { allUsers, addUser, updateUser, deleteUser, currentUser } = useNews();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<UserRole>('publisher');
  const [bio, setBio] = useState('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) return;

    addUser({
      name,
      email,
      role,
      bio,
      status: 'active',
      avatar: `https://images.unsplash.com/photo-${
        role === 'admin'
          ? '1534528741775-53994a69daeb'
          : role === 'publisher'
          ? '1507003211169-0a1dd7228f2d'
          : '1500648767791-00dcc994a43e'
      }?w=150&auto=format&fit=crop&q=80`,
    });

    setName('');
    setEmail('');
    setBio('');
    setIsModalOpen(false);
  };

  const roleBadges: Record<UserRole, { label: string; class: string }> = {
    admin: { label: 'Admin / Pemred', class: 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300 font-extrabold' },
    editor: { label: 'Editor / Redaktur', class: 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300 font-bold' },
    publisher: { label: 'Publisher / Wartawan', class: 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 font-bold' },
    reader: { label: 'Pembaca / Warga', class: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' },
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
            Kelola Pengguna & Multi-Peran (RBAC)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Manajemen hierarki hak akses tim redaksi: Admin, Redaktur, Publisher, dan Pembaca.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center gap-1.5 cursor-pointer"
        >
          <UserPlus className="w-4 h-4" />
          <span>Tambah Anggota Tim</span>
        </button>
      </div>

      {/* Users Table */}
      <div className="bg-white dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 dark:bg-slate-700/50 text-slate-500 dark:text-slate-400 uppercase tracking-wider font-bold border-b border-slate-200 dark:border-slate-700/60">
            <tr>
              <th className="py-3 px-4">Nama & Foto</th>
              <th className="py-3 px-3">Email Kontak</th>
              <th className="py-3 px-3">Peran Akses</th>
              <th className="py-3 px-3">Status</th>
              <th className="py-3 px-4 text-right">Ubah Peran / Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-700/40">
            {allUsers.map((user) => {
              const badge = roleBadges[user.role] || roleBadges.reader;
              const isCurrent = user.id === currentUser.id;

              return (
                <tr key={user.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-700/30 transition">
                  {/* Name & Avatar */}
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={user.avatar}
                        alt={user.name}
                        className="w-9 h-9 rounded-full object-cover ring-2 ring-slate-200 dark:ring-slate-700"
                      />
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-slate-900 dark:text-white">{user.name}</span>
                          {isCurrent && (
                            <span className="bg-amber-100 text-amber-900 text-[10px] font-black px-1.5 py-0.2 rounded">
                              Anda
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-400 line-clamp-1 max-w-xs">{user.bio || 'Staf Redaksi'}</p>
                      </div>
                    </div>
                  </td>

                  {/* Email */}
                  <td className="py-3 px-3 font-mono text-slate-600 dark:text-slate-300">{user.email}</td>

                  {/* Role Selector */}
                  <td className="py-3 px-3">
                    <select
                      value={user.role}
                      disabled={isCurrent && user.role === 'admin'}
                      onChange={(e) => updateUser(user.id, { role: e.target.value as UserRole })}
                      className="bg-slate-100 dark:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-600 outline-none font-semibold cursor-pointer"
                    >
                      <option value="admin">Admin</option>
                      <option value="editor">Editor</option>
                      <option value="publisher">Publisher</option>
                      <option value="reader">Reader</option>
                    </select>
                  </td>

                  {/* Status Toggle */}
                  <td className="py-3 px-3">
                    <button
                      onClick={() =>
                        updateUser(user.id, {
                          status: user.status === 'active' ? 'suspended' : 'active',
                        })
                      }
                      disabled={isCurrent}
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold transition cursor-pointer ${
                        user.status === 'active'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                      }`}
                    >
                      {user.status === 'active' ? 'Aktif' : 'Ditangguhkan'}
                    </button>
                  </td>

                  {/* Delete */}
                  <td className="py-3 px-4 text-right">
                    {!isCurrent && (
                      <button
                        onClick={() => {
                          if (confirm(`Hapus pengguna "${user.name}"?`)) {
                            deleteUser(user.id);
                          }
                        }}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-slate-100 dark:hover:bg-slate-700 transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Modal Add User */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <h3 className="text-base font-black text-slate-900 dark:text-white">
              Tambah Pengguna Baru
            </h3>

            <form onSubmit={handleAdd} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Nama Lengkap & Gelar
                </label>
                <input
                  type="text"
                  placeholder="Contoh: Hendra Wijaya, S.I.Kom"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Email Akun
                </label>
                <input
                  type="email"
                  placeholder="hendra@pamanukannews.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Peran Akun
                </label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as UserRole)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-red-500"
                >
                  <option value="publisher">Publisher / Jurnalis</option>
                  <option value="editor">Editor / Redaktur</option>
                  <option value="admin">Administrator / Pemred</option>
                  <option value="reader">Pembaca</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Bio Singkat / Penugasan Liputan
                </label>
                <input
                  type="text"
                  placeholder="Wartawan Liputan Pamanukan & Pantura Subang"
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-200 transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition shadow-xs"
                >
                  Simpan Pengguna
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
