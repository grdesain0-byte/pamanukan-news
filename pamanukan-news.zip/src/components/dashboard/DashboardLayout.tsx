import React, { useState } from 'react';
import { useNews } from '../../context/NewsContext';
import { Article } from '../../types';
import { AnalyticsView } from './AnalyticsView';
import { ArticleManagerView } from './ArticleManagerView';
import { ArticleEditorView } from './ArticleEditorView';
import { MediaManagerView } from './MediaManagerView';
import { CategoryManagerView } from './CategoryManagerView';
import { UserManagerView } from './UserManagerView';
import { AdManagerView } from './AdManagerView';
import { WebsiteSettingsView } from './WebsiteSettingsView';
import { SupabaseSettingsView } from './SupabaseSettingsView';
import {
  BarChart3,
  FileText,
  PenSquare,
  Image as ImageIcon,
  FolderTree,
  Users,
  Megaphone,
  Settings,
  Database,
  ArrowLeft,
  Sun,
  Moon,
  Shield,
  Menu,
  X,
  ExternalLink,
} from 'lucide-react';

interface DashboardLayoutProps {
  initialTab?: string;
  onNavigateToPortal: () => void;
  onPreviewArticle: (id: string) => void;
  onOpenAuthModal?: () => void;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({
  initialTab = 'analitik',
  onNavigateToPortal,
  onPreviewArticle,
  onOpenAuthModal,
}) => {
  const {
    currentUser,
    isDarkMode,
    toggleDarkMode,
    notifications,
    supabaseAuthUser,
    logoutSupabaseAuth,
  } = useNews();
  const [currentTab, setCurrentTab] = useState<string>(initialTab);
  const [editingArticle, setEditingArticle] = useState<Article | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const isAdmin = currentUser.role === 'admin';
  const isPublisher = currentUser.role === 'publisher';

  // Strict requested structure:
  // ADMIN:
  // ├── Kelola User
  // ├── Kelola Website
  // ├── Kelola Kategori
  // ├── Kelola Berita
  // ├── Kelola Media
  // ├── Kelola Iklan
  // └── Semua Permission (Database Supabase & Analitik Real-time)
  //
  // PUBLISHER:
  // ├── Buat Berita
  // ├── Edit Berita
  // ├── Upload Media
  // ├── Submit Berita
  // ├── Review
  // └── Publish

  const adminNavItems = [
    {
      id: 'analitik',
      label: 'Dasbor Analitik Real-Time',
      icon: <BarChart3 className="w-4 h-4" />,
      badge: 'Live',
    },
    {
      id: 'user',
      label: 'Kelola User',
      icon: <Users className="w-4 h-4" />,
    },
    {
      id: 'website',
      label: 'Kelola Website',
      icon: <Settings className="w-4 h-4" />,
    },
    {
      id: 'kategori',
      label: 'Kelola Kategori',
      icon: <FolderTree className="w-4 h-4" />,
    },
    {
      id: 'berita',
      label: 'Kelola Berita (Semua Izin)',
      icon: <FileText className="w-4 h-4" />,
    },
    {
      id: 'media',
      label: 'Kelola Media',
      icon: <ImageIcon className="w-4 h-4" />,
    },
    {
      id: 'iklan',
      label: 'Kelola Iklan',
      icon: <Megaphone className="w-4 h-4" />,
    },
    {
      id: 'supabase',
      label: 'Koneksi Supabase & Semua Permission',
      icon: <Database className="w-4 h-4" />,
      badge: 'Connected',
    },
  ];

  const publisherNavItems = [
    {
      id: 'tulis',
      label: 'Buat Berita',
      icon: <PenSquare className="w-4 h-4" />,
      badge: 'Tulis',
    },
    {
      id: 'berita',
      label: 'Edit & Kelola Berita',
      icon: <FileText className="w-4 h-4" />,
    },
    {
      id: 'media',
      label: 'Upload Media (Kompresi)',
      icon: <ImageIcon className="w-4 h-4" />,
    },
    {
      id: 'analitik',
      label: 'Analitik Pembaca Konten',
      icon: <BarChart3 className="w-4 h-4" />,
    },
  ];

  const activeNavItems = isAdmin ? adminNavItems : publisherNavItems;

  const handleEditArticle = (article: Article) => {
    setEditingArticle(article);
    setCurrentTab('tulis');
  };

  const handleAddNew = () => {
    setEditingArticle(null);
    setCurrentTab('tulis');
  };

  const renderActiveView = () => {
    switch (currentTab) {
      case 'analitik':
        return <AnalyticsView />;
      case 'berita':
        return (
          <ArticleManagerView
            onEditArticle={handleEditArticle}
            onPreviewArticle={onPreviewArticle}
            onAddNew={handleAddNew}
          />
        );
      case 'tulis':
        return (
          <ArticleEditorView
            initialArticle={editingArticle}
            onSaveComplete={() => {
              setEditingArticle(null);
              setCurrentTab('berita');
            }}
          />
        );
      case 'media':
        return <MediaManagerView />;
      case 'kategori':
        return <CategoryManagerView />;
      case 'user':
        return <UserManagerView />;
      case 'iklan':
        return <AdManagerView />;
      case 'website':
        return <WebsiteSettingsView />;
      case 'supabase':
        return <SupabaseSettingsView />;
      default:
        return <AnalyticsView />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col transition-colors">
      {/* Dashboard Top Header Bar */}
      <header className="sticky top-0 z-40 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 py-3 flex items-center justify-between shadow-xs">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2 rounded-xl text-slate-600 dark:text-slate-300 lg:hidden hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          {/* Logo link */}
          <div
            onClick={onNavigateToPortal}
            className="flex items-center gap-2 cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-lg bg-red-600 text-white font-black flex items-center justify-center text-sm shadow-md shadow-red-600/30">
              P
            </div>
            <div>
              <span className="font-black text-slate-900 dark:text-white text-sm sm:text-base leading-none">
                PAMANUKAN <span className="text-red-600">NEWS</span>
              </span>
              <span className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                Ruang Redaksi (CMS)
              </span>
            </div>
          </div>
        </div>

        {/* Right Info */}
        <div className="flex items-center gap-3">
          {/* User Profile Pill & Role Switcher */}
          <div
            onClick={onOpenAuthModal}
            className={`flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 ${
              onOpenAuthModal ? 'cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-700/80 transition' : ''
            }`}
            title="Klik untuk ganti akun Admin / Publisher"
          >
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-7 h-7 rounded-full object-cover ring-2 ring-red-500/30"
            />
            <div className="hidden sm:block text-left">
              <p className="text-xs font-bold text-slate-900 dark:text-white leading-tight">
                {currentUser.name}
              </p>
              <p className="text-[10px] text-red-600 dark:text-red-400 font-extrabold uppercase tracking-wider flex items-center gap-1">
                <span>{currentUser.role}</span>
                <span className="text-[9px] text-slate-400 font-normal">(Ganti)</span>
              </p>
            </div>
          </div>

          {/* Dark Mode */}
          <button
            onClick={toggleDarkMode}
            className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Back to Portal */}
          <button
            onClick={onNavigateToPortal}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold transition shadow-xs cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Lihat Portal</span>
          </button>
        </div>
      </header>

      {/* Main Body */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto p-4 sm:p-6 gap-6">
        {/* Sidebar Nav (Desktop) */}
        <aside
          className={`lg:block w-64 shrink-0 space-y-1.5 ${
            isMobileMenuOpen
              ? 'fixed inset-y-0 left-0 z-50 bg-white dark:bg-slate-900 p-6 shadow-2xl border-r border-slate-200 dark:border-slate-800 w-72'
              : 'hidden lg:block'
          }`}
        >
          {isMobileMenuOpen && (
            <div className="flex items-center justify-between pb-4 mb-3 border-b border-slate-100 dark:border-slate-800">
              <span className="font-black text-sm text-slate-900 dark:text-white">
                Menu Redaksi
              </span>
              <button
                onClick={() => setIsMobileMenuOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          )}

          {/* Role Header Indicator */}
          <div className="p-3 mb-2 rounded-2xl bg-linear-to-r from-slate-900 to-slate-800 text-white space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className={`w-2.5 h-2.5 rounded-full ${isAdmin ? 'bg-red-500 animate-pulse' : 'bg-blue-500 animate-pulse'}`} />
                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Peran Saat Ini</p>
                  <p className="text-xs font-black text-white">{isAdmin ? 'ADMINISTRATOR' : 'PUBLISHER'}</p>
                </div>
              </div>
              <span className={`text-[10px] font-black px-2 py-0.5 rounded-full uppercase ${isAdmin ? 'bg-red-600 text-white' : 'bg-blue-600 text-white'}`}>
                {isAdmin ? 'SEMUA IZIN' : 'KONTEN'}
              </span>
            </div>

            {/* Supabase Auth Connection Status */}
            <div className="pt-2 border-t border-white/10 flex items-center justify-between text-[10px]">
              <div className="flex items-center gap-1.5 text-emerald-400 truncate max-w-[150px]">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />
                <span className="truncate">
                  {supabaseAuthUser ? supabaseAuthUser.email : 'Supabase Auth Terhubung'}
                </span>
              </div>
              {onOpenAuthModal && (
                <button
                  onClick={onOpenAuthModal}
                  className="text-amber-400 hover:text-amber-300 font-bold hover:underline shrink-0 cursor-pointer"
                >
                  Ganti Akun
                </button>
              )}
            </div>
          </div>

          <div className="px-3 py-2 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            {isAdmin ? 'Menu Struktur Admin' : 'Menu Struktur Publisher'}
          </div>

          {activeNavItems.map((item) => {
            const isSelected = currentTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => {
                  if (item.id === 'tulis') {
                    setEditingArticle(null);
                  }
                  setCurrentTab(item.id);
                  setIsMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  isSelected
                    ? 'bg-red-600 text-white shadow-md shadow-red-600/30'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className={isSelected ? 'text-white' : 'text-slate-400'}>
                    {item.icon}
                  </span>
                  <span>{item.label}</span>
                </div>

                {item.badge && (
                  <span
                    className={`text-[9px] font-black px-1.5 py-0.2 rounded-full uppercase ${
                      isSelected
                        ? 'bg-white text-red-600'
                        : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}

          <div className="pt-6 mt-6 border-t border-slate-200 dark:border-slate-800">
            <div className="p-4 rounded-2xl bg-linear-to-br from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-850 space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 dark:text-white">
                <Shield className="w-4 h-4 text-red-600" />
                <span>Hierarki & Logika Sistem</span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug">
                {isAdmin
                  ? 'ADMIN: Mengontrol User, Website, Kategori, Berita, Media, Iklan & Semua Hak Akses.'
                  : 'PUBLISHER: Buat Berita, Edit Berita, Upload Media Kompresi, Submit Berita, Review & Publish.'}
              </p>
            </div>
          </div>
        </aside>

        {/* Content View */}
        <main className="flex-1 min-w-0">{renderActiveView()}</main>
      </div>
    </div>
  );
};
