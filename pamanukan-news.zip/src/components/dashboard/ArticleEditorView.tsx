import React, { useState, useEffect } from 'react';
import { useNews } from '../../context/NewsContext';
import { Article, ArticleStatus } from '../../types';
import { compressImage, formatBytes, CompressionResult } from '../../services/imageCompression';
import {
  Sparkles,
  Upload,
  CheckCircle,
  Save,
  Send,
  Globe,
  FileCheck,
  AlertTriangle,
  Lightbulb,
  FileText,
  HelpCircle,
  Maximize2,
  Trash2,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface ArticleEditorViewProps {
  initialArticle?: Article | null;
  onSaveComplete: () => void;
}

export const ArticleEditorView: React.FC<ArticleEditorViewProps> = ({
  initialArticle,
  onSaveComplete,
}) => {
  const { categories, currentUser, createArticle, updateArticle, addMediaItem } = useNews();

  // Form State
  const [title, setTitle] = useState(initialArticle?.title || '');
  const [summary, setSummary] = useState(initialArticle?.summary || '');
  const [content, setContent] = useState(initialArticle?.content || '');
  const [categoryId, setCategoryId] = useState(
    initialArticle?.categoryId || categories[0]?.id || 'cat-pamanukan'
  );
  const [coverImage, setCoverImage] = useState(
    initialArticle?.coverImage ||
      'https://images.unsplash.com/photo-1545459720-aac8509eb02c?w=1000&auto=format&fit=crop&q=80'
  );
  const [tagsInput, setTagsInput] = useState(initialArticle?.tags?.join(', ') || 'Pamanukan, Subang, Pantura');
  const [isHeadline, setIsHeadline] = useState(initialArticle?.isHeadline || false);
  const [isFeatured, setIsFeatured] = useState(initialArticle?.isFeatured || false);
  const [isEditorPick, setIsEditorPick] = useState(initialArticle?.isEditorPick || false);

  // Compression Feedback State
  const [compressionResult, setCompressionResult] = useState<CompressionResult | null>(null);
  const [isCompressing, setIsCompressing] = useState(false);
  const [compressQuality, setCompressQuality] = useState(0.8);

  // AI Assistant State
  const [aiLoading, setAiLoading] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([]);
  const [aiNote, setAiNote] = useState('');

  const isEditing = Boolean(initialArticle);
  // Publishers can submit, review, and publish directly per requested workflow
  const canPublishDirectly = currentUser.role === 'admin' || currentUser.role === 'editor' || currentUser.role === 'publisher';

  // Handle Cover Image Upload with Automatic Compression
  const handleImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsCompressing(true);
    try {
      const result = await compressImage(file, {
        maxWidth: 1280,
        maxHeight: 850,
        quality: compressQuality,
        format: 'image/webp',
      });

      setCompressionResult(result);
      setCoverImage(result.dataUrl);

      // Also auto-add to Media Library
      addMediaItem({
        name: file.name.replace(/\.[^/.]+$/, '') + '.webp',
        url: result.dataUrl,
        originalSize: result.originalSize,
        compressedSize: result.compressedSize,
        mimeType: result.mimeType,
        width: result.width,
        height: result.height,
        uploadedBy: currentUser.id,
        uploadedByName: currentUser.name,
      });
    } catch (err) {
      console.error('Failed to compress image:', err);
      alert('Gagal mengompres gambar. Silakan coba file gambar lain.');
    } finally {
      setIsCompressing(false);
    }
  };

  // AI Assistant Call
  const handleCallAi = async (action: 'suggest_title' | 'generate_summary' | 'extract_tags' | 'proofread') => {
    setAiLoading(true);
    setAiSuggestions([]);
    setAiNote('');

    try {
      const response = await fetch('/api/ai/assist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action,
          title,
          content,
          category: categories.find((c) => c.id === categoryId)?.name,
        }),
      });

      const data = await response.json();

      if (action === 'suggest_title' && data.suggestions) {
        setAiSuggestions(data.suggestions);
      } else if (action === 'generate_summary' && data.summary) {
        setSummary(data.summary);
        setAiNote('Ringkasan lead 5W+1H berhasil dibuat dan diterapkan!');
      } else if (action === 'extract_tags' && data.tags) {
        setTagsInput(data.tags.join(', '));
        setAiNote('Kata kunci SEO berhasil diekstrak ke dalam kolom tag.');
      } else if (action === 'proofread') {
        if (data.enhancedTitle) setTitle(data.enhancedTitle);
        if (data.enhancedContent) setContent(data.enhancedContent);
        setAiNote(`Penyempurnaan EYD diterapkan: ${(data.improvements || []).join('; ')}`);
      }
    } catch (e) {
      console.error('AI call failed:', e);
      setAiNote('Asisten AI offline sementara. Anda tetap dapat melanjutkan secara manual.');
    } finally {
      setAiLoading(false);
    }
  };

  // Save Logic
  const handleSubmit = (status: ArticleStatus) => {
    if (!title.trim()) {
      alert('Judul berita wajib diisi.');
      return;
    }

    const tagsArray = tagsInput
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);

    const payload = {
      title,
      summary,
      content,
      categoryId,
      categoryName: categories.find((c) => c.id === categoryId)?.name || 'Pamanukan',
      coverImage,
      tags: tagsArray,
      status,
      isHeadline,
      isFeatured,
      isEditorPick,
    };

    if (isEditing && initialArticle) {
      updateArticle(initialArticle.id, payload);
    } else {
      createArticle(payload);
    }

    if (status === 'published') {
      try {
        confetti({ particleCount: 70, spread: 60, origin: { y: 0.7 } });
      } catch {}
    }

    onSaveComplete();
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
            {isEditing ? 'Edit Naskah Berita' : 'Tulis Berita Baru (Ruang Publisher)'}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Dukungan kompresi gambar otomatis & asisten kecerdasan buatan (AI) redaksi.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Save Draft */}
          <button
            type="button"
            onClick={() => handleSubmit('draft')}
            className="flex items-center gap-1.5 px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold transition cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Simpan Draft</span>
          </button>

          {/* Submit for Review */}
          <button
            type="button"
            onClick={() => handleSubmit('pending')}
            className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>Kirim ke Redaktur (Submit Review)</span>
          </button>

          {/* Direct Publish (Admin/Editor) */}
          {canPublishDirectly && (
            <button
              type="button"
              onClick={() => handleSubmit('published')}
              className="flex items-center gap-1.5 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition shadow-md shadow-red-600/30 cursor-pointer"
            >
              <Globe className="w-4 h-4" />
              <span>Terbitkan Langsung</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Grid: Form on Left (8 Cols), AI & Media Tools on Right (4 Cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form: Title, Content, Metadata (8 Cols) */}
        <div className="lg:col-span-8 space-y-5">
          {/* Title Input */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
              Judul Berita (Headline)
            </label>
            <input
              type="text"
              placeholder="Ketik judul berita yang lugas, faktual, dan memikat..."
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white text-base sm:text-lg font-bold px-4 py-3 rounded-2xl outline-none focus:ring-2 focus:ring-red-500 shadow-inner"
            />
          </div>

          {/* Category & Visibility Settings */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Kategori Berita
              </label>
              <select
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
                className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-200 text-xs px-3 py-2.5 rounded-xl outline-none focus:ring-2 focus:ring-red-500"
              >
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Kata Kunci / Tag SEO
              </label>
              <input
                type="text"
                placeholder="Pisahkan dengan koma..."
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-200 text-xs px-3 py-2.5 rounded-xl outline-none focus:ring-2 focus:ring-red-500"
              />
            </div>

            <div className="flex flex-col justify-end">
              <div className="flex items-center gap-3 py-2">
                <label className="flex items-center gap-1.5 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isHeadline}
                    onChange={(e) => setIsHeadline(e.target.checked)}
                    className="accent-red-600 rounded"
                  />
                  <span>Headline Utama</span>
                </label>
                <label className="flex items-center gap-1.5 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isEditorPick}
                    onChange={(e) => setIsEditorPick(e.target.checked)}
                    className="accent-red-600 rounded"
                  />
                  <span>Pilihan Redaksi</span>
                </label>
              </div>
            </div>
          </div>

          {/* Lead Summary (5W+1H) */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                Lead / Ringkasan Berita (2-3 Kalimat)
              </label>
              <button
                type="button"
                onClick={() => handleCallAi('generate_summary')}
                className="text-xs text-red-600 hover:text-red-700 font-bold flex items-center gap-1 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Buat Lead dengan AI</span>
              </button>
            </div>
            <textarea
              rows={3}
              placeholder="Paragraf pembuka yang memuat 5W+1H inti peristiwa..."
              value={summary}
              onChange={(e) => setSummary(e.target.value)}
              className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white text-xs sm:text-sm px-4 py-2.5 rounded-2xl outline-none focus:ring-2 focus:ring-red-500 shadow-inner"
            />
          </div>

          {/* Main Content Body */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                Isi Artikel Lengkap
              </label>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleCallAi('proofread')}
                  className="text-xs text-blue-600 hover:text-blue-700 font-bold flex items-center gap-1 cursor-pointer"
                >
                  <FileCheck className="w-3.5 h-3.5" />
                  <span>Koreksi EYD V (AI)</span>
                </button>
              </div>
            </div>

            {/* Quick HTML tag helpers */}
            <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1.5 rounded-xl text-xs">
              <button
                type="button"
                onClick={() => setContent((prev) => prev + '<p>Paragraf baru di sini...</p>\n')}
                className="px-2 py-1 rounded bg-white dark:bg-slate-700 hover:bg-slate-50 text-slate-700 dark:text-slate-200 font-semibold"
              >
                + Paragraf
              </button>
              <button
                type="button"
                onClick={() => setContent((prev) => prev + '<blockquote>"Kutipan pernyataan narasumber..." - Nama Narasumber</blockquote>\n')}
                className="px-2 py-1 rounded bg-white dark:bg-slate-700 hover:bg-slate-50 text-slate-700 dark:text-slate-200 font-semibold"
              >
                + Kutipan
              </button>
              <button
                type="button"
                onClick={() => setContent((prev) => prev + '<h3>Subjudul Pembahasan</h3>\n')}
                className="px-2 py-1 rounded bg-white dark:bg-slate-700 hover:bg-slate-50 text-slate-700 dark:text-slate-200 font-semibold"
              >
                + Subjudul
              </button>
            </div>

            <textarea
              rows={12}
              placeholder="Tulis artikel berita secara detail di sini. Gunakan tag paragraf <p>...</p> atau teks biasa..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="w-full font-serif-reading bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white text-sm sm:text-base px-4 py-3 rounded-2xl outline-none focus:ring-2 focus:ring-red-500 shadow-inner"
            />
          </div>
        </div>

        {/* Right Sidebar: Auto Image Compression & AI Assist Tools (4 Cols) */}
        <div className="lg:col-span-4 space-y-6">
          {/* 1. Cover Image Upload with Automatic Compression Card */}
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-900 dark:text-white flex items-center gap-1.5">
              <Upload className="w-4 h-4 text-red-600" />
              <span>Gambar Sampul & Kompresi Otomatis</span>
            </h3>

            {/* Preview Image */}
            <div className="relative rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-700 border border-slate-200 dark:border-slate-700 h-40">
              <img
                src={coverImage}
                alt="Preview Sampul"
                className="w-full h-full object-cover"
              />
              {isCompressing && (
                <div className="absolute inset-0 bg-black/60 backdrop-blur-xs flex flex-col items-center justify-center text-white text-xs gap-2">
                  <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Mengompresi Gambar...</span>
                </div>
              )}
            </div>

            {/* Compression Metrics Banner if compressed */}
            {compressionResult && (
              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-500/30 text-emerald-900 dark:text-emerald-200 text-xs space-y-1">
                <div className="flex items-center justify-between font-bold">
                  <span>Hasil Kompresi WebP:</span>
                  <span className="bg-emerald-500 text-white px-1.5 py-0.2 rounded text-[10px]">
                    Hemat {compressionResult.savedPercentage}%!
                  </span>
                </div>
                <p className="text-[11px] opacity-90">
                  Asli: {formatBytes(compressionResult.originalSize)} ➔ Terkompresi: {formatBytes(compressionResult.compressedSize)}
                </p>
                <p className="text-[10px] text-emerald-700 dark:text-emerald-300">
                  Dimensi: {compressionResult.width} x {compressionResult.height} px
                </p>
              </div>
            )}

            {/* File Input */}
            <div>
              <label className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-dashed border-red-500/50 bg-red-50/50 dark:bg-red-950/20 text-red-600 dark:text-red-400 text-xs font-bold hover:bg-red-50 cursor-pointer transition">
                <Upload className="w-4 h-4" />
                <span>Pilih Foto dari Perangkat</span>
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={handleImageFileChange}
                  className="hidden"
                />
              </label>
              <p className="text-[10px] text-slate-400 mt-1 text-center">
                Maks. 10 MB. Otomatis dikonversi ke WebP teroptimasi.
              </p>
            </div>
          </div>

          {/* 2. AI Redaksi Assistant Card */}
          <div className="p-5 rounded-2xl bg-linear-to-br from-slate-900 to-red-950 text-white border border-slate-800 shadow-lg space-y-3.5">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-red-600 text-white flex items-center justify-center shadow-xs">
                <Sparkles className="w-3.5 h-3.5" />
              </span>
              <h3 className="text-xs font-black uppercase tracking-wider text-white">
                Asisten Redaksi AI
              </h3>
            </div>
            <p className="text-xs text-slate-300">
              Percepat penulisan dengan model AI untuk rekomendasi judul, ringkasan, dan audit jurnalistik.
            </p>

            <div className="space-y-2">
              <button
                type="button"
                onClick={() => handleCallAi('suggest_title')}
                disabled={aiLoading}
                className="w-full text-left px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 text-xs font-semibold text-white transition flex items-center justify-between cursor-pointer"
              >
                <span>5 Ide Judul Menarik Pantura</span>
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              </button>

              <button
                type="button"
                onClick={() => handleCallAi('extract_tags')}
                disabled={aiLoading}
                className="w-full text-left px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 text-xs font-semibold text-white transition flex items-center justify-between cursor-pointer"
              >
                <span>Ekstrak Tag SEO Otomatis</span>
                <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              </button>
            </div>

            {aiLoading && (
              <div className="p-3 text-center text-xs text-amber-300 font-semibold flex items-center justify-center gap-2">
                <div className="w-3.5 h-3.5 border-2 border-amber-300 border-t-transparent rounded-full animate-spin" />
                <span>AI sedang berpikir...</span>
              </div>
            )}

            {aiNote && (
              <div className="p-3 rounded-xl bg-white/10 text-[11px] text-emerald-300 border border-emerald-400/20">
                {aiNote}
              </div>
            )}

            {aiSuggestions.length > 0 && (
              <div className="space-y-2 pt-2 border-t border-white/15">
                <p className="text-[11px] font-bold text-amber-300">Pilih judul rekomendasi:</p>
                <div className="space-y-1.5">
                  {aiSuggestions.map((sug, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setTitle(sug)}
                      className="w-full text-left p-2 rounded-lg bg-black/40 hover:bg-black/60 text-xs text-slate-200 transition border border-white/5 line-clamp-2"
                    >
                      {sug}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
