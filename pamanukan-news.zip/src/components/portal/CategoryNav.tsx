import React from 'react';
import { useNews } from '../../context/NewsContext';
import { Flame, Compass, ChevronRight } from 'lucide-react';

interface CategoryNavProps {
  selectedCategoryId: string;
  onSelectCategory: (id: string) => void;
}

export const CategoryNav: React.FC<CategoryNavProps> = ({
  selectedCategoryId,
  onSelectCategory,
}) => {
  const { categories, articles } = useNews();

  const activeCategories = categories.filter((c) => c.isActive);

  return (
    <nav className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 transition-colors shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between gap-4 overflow-x-auto py-2.5 no-scrollbar scroll-smooth">
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* All button */}
            <button
              onClick={() => onSelectCategory('all')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                selectedCategoryId === 'all'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Compass className="w-3.5 h-3.5" />
              <span>Semua</span>
            </button>

            {/* Dynamic categories */}
            {activeCategories.map((cat) => {
              const isSelected = selectedCategoryId === cat.id;
              const count = articles.filter(
                (a) => a.categoryId === cat.id && a.status === 'published'
              ).length;

              return (
                <button
                  key={cat.id}
                  onClick={() => onSelectCategory(cat.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                    isSelected
                      ? 'bg-red-600 text-white shadow-xs'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <span
                    className="w-2 h-2 rounded-full shrink-0"
                    style={{ backgroundColor: isSelected ? '#ffffff' : cat.color }}
                  />
                  <span>{cat.name}</span>
                  {count > 0 && (
                    <span
                      className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                        isSelected
                          ? 'bg-red-700 text-red-100'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                      }`}
                    >
                      {count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Trending Hot Tag on right */}
          <div className="hidden lg:flex items-center gap-2 text-xs font-semibold text-slate-500 dark:text-slate-400 whitespace-nowrap border-l border-slate-200 dark:border-slate-800 pl-4">
            <span className="flex items-center gap-1 text-red-600 font-bold">
              <Flame className="w-3.5 h-3.5" />
              <span>Tren:</span>
            </span>
            <span
              onClick={() => onSelectCategory('cat-ekonomi')}
              className="hover:text-red-600 cursor-pointer transition"
            >
              #TolPatimban
            </span>
            <span>•</span>
            <span
              onClick={() => onSelectCategory('cat-pamanukan')}
              className="hover:text-red-600 cursor-pointer transition"
            >
              #Cipunagara
            </span>
            <span>•</span>
            <span
              onClick={() => onSelectCategory('cat-budaya')}
              className="hover:text-red-600 cursor-pointer transition"
            >
              #RuwatLaut
            </span>
          </div>
        </div>
      </div>
    </nav>
  );
};
