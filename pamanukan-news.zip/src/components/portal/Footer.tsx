import React from 'react';
import { useNews } from '../../context/NewsContext';
import { ShieldCheck, Mail, Phone, MapPin, ExternalLink, Heart } from 'lucide-react';

interface FooterProps {
  onNavigateToDashboard: () => void;
  onSelectCategory: (id: string) => void;
  onOpenAuthModal?: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onNavigateToDashboard,
  onSelectCategory,
  onOpenAuthModal,
}) => {
  const { siteSettings, categories } = useNews();

  return (
    <footer className="bg-slate-950 text-slate-400 border-t border-slate-800 text-xs">
      {/* Upper Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8">
          {/* Brand & Editorial Identity (5 Cols) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-linear-to-tr from-red-600 to-red-700 rounded-xl flex items-center justify-center text-white font-black text-xl shadow-md shadow-red-600/30">
                P
              </div>
              <div>
                <h3 className="text-xl font-black text-white tracking-tight">
                  PAMANUKAN <span className="text-red-500">NEWS</span>
                </h3>
                <p className="text-[11px] text-slate-400 font-medium">
                  {siteSettings.tagline}
                </p>
              </div>
            </div>

            <p className="text-slate-400 text-xs leading-relaxed max-w-md">
              {siteSettings.seoDescription}
            </p>

            <div className="space-y-2 pt-2 border-t border-slate-800/80">
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-red-500 shrink-0" />
                <span>{siteSettings.address}</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-red-500 shrink-0" />
                <span>{siteSettings.contactEmail}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-red-500 shrink-0" />
                <span>{siteSettings.contactPhone}</span>
              </div>
            </div>
          </div>

          {/* Categories (3 Cols) */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-black text-white text-xs uppercase tracking-wider border-b border-slate-800 pb-2">
              Kanal Berita
            </h4>
            <div className="grid grid-cols-2 gap-2">
              {categories.slice(0, 8).map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => onSelectCategory(cat.id)}
                  className="text-left text-slate-400 hover:text-red-400 transition truncate"
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>

          {/* Dewan Pers & Standar Siber (4 Cols) */}
          <div className="lg:col-span-4 space-y-3">
            <h4 className="font-black text-white text-xs uppercase tracking-wider border-b border-slate-800 pb-2 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Pedoman Media Siber</span>
            </h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              PAMANUKAN NEWS berpedoman pada Kode Etik Jurnalistik dan Pedoman Pemberitaan Media Siber sesuai ketetapan Dewan Pers Republik Indonesia. Hak Cipta dilindungi Undang-Undang.
            </p>

            {onOpenAuthModal && (
              <div className="pt-2">
                <button
                  onClick={onOpenAuthModal}
                  className="w-full py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 transition font-medium text-xs flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Masuk ke Akun</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Bottom Copyright */}
      <div className="bg-black/60 border-t border-slate-900 py-4 px-4 sm:px-6 text-center text-[11px] text-slate-400">
        <p>
          © {new Date().getFullYear()} PAMANUKAN NEWS. Seluruh hak cipta dilindungi. Portal Berita Digital Pantura Subang.
        </p>
      </div>
    </footer>
  );
};
