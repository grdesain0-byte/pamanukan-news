import React from 'react';
import { Article } from '../../types';
import { Eye, Clock, Flame, Sparkles } from 'lucide-react';

interface HeroSectionProps {
  articles: Article[];
  onSelectArticle: (id: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  articles,
  onSelectArticle,
}) => {
  const published = articles.filter((a) => a.status === 'published');
  if (published.length === 0) return null;

  // Primary headline: isHeadline = true or first article
  const headline = published.find((a) => a.isHeadline) || published[0];
  const subHeadlines = published
    .filter((a) => a.id !== headline.id)
    .slice(0, 4);

  const formatDate = (isoStr: string) => {
    if (!isoStr) return '';
    const date = new Date(isoStr);
    return date.toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  };

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Main Big Headline Card (7 Cols) */}
        <div
          onClick={() => onSelectArticle(headline.id)}
          className="lg:col-span-7 group relative rounded-2xl overflow-hidden cursor-pointer shadow-lg bg-slate-900 border border-slate-200/50 dark:border-slate-800 min-h-[420px] lg:min-h-[500px] flex flex-col justify-end"
        >
          {/* Background Cover Image with Hover Zoom */}
          <div className="absolute inset-0 overflow-hidden">
            <img
              src={headline.coverImage}
              alt={headline.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
              loading="eager"
            />
            {/* Dynamic Gradient for Legibility */}
            <div className="absolute inset-0 bg-linear-to-t from-slate-950 via-slate-950/60 to-transparent" />
          </div>

          {/* Top Badges */}
          <div className="absolute top-4 left-4 flex flex-wrap items-center gap-2 z-10">
            <span className="bg-red-600 text-white text-xs font-black px-3 py-1 rounded-full uppercase tracking-wider flex items-center gap-1 shadow-md shadow-red-600/40">
              <Flame className="w-3.5 h-3.5" />
              <span>HEADLINE UTAMA</span>
            </span>
            <span className="bg-slate-900/80 backdrop-blur-md text-slate-100 text-xs font-semibold px-2.5 py-1 rounded-full border border-white/10">
              {headline.categoryName}
            </span>
          </div>

          {/* Bottom Content */}
          <div className="relative z-10 p-6 sm:p-8 space-y-3">
            <div className="flex items-center gap-3 text-xs text-slate-300 font-medium">
              <span className="flex items-center gap-1 text-amber-400">
                <Clock className="w-3.5 h-3.5" />
                <span>{headline.readingTimeMinutes} mnt baca</span>
              </span>
              <span>•</span>
              <span>{formatDate(headline.publishedAt)}</span>
              <span>•</span>
              <span className="flex items-center gap-1 text-slate-300">
                <Eye className="w-3.5 h-3.5" />
                <span>{headline.views.toLocaleString('id-ID')} tayang</span>
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-white leading-tight group-hover:text-red-300 transition-colors">
              {headline.title}
            </h2>

            <p className="text-sm text-slate-300 line-clamp-2 leading-relaxed">
              {headline.summary}
            </p>

            {/* Author Footer */}
            <div className="flex items-center justify-between pt-2 border-t border-white/15">
              <div className="flex items-center gap-2.5">
                <img
                  src={headline.authorAvatar}
                  alt={headline.authorName}
                  className="w-7 h-7 rounded-full object-cover ring-2 ring-red-500/40"
                />
                <span className="text-xs text-slate-200 font-medium">
                  Oleh <span className="font-bold text-white">{headline.authorName}</span>
                </span>
              </div>
              <span className="text-xs text-red-400 font-bold group-hover:translate-x-1 transition-transform flex items-center gap-1">
                Baca Selengkapnya →
              </span>
            </div>
          </div>
        </div>

        {/* Right: 4 Sub-Stories Grid (5 Cols) */}
        <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4">
          {subHeadlines.map((item, idx) => (
            <div
              key={item.id}
              onClick={() => onSelectArticle(item.id)}
              className="group flex gap-3.5 p-3.5 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-800 hover:border-red-500/50 hover:shadow-md transition-all cursor-pointer"
            >
              {/* Thumbnail */}
              <div className="w-28 sm:w-32 h-24 rounded-lg overflow-hidden shrink-0 relative bg-slate-100 dark:bg-slate-700">
                <img
                  src={item.coverImage}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  loading="lazy"
                />
                <span className="absolute bottom-1 left-1 bg-black/70 backdrop-blur-xs text-[10px] text-white px-1.5 py-0.5 rounded font-bold">
                  #{idx + 2}
                </span>
              </div>

              {/* Text */}
              <div className="flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-bold text-red-600 dark:text-red-400 uppercase tracking-wider">
                      {item.categoryName}
                    </span>
                    <span className="text-[10px] text-slate-400">• {item.readingTimeMinutes} mnt</span>
                  </div>
                  <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white line-clamp-2 leading-snug group-hover:text-red-600 dark:group-hover:text-red-400 transition-colors">
                    {item.title}
                  </h3>
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 mt-2">
                  <span className="truncate max-w-[130px]">{item.authorName}</span>
                  <span className="flex items-center gap-1">
                    <Eye className="w-3 h-3" />
                    <span>{item.views.toLocaleString('id-ID')}</span>
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
