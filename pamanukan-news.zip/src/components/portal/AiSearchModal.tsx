import React, { useState, useEffect } from 'react';
import { useNews } from '../../context/NewsContext';
import { Article } from '../../types';
import {
  Sparkles,
  Search,
  X,
  ArrowRight,
  Lightbulb,
  FileText,
  Clock,
  ExternalLink,
  Flame,
} from 'lucide-react';

interface AiSearchResult {
  aiSummary: string;
  recommendedArticleIds: string[];
  keyInsights: string[];
  suggestedFollowUps: string[];
}

interface AiSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectArticle: (id: string) => void;
}

export const AiSearchModal: React.FC<AiSearchModalProps> = ({
  isOpen,
  onClose,
  onSelectArticle,
}) => {
  const { articles } = useNews();
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [searchResult, setSearchResult] = useState<AiSearchResult | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  // Preset smart queries
  const presets = [
    'Akses Tol Patimban dan dampaknya ke Pamanukan',
    'Normalisasi Cipunagara antisipasi banjir tahunan',
    'Sentra kuliner ikan etong bakar Pantura',
    'Tradisi ruwat laut nelayan Muara Ciasem',
    'Panen raya padi organik Subang',
  ];

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        onClose();
      }
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handlePerformSearch = async (searchQuery: string) => {
    const q = searchQuery.trim();
    if (!q) return;

    setLoading(true);
    setErrorMsg('');
    setSearchResult(null);

    try {
      const response = await fetch('/api/ai/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: q,
          articles,
        }),
      });

      if (!response.ok) {
        throw new Error('Gagal menghubungi mesin pencari AI');
      }

      const data: AiSearchResult = await response.json();
      setSearchResult(data);
    } catch (err: any) {
      console.error('AI Search error:', err);
      // Fallback local match
      const matched = articles.filter(
        (a) =>
          a.title.toLowerCase().includes(q.toLowerCase()) ||
          a.summary.toLowerCase().includes(q.toLowerCase())
      );
      setSearchResult({
        aiSummary: `Ditemukan ${matched.length} artikel di arsip Pamanukan News yang berkaitan dengan pencarian "${q}".`,
        recommendedArticleIds: matched.slice(0, 4).map((m) => m.id),
        keyInsights: [
          `Pencarian berbasis arsip lokal wilayah Pamanukan dan Subang`,
          `Liputan faktual dan telah diverifikasi redaksi`,
        ],
        suggestedFollowUps: [
          `Perkembangan terkini terkait ${q}`,
          `Tanggapan warga dan tokoh masyarakat setempat`,
        ],
      });
    } finally {
      setLoading(false);
    }
  };

  const matchedArticles = searchResult
    ? (searchResult.recommendedArticleIds || [])
        .map((id) => articles.find((a) => a.id === id))
        .filter((a): a is Article => Boolean(a))
    : [];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-md flex justify-center p-3 sm:p-6 animate-fade-in">
      <div className="relative w-full max-w-3xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-auto max-h-[90vh] flex flex-col">
        {/* Top Search Input Bar */}
        <div className="p-4 sm:p-6 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-linear-to-tr from-red-600 to-amber-500 text-white flex items-center justify-center">
                <Sparkles className="w-3.5 h-3.5" />
              </span>
              <h3 className="text-sm font-black text-slate-900 dark:text-white uppercase tracking-wider">
                Pencarian Arsip Cerdas Berbasis AI
              </h3>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-slate-700 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Form */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handlePerformSearch(query);
            }}
            className="relative"
          >
            <Search className="absolute left-4 top-3.5 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Tanyakan apa saja seputar arsip berita Pamanukan & Pantura..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              autoFocus
              className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white placeholder-slate-400 text-sm pl-11 pr-24 py-3 rounded-2xl outline-none focus:ring-2 focus:ring-red-500 shadow-inner"
            />
            <button
              type="submit"
              disabled={loading || !query.trim()}
              className="absolute right-2 top-2 px-3.5 py-1.5 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              {loading ? (
                <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <span>Cari</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </form>

          {/* Quick Presets */}
          <div className="flex flex-wrap items-center gap-1.5 mt-3">
            <span className="text-[11px] font-bold text-slate-400 mr-1 flex items-center gap-1">
              <Flame className="w-3 h-3 text-red-500" /> Contoh Kueri:
            </span>
            {presets.map((preset, i) => (
              <button
                key={i}
                type="button"
                onClick={() => {
                  setQuery(preset);
                  handlePerformSearch(preset);
                }}
                className="px-2.5 py-1 bg-white dark:bg-slate-800 hover:bg-red-50 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 rounded-lg text-xs transition cursor-pointer"
              >
                {preset}
              </button>
            ))}
          </div>
        </div>

        {/* Content Body */}
        <div className="overflow-y-auto p-6 space-y-6 flex-1">
          {loading && (
            <div className="py-16 text-center space-y-3">
              <div className="w-12 h-12 rounded-full border-3 border-red-600 border-t-transparent animate-spin mx-auto" />
              <p className="text-sm font-bold text-slate-800 dark:text-slate-200">
                AI Redaksi sedang menganalisis arsip berita...
              </p>
              <p className="text-xs text-slate-400">
                Memindai laporan terbit, kutipan narasumber, dan data kawasan Pantura Subang.
              </p>
            </div>
          )}

          {errorMsg && (
            <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-500/30 text-red-700 dark:text-red-300 text-xs">
              {errorMsg}
            </div>
          )}

          {!loading && searchResult && (
            <div className="space-y-6 animate-fade-in">
              {/* AI Synthesized Answer Card */}
              <div className="p-5 rounded-2xl bg-linear-to-br from-red-50 to-orange-50/50 dark:from-red-950/20 dark:to-slate-800/60 border border-red-200 dark:border-red-900/40 space-y-3">
                <div className="flex items-center gap-2 text-xs font-black text-red-700 dark:text-red-400 uppercase tracking-wider">
                  <Sparkles className="w-4 h-4" />
                  <span>Rangkuman Cerdas AI Redaksi</span>
                </div>
                <p className="text-sm text-slate-800 dark:text-slate-200 leading-relaxed font-medium">
                  {searchResult.aiSummary}
                </p>

                {/* Key Insights */}
                {searchResult.keyInsights && searchResult.keyInsights.length > 0 && (
                  <div className="pt-2 border-t border-red-200/60 dark:border-red-900/30 space-y-1">
                    <p className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                      <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
                      <span>Poin Kunci Arsip:</span>
                    </p>
                    <ul className="text-xs text-slate-600 dark:text-slate-400 space-y-1 pl-5 list-disc">
                      {searchResult.keyInsights.map((insight, idx) => (
                        <li key={idx}>{insight}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Recommended Articles from Archive */}
              <div className="space-y-3">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-red-600" />
                  <span>Artikel Arsip Terkait ({matchedArticles.length})</span>
                </h4>

                {matchedArticles.length === 0 ? (
                  <p className="text-xs text-slate-400 italic">
                    Tidak ada arsip berita yang cocok secara langsung.
                  </p>
                ) : (
                  <div className="space-y-2.5">
                    {matchedArticles.map((art) => (
                      <div
                        key={art.id}
                        onClick={() => {
                          onSelectArticle(art.id);
                          onClose();
                        }}
                        className="group flex gap-3.5 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 hover:border-red-500/50 hover:bg-white dark:hover:bg-slate-800 transition cursor-pointer"
                      >
                        <img
                          src={art.coverImage}
                          alt={art.title}
                          className="w-20 h-16 rounded-xl object-cover shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-[10px] font-bold text-red-600 dark:text-red-400 uppercase">
                              {art.categoryName}
                            </span>
                            <span className="text-[10px] text-slate-400">• {art.readingTimeMinutes} mnt</span>
                          </div>
                          <h5 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate group-hover:text-red-600 transition">
                            {art.title}
                          </h5>
                          <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">
                            {art.summary}
                          </p>
                        </div>
                        <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-red-600 shrink-0 self-center" />
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Follow-up Question Ideas */}
              {searchResult.suggestedFollowUps && searchResult.suggestedFollowUps.length > 0 && (
                <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
                  <p className="text-xs font-bold text-slate-500 mb-2">Pertanyaan Lanjutan Terkait:</p>
                  <div className="flex flex-wrap gap-2">
                    {searchResult.suggestedFollowUps.map((fu, idx) => (
                      <button
                        key={idx}
                        onClick={() => {
                          setQuery(fu);
                          handlePerformSearch(fu);
                        }}
                        className="text-xs px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-red-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition cursor-pointer"
                      >
                        {fu} →
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
