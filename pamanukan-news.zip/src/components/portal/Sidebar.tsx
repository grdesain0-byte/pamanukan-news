import React, { useState } from 'react';
import { useNews } from '../../context/NewsContext';
import {
  CloudSun,
  Wind,
  Droplets,
  Waves,
  Clock,
  TrendingUp,
  Mail,
  Send,
  BellRing,
  PhoneCall,
  CheckCircle,
  ExternalLink,
} from 'lucide-react';

interface SidebarProps {
  onSelectArticle: (id: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onSelectArticle }) => {
  const {
    articles,
    advertisements,
    recordAdClick,
    pushSubscriptionActive,
    togglePushNotifications,
    siteSettings,
  } = useNews();

  const [emailInput, setEmailInput] = useState('');
  const [subscribedMessage, setSubscribedMessage] = useState(false);

  const sidebarAd = advertisements.find((ad) => ad.position === 'sidebar' && ad.isActive);

  // Top 5 most viewed
  const trendingArticles = [...articles]
    .filter((a) => a.status === 'published')
    .sort((a, b) => b.views - a.views)
    .slice(0, 5);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailInput) return;
    setSubscribedMessage(true);
    setTimeout(() => setSubscribedMessage(false), 4000);
    setEmailInput('');
  };

  return (
    <aside className="space-y-6">
      {/* 1. Widget Cuaca & Maritim Pesisir Pantura Subang */}
      <div className="bg-linear-to-br from-slate-900 via-slate-800 to-blue-950 text-white rounded-2xl p-5 shadow-lg border border-slate-700/60 relative overflow-hidden">
        <div className="absolute -top-8 -right-8 w-28 h-28 bg-blue-500/10 rounded-full blur-2xl" />

        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div>
            <h3 className="font-extrabold text-sm flex items-center gap-1.5 text-white">
              <CloudSun className="w-4 h-4 text-amber-400" />
              <span>Cuaca & Info Maritim</span>
            </h3>
            <p className="text-[11px] text-slate-300 mt-0.5">Pamanukan & Patimban, Subang</p>
          </div>
          <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-500/30">
            Aman Melaut
          </span>
        </div>

        <div className="flex items-center justify-between py-4">
          <div>
            <span className="text-3xl font-black text-white">29°C</span>
            <p className="text-xs text-amber-300 font-semibold mt-0.5">Cerah Berawan</p>
          </div>
          <div className="text-right text-[11px] text-slate-300 space-y-1">
            <p className="flex items-center justify-end gap-1">
              <Wind className="w-3.5 h-3.5 text-blue-300" /> Angin: 11 knot (Timur Laut)
            </p>
            <p className="flex items-center justify-end gap-1">
              <Droplets className="w-3.5 h-3.5 text-cyan-300" /> Kelembapan: 76%
            </p>
            <p className="flex items-center justify-end gap-1">
              <Waves className="w-3.5 h-3.5 text-indigo-300" /> Tinggi Gelombang: 0.8 - 1.2 m
            </p>
          </div>
        </div>

        <p className="text-[10px] text-slate-400 border-t border-white/10 pt-2 text-center">
          Sumber Data: Stasiun Meteorologi Maritim BMKG Pantura
        </p>
      </div>

      {/* 2. Top 5 Trending Berita Pantura */}
      <div className="bg-white dark:bg-slate-800/80 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex items-center gap-2 pb-3 mb-3 border-b border-slate-100 dark:border-slate-700/60">
          <TrendingUp className="w-4 h-4 text-red-600" />
          <h3 className="font-black text-sm text-slate-900 dark:text-white uppercase tracking-tight">
            Paling Populer Hari Ini
          </h3>
        </div>

        <div className="space-y-3.5">
          {trendingArticles.map((art, idx) => (
            <div
              key={art.id}
              onClick={() => onSelectArticle(art.id)}
              className="flex items-start gap-3 group cursor-pointer"
            >
              <span
                className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-black shrink-0 ${
                  idx === 0
                    ? 'bg-red-600 text-white shadow-xs'
                    : idx === 1
                    ? 'bg-amber-500 text-slate-900'
                    : idx === 2
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400'
                }`}
              >
                {idx + 1}
              </span>
              <div className="flex-1">
                <span className="text-[10px] font-bold text-red-600 dark:text-red-400 uppercase">
                  {art.categoryName}
                </span>
                <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 group-hover:text-red-600 dark:group-hover:text-red-400 transition-colors line-clamp-2 leading-snug">
                  {art.title}
                </h4>
                <p className="text-[10px] text-slate-400 mt-1">
                  {art.views.toLocaleString('id-ID')} pembaca
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 3. Sidebar Ad Banner (300x250) */}
      {sidebarAd && (
        <div className="bg-white dark:bg-slate-800 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-xs">
          <a
            href={sidebarAd.linkUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => recordAdClick(sidebarAd.id)}
            className="block relative group hover:opacity-95 transition"
          >
            <span className="absolute top-2 right-2 bg-black/60 text-white text-[9px] px-1.5 py-0.5 rounded font-mono z-10">
              IKLAN
            </span>
            <img
              src={sidebarAd.imageUrl}
              alt={sidebarAd.title}
              className="w-full h-56 object-cover"
            />
            <div className="p-3 bg-slate-50 dark:bg-slate-850 flex items-center justify-between text-xs">
              <span className="font-bold text-slate-700 dark:text-slate-300 truncate max-w-[210px]">
                {sidebarAd.title}
              </span>
              <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
            </div>
          </a>
        </div>
      )}

      {/* 4. Berlangganan Push Notification & Buletin Pantura */}
      <div className="bg-linear-to-tr from-red-600 to-red-700 text-white rounded-2xl p-5 shadow-lg relative overflow-hidden">
        <div className="relative z-10 space-y-3">
          <div className="flex items-center gap-2">
            <BellRing className="w-5 h-5 text-amber-300 animate-bounce" />
            <h3 className="font-black text-sm">Waspada Breaking News Pantura</h3>
          </div>
          <p className="text-xs text-red-100 leading-relaxed">
            Dapatkan notifikasi instan langsung di layar gawai Anda setiap kali terjadi peristiwa penting dan berita mendesak di kawasan Pamanukan.
          </p>

          <button
            onClick={togglePushNotifications}
            className={`w-full py-2.5 px-4 rounded-xl text-xs font-black transition shadow-md flex items-center justify-center gap-2 cursor-pointer ${
              pushSubscriptionActive
                ? 'bg-emerald-500 text-white hover:bg-emerald-600'
                : 'bg-white text-red-700 hover:bg-red-50'
            }`}
          >
            {pushSubscriptionActive ? (
              <>
                <CheckCircle className="w-4 h-4" />
                <span>Notifikasi Sudah Aktif</span>
              </>
            ) : (
              <>
                <BellRing className="w-4 h-4" />
                <span>Aktifkan Notifikasi Web Sekarang</span>
              </>
            )}
          </button>

          <form onSubmit={handleSubscribe} className="pt-2 border-t border-white/20">
            <p className="text-[11px] text-red-200 mb-2">Atau langganan rangkuman pagi via Email:</p>
            <div className="flex gap-1.5">
              <input
                type="email"
                placeholder="Alamat email Anda..."
                value={emailInput}
                onChange={(e) => setEmailInput(e.target.value)}
                className="flex-1 bg-red-800/80 border border-red-500 text-white placeholder-red-300 text-xs px-3 py-2 rounded-lg outline-none focus:ring-2 focus:ring-white"
              />
              <button
                type="submit"
                className="bg-slate-900 hover:bg-black text-white px-3 py-2 rounded-lg text-xs font-bold transition flex items-center justify-center"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
            {subscribedMessage && (
              <p className="text-[11px] text-emerald-300 font-semibold mt-1.5">
                ✓ Terima kasih! Anda telah terdaftar dalam buletin redaksi.
              </p>
            )}
          </form>
        </div>
      </div>

      {/* 5. Layanan Pengaduan Warga & Hotline Redaksi */}
      <div className="bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-5 border border-slate-200 dark:border-slate-800">
        <h3 className="font-bold text-xs uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
          Suara Warga & Hotline Redaksi
        </h3>
        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-3">
          Punya info peristiwa, keluhan fasilitas umum, atau laporan warga seputar Pamanukan dan Subang?
        </p>
        <a
          href="https://wa.me/6281234567890"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-center gap-2 w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition shadow-xs"
        >
          <PhoneCall className="w-3.5 h-3.5" />
          <span>Kirim Laporan via WhatsApp</span>
        </a>
      </div>
    </aside>
  );
};
