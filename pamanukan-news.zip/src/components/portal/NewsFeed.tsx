import React, { useState } from 'react';
import { Article } from '../../types';
import { useNews } from '../../context/NewsContext';
import { Eye, Clock, Bookmark, Sparkles, Filter, TrendingUp, Award, Newspaper } from 'lucide-react';

interface NewsFeedProps {
  selectedCategoryId: string;
  onSelectArticle: (id: string) => void;
  searchQuery?: string;
}

export const NewsFeed: React.FC<NewsFeedProps> = ({
  selectedCategoryId,
  onSelectArticle,
  searchQuery = '',
}) => {
  const { articles, advertisements, recordAdClick } = useNews();
  const [feedTab, setFeedTab] = useState<'terkini' | 'populer' | 'editor'>('terkini');
  const [visibleCount, setVisibleCount] = useState<number>(6);

  const inFeedAd = advertisements.find((ad) => ad.position === 'in_feed' && ad.isActive);

  // Filter published articles
  let filtered = articles.filter((a) => a.status === 'published');

  // Category filter
  if (selectedCategoryId !== 'all') {
    filtered = filtered.filter((a) => a.categoryId === selectedCategoryId);
  }

  // Search filter
  if (searchQuery.trim()) {
    const q = searchQuery.toLowerCase();
    filtered = filtered.filter(
      (a) =>
        a.title.toLowerCase().includes(q) ||
        a.summary.toLowerCase().includes(q) ||
        a.tags.some((t) => t.toLowerCase().includes(q))
    );
  }

  // Sort by feedTab
  if (feedTab === 'populer') {
    filtered = [...filtered].sort((a, b) => b.views - a.views);
  } else if (feedTab === 'editor') {
    filtered = [...filtered].sort((a, b) => (b.isEditorPick ? 1 : 0) - (a.isEditorPick ? 1 : 0));
  } else {
    // terkini
    filtered = [...filtered].sort(
      (a, b) => new Date(b.publishedAt || b.createdAt).getTime() - new Date(a.publishedAt || a.createdAt).getTime()
    );
  }

  const displayedArticles = filtered.slice(0, visibleCount);
  const hasMore = visibleCount < filtered.length;

  return (
    <div className="space-y-6">
      {/* Feed Filter Header & Tabs */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2">
          <Newspaper className="w-5 h-5 text-red-600" />
          <h2 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
            Indeks Berita Pantura
          </h2>
          <span className="text-xs bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-bold px-2 py-0.5 rounded-full">
            {filtered.length} Artikel
          </span>
        </div>

        {/* Tab Pills */}
        <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800/80 p-1 rounded-xl">
          <button
            onClick={() => setFeedTab('terkini')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
              feedTab === 'terkini'
                ? 'bg-white dark:bg-slate-700 text-red-600 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <span>Terkini</span>
          </button>

          <button
            onClick={() => setFeedTab('populer')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
              feedTab === 'populer'
                ? 'bg-white dark:bg-slate-700 text-red-600 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5 text-amber-500" />
            <span>Terpopuler</span>
          </button>

          <button
            onClick={() => setFeedTab('editor')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
              feedTab === 'editor'
                ? 'bg-white dark:bg-slate-700 text-red-600 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Award className="w-3.5 h-3.5 text-blue-500" />
            <span>Pilihan Redaksi</span>
          </button>
        </div>
      </div>

      {/* Articles Grid */}
      {displayedArticles.length === 0 ? (
        <div className="p-12 text-center bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800">
          <Sparkles className="w-8 h-8 text-slate-400 mx-auto mb-2" />
          <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">
            Tidak ada berita yang sesuai
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Coba ubah kata kunci pencarian atau pilih kategori lain.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {displayedArticles.map((article, idx) => {
            const formattedDate = new Date(article.publishedAt || article.createdAt).toLocaleDateString(
              'id-ID',
              { day: 'numeric', month: 'short', year: 'numeric' }
            );

            return (
              <React.Fragment key={article.id}>
                <article
                  onClick={() => onSelectArticle(article.id)}
                  className="group bg-white dark:bg-slate-800/90 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 hover:border-red-500/40 hover:shadow-xl transition-all flex flex-col justify-between cursor-pointer"
                >
                  {/* Top Image */}
                  <div className="relative h-48 w-full overflow-hidden bg-slate-100 dark:bg-slate-700">
                    <img
                      src={article.coverImage}
                      alt={article.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      loading="lazy"
                    />
                    <div className="absolute top-3 left-3 flex items-center gap-1.5">
                      <span className="bg-red-600 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider shadow-sm">
                        {article.categoryName}
                      </span>
                      {article.isEditorPick && (
                        <span className="bg-amber-500 text-slate-900 text-[10px] font-extrabold px-2 py-0.5 rounded-full shadow-sm flex items-center gap-1">
                          <Award className="w-3 h-3" />
                          <span>Pilihan</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 text-xs text-slate-400 mb-2">
                        <span>{formattedDate}</span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>{article.readingTimeMinutes} mnt baca</span>
                        </span>
                      </div>

                      <h3 className="text-base font-bold text-slate-900 dark:text-white leading-snug group-hover:text-red-600 dark:group-hover:text-red-400 transition-colors line-clamp-2">
                        {article.title}
                      </h3>

                      <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 line-clamp-3 leading-relaxed">
                        {article.summary}
                      </p>
                    </div>

                    {/* Author & Footer Info */}
                    <div className="flex items-center justify-between pt-4 mt-4 border-t border-slate-100 dark:border-slate-700/60">
                      <div className="flex items-center gap-2">
                        <img
                          src={article.authorAvatar}
                          alt={article.authorName}
                          className="w-6 h-6 rounded-full object-cover"
                        />
                        <span className="text-xs text-slate-500 dark:text-slate-400 font-medium truncate max-w-[120px]">
                          {article.authorName}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-xs text-slate-400 font-medium">
                        <span className="flex items-center gap-1">
                          <Eye className="w-3.5 h-3.5" />
                          <span>{article.views.toLocaleString('id-ID')}</span>
                        </span>
                      </div>
                    </div>
                  </div>
                </article>

                {/* In-feed Ad after 4th item */}
                {idx === 2 && inFeedAd && (
                  <div className="md:col-span-2 my-2">
                    <a
                      href={inFeedAd.linkUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => recordAdClick(inFeedAd.id)}
                      className="block relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 shadow-sm hover:opacity-95 transition"
                    >
                      <span className="absolute top-2 right-2 bg-black/60 text-white text-[9px] px-2 py-0.5 rounded font-mono z-10">
                        PARIWARA
                      </span>
                      <img
                        src={inFeedAd.imageUrl}
                        alt={inFeedAd.title}
                        className="w-full h-32 sm:h-36 object-cover"
                      />
                    </a>
                  </div>
                )}
              </React.Fragment>
            );
          })}
        </div>
      )}

      {/* Load More Button */}
      {hasMore && (
        <div className="text-center pt-4">
          <button
            onClick={() => setVisibleCount((prev) => prev + 4)}
            className="px-6 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-red-600 hover:text-white dark:hover:bg-red-600 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
          >
            Muat Lebih Banyak Berita Pantura
          </button>
        </div>
      )}
    </div>
  );
};
