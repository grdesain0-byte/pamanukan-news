import React, { useState, useEffect } from 'react';
import { Article, Comment } from '../../types';
import { useNews } from '../../context/NewsContext';
import {
  X,
  Clock,
  Eye,
  Share2,
  Bookmark,
  Volume2,
  VolumeX,
  Play,
  Pause,
  RotateCcw,
  Type,
  ThumbsUp,
  MessageSquare,
  Send,
  Check,
  Award,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';

interface ArticleDetailModalProps {
  articleId: string | null;
  onClose: () => void;
  onSelectArticle: (id: string) => void;
}

export const ArticleDetailModal: React.FC<ArticleDetailModalProps> = ({
  articleId,
  onClose,
  onSelectArticle,
}) => {
  const { articles, incrementArticleViews, currentUser } = useNews();

  const [fontSize, setFontSize] = useState<'normal' | 'large' | 'xlarge'>('normal');
  const [isBookmarked, setIsBookmarked] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);

  // Audio Speech Reader State
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);

  // Comments State
  const [comments, setComments] = useState<Comment[]>([
    {
      id: 'c-1',
      articleId: articleId || '',
      authorName: 'H. Sudirman Pamanukan',
      authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      content: 'Alhamdulillah, sangat dinantikan warga Pamanukan. Semoga pengerjaan tepat waktu sebelum puncak musim hujan tiba!',
      createdAt: '2 jam yang lalu',
      likes: 12,
      isVerified: true,
    },
    {
      id: 'c-2',
      articleId: articleId || '',
      authorName: 'Siti Rahmawati',
      authorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
      content: 'Liputan PAMANUKAN NEWS selalu cepat dan langsung dari lapangan. Terus suarakan aspirasi masyarakat pesisir Pantura!',
      createdAt: '4 jam yang lalu',
      likes: 7,
      isVerified: false,
    },
  ]);
  const [newCommentText, setNewCommentText] = useState<string>('');

  const article = articles.find((a) => a.id === articleId);

  // Increment views once on open
  useEffect(() => {
    if (articleId) {
      incrementArticleViews(articleId);
    }
  }, [articleId]);

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        stopSpeech();
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      stopSpeech();
    };
  }, [onClose]);

  if (!article) return null;

  // Audio Speech Handler using Web Speech API
  const startSpeech = () => {
    if (!('speechSynthesis' in window)) return;

    if (isPaused) {
      window.speechSynthesis.resume();
      setIsPaused(false);
      setIsSpeaking(true);
      return;
    }

    window.speechSynthesis.cancel();

    // Strip HTML tags for clean reading
    const textToRead = `${article.title}. Berita dari PAMANUKAN NEWS. ${article.summary}. ${article.content.replace(/<[^>]*>?/gm, '')}`;
    const utterance = new SpeechSynthesisUtterance(textToRead);
    utterance.lang = 'id-ID';
    utterance.rate = 1.0;

    utterance.onend = () => {
      setIsSpeaking(false);
      setIsPaused(false);
    };

    utterance.onerror = () => {
      setIsSpeaking(false);
      setIsPaused(false);
    };

    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
    setIsPaused(false);
  };

  const pauseSpeech = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.pause();
      setIsPaused(true);
    }
  };

  const stopSpeech = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      setIsPaused(false);
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim()) return;

    const newComment: Comment = {
      id: `c-${Date.now()}`,
      articleId: article.id,
      authorName: currentUser.name || 'Warga Pamanukan',
      authorAvatar: currentUser.avatar,
      content: newCommentText.trim(),
      createdAt: 'Baru saja',
      likes: 0,
      isVerified: currentUser.role !== 'reader',
    };

    setComments([newComment, ...comments]);
    setNewCommentText('');
  };

  const handleLikeComment = (commentId: string) => {
    setComments((prev) =>
      prev.map((c) => (c.id === commentId ? { ...c, likes: c.likes + 1 } : c))
    );
  };

  // Related articles in same category
  const relatedArticles = articles
    .filter((a) => a.id !== article.id && a.categoryId === article.categoryId && a.status === 'published')
    .slice(0, 3);

  const fontSizeClasses = {
    normal: 'text-base leading-relaxed',
    large: 'text-lg leading-loose',
    xlarge: 'text-xl leading-loose',
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-sm flex justify-center p-2 sm:p-4 md:p-6 animate-fade-in">
      <div className="relative w-full max-w-4xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-auto max-h-[94vh] flex flex-col">
        {/* Sticky Header Bar */}
        <div className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md px-6 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4">
          {/* Breadcrumb */}
          <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 truncate">
            <span>Beranda</span>
            <ChevronRight className="w-3.5 h-3.5" />
            <span className="font-semibold text-red-600 dark:text-red-400">
              {article.categoryName}
            </span>
          </div>

          {/* Action Toolbar */}
          <div className="flex items-center gap-2">
            {/* Font Size Adjuster */}
            <div className="flex items-center bg-slate-100 dark:bg-slate-800 rounded-xl p-1 text-xs font-bold text-slate-600 dark:text-slate-300">
              <button
                onClick={() => setFontSize('normal')}
                className={`px-2 py-0.5 rounded-lg transition ${
                  fontSize === 'normal' ? 'bg-white dark:bg-slate-700 text-red-600 shadow-xs' : ''
                }`}
                title="Ukuran teks normal"
              >
                A
              </button>
              <button
                onClick={() => setFontSize('large')}
                className={`px-2 py-0.5 rounded-lg transition text-sm ${
                  fontSize === 'large' ? 'bg-white dark:bg-slate-700 text-red-600 shadow-xs' : ''
                }`}
                title="Ukuran teks besar"
              >
                A+
              </button>
              <button
                onClick={() => setFontSize('xlarge')}
                className={`px-2 py-0.5 rounded-lg transition text-base ${
                  fontSize === 'xlarge' ? 'bg-white dark:bg-slate-700 text-red-600 shadow-xs' : ''
                }`}
                title="Ukuran teks ekstra besar"
              >
                A++
              </button>
            </div>

            {/* Bookmark */}
            <button
              onClick={() => setIsBookmarked(!isBookmarked)}
              className={`p-2 rounded-xl border border-slate-200 dark:border-slate-800 transition ${
                isBookmarked
                  ? 'bg-amber-500 text-white border-amber-500'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title="Simpan artikel"
            >
              <Bookmark className="w-4 h-4" />
            </button>

            {/* Close Button */}
            <button
              onClick={() => {
                stopSpeech();
                onClose();
              }}
              className="p-2 rounded-xl text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Article Body */}
        <div className="overflow-y-auto p-6 sm:p-10 space-y-6">
          {/* Category & Date */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="bg-red-600 text-white text-xs font-black px-3 py-1 rounded-full uppercase tracking-wider">
              {article.categoryName}
            </span>
            {article.isEditorPick && (
              <span className="bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 text-xs font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
                <Award className="w-3.5 h-3.5" />
                <span>Pilihan Redaksi</span>
              </span>
            )}
            <span className="text-xs text-slate-400">
              {new Date(article.publishedAt || article.createdAt).toLocaleDateString('id-ID', {
                weekday: 'long',
                day: 'numeric',
                month: 'long',
                year: 'numeric',
              })}
            </span>
          </div>

          {/* Title */}
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-slate-900 dark:text-white leading-tight">
            {article.title}
          </h1>

          {/* Author Card & Reading Time */}
          <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-3">
              <img
                src={article.authorAvatar}
                alt={article.authorName}
                className="w-11 h-11 rounded-full object-cover ring-2 ring-red-500/30"
              />
              <div>
                <p className="text-sm font-bold text-slate-900 dark:text-white">
                  {article.authorName}
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Jurnalis Redaksi PAMANUKAN NEWS
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
              <span className="flex items-center gap-1">
                <Clock className="w-4 h-4 text-red-500" />
                <span>{article.readingTimeMinutes} Menit Baca</span>
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Eye className="w-4 h-4 text-blue-500" />
                <span>{article.views.toLocaleString('id-ID')} Tayangan</span>
              </span>
            </div>
          </div>

          {/* Audio Speech Player Banner (Fitur Baca Berita Otomatis) */}
          <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-2xl bg-linear-to-r from-red-50 to-orange-50 dark:from-red-950/30 dark:to-orange-950/20 border border-red-200 dark:border-red-900/40">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-red-600 text-white flex items-center justify-center shadow-xs">
                {isSpeaking ? (
                  <Volume2 className="w-4 h-4 animate-pulse" />
                ) : (
                  <Volume2 className="w-4 h-4" />
                )}
              </div>
              <div>
                <p className="text-xs font-bold text-slate-900 dark:text-white">
                  Dengarkan Artikel (Audio Berita Otomatis)
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Gunakan suara AI narator berita Bahasa Indonesia
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              {!isSpeaking || isPaused ? (
                <button
                  onClick={startSpeech}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>{isPaused ? 'Lanjutkan' : 'Putar Audio'}</span>
                </button>
              ) : (
                <button
                  onClick={pauseSpeech}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
                >
                  <Pause className="w-3.5 h-3.5" />
                  <span>Jeda</span>
                </button>
              )}

              {isSpeaking && (
                <button
                  onClick={stopSpeech}
                  className="p-1.5 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl hover:bg-slate-300 transition cursor-pointer"
                  title="Berhenti"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Cover Image */}
          <div className="rounded-2xl overflow-hidden bg-slate-100 dark:bg-slate-800 shadow-md">
            <img
              src={article.coverImage}
              alt={article.title}
              className="w-full max-h-[460px] object-cover"
            />
            <div className="p-2.5 bg-slate-50 dark:bg-slate-850 text-slate-500 dark:text-slate-400 text-xs italic text-center border-t border-slate-100 dark:border-slate-800">
              Dokumentasi Foto Redaksi PAMANUKAN NEWS / Liputan Wilayah Pantura Subang
            </div>
          </div>

          {/* Summary Lead */}
          <div className="p-4 rounded-xl bg-slate-100 dark:bg-slate-800/80 border-l-4 border-red-600 text-slate-800 dark:text-slate-200 font-semibold italic text-sm leading-relaxed">
            {article.summary}
          </div>

          {/* Formatted Article Content */}
          <div
            className={`font-serif-reading prose dark:prose-invert max-w-none text-slate-800 dark:text-slate-200 ${fontSizeClasses[fontSize]}`}
            dangerouslySetInnerHTML={{ __html: article.content }}
          />

          {/* Tags */}
          {article.tags && article.tags.length > 0 && (
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800">
              <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                Topik Terkait:
              </p>
              <div className="flex flex-wrap gap-2">
                {article.tags.map((tag, i) => (
                  <span
                    key={i}
                    className="px-3 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-red-50 text-slate-700 dark:text-slate-300 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Social Share Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Share2 className="w-4 h-4 text-red-600" />
              <span>Bagikan Berita Ini:</span>
            </span>

            <div className="flex items-center gap-2">
              <a
                href={`https://api.whatsapp.com/send?text=${encodeURIComponent(
                  `${article.title} - Baca selengkapnya di PAMANUKAN NEWS: ${window.location.href}`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5"
              >
                <span>WhatsApp</span>
              </a>

              <a
                href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(
                  window.location.href
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5"
              >
                <span>Facebook</span>
              </a>

              <button
                onClick={handleCopyLink}
                className="px-3 py-1.5 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
              >
                {copiedLink ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Tersalin!</span>
                  </>
                ) : (
                  <span>Salin Tautan</span>
                )}
              </button>
            </div>
          </div>

          {/* Interactive Comments Section */}
          <div className="pt-6 border-t border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-red-600" />
                <span>Komentar Pembaca ({comments.length})</span>
              </h3>
              <span className="text-xs text-slate-400">Moderasi otomatis aktif</span>
            </div>

            {/* Comment Form */}
            <form onSubmit={handleAddComment} className="flex gap-2">
              <input
                type="text"
                placeholder="Tulis tanggapan atau opini Anda secara santun..."
                value={newCommentText}
                onChange={(e) => setNewCommentText(e.target.value)}
                className="flex-1 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white placeholder-slate-400 text-xs px-4 py-2.5 rounded-xl outline-none focus:ring-2 focus:ring-red-500"
              />
              <button
                type="submit"
                className="px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl transition shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Kirim</span>
              </button>
            </form>

            {/* Comments List */}
            <div className="space-y-3 pt-2">
              {comments.map((comment) => (
                <div
                  key={comment.id}
                  className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <img
                        src={comment.authorAvatar}
                        alt={comment.authorName}
                        className="w-7 h-7 rounded-full object-cover"
                      />
                      <span className="text-xs font-bold text-slate-900 dark:text-white">
                        {comment.authorName}
                      </span>
                      {comment.isVerified && (
                        <span className="bg-blue-100 dark:bg-blue-950 text-blue-600 text-[10px] font-bold px-1.5 py-0.2 rounded">
                          Warga Terverifikasi
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-slate-400">{comment.createdAt}</span>
                  </div>
                  <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                    {comment.content}
                  </p>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleLikeComment(comment.id)}
                      className="text-[11px] text-slate-500 hover:text-red-600 flex items-center gap-1 transition"
                    >
                      <ThumbsUp className="w-3 h-3" />
                      <span>{comment.likes} Suka</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Related Articles */}
          {relatedArticles.length > 0 && (
            <div className="pt-8 border-t border-slate-200 dark:border-slate-800 space-y-4">
              <h3 className="text-base font-black text-slate-900 dark:text-white">
                Berita Terkait di {article.categoryName}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {relatedArticles.map((rel) => (
                  <div
                    key={rel.id}
                    onClick={() => {
                      stopSpeech();
                      onSelectArticle(rel.id);
                    }}
                    className="group cursor-pointer space-y-2 bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-red-500/40 transition"
                  >
                    <img
                      src={rel.coverImage}
                      alt={rel.title}
                      className="w-full h-24 object-cover rounded-lg group-hover:scale-102 transition"
                    />
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white line-clamp-2 group-hover:text-red-600 transition">
                      {rel.title}
                    </h4>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
